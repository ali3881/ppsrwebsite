# PPSR Stripe Settings Integration Fix

This package contains fixes for the PPSR service website to use Stripe API keys from the admin settings panel instead of hardcoded values, and fixes the database column error in search.php.

## What's Fixed

1. **Database Column Error in search.php**
   - Fixed the "Unknown column 'value' in 'SELECT'" error
   - Updated the SQL query to use 'setting_value' instead of 'value'
   - Added better error handling for database queries
   - Implemented a fallback to a default search fee value (25.00) if the database query fails

2. **Dynamic Stripe API Keys**
   - Updated the Stripe integration to use API keys from the admin settings panel
   - Added a getSettingValue function to retrieve settings from the database
   - Maintained backward compatibility with existing constants
   - Added proper error handling for missing or invalid API keys

3. **Improved Error Handling**
   - Added detailed error logging for database and API errors
   - Implemented fallback mechanisms for missing settings
   - Enhanced user feedback for payment processing errors

## Files Included

1. **stripe_payment.php**
   - Updated to retrieve API keys from the settings table
   - Added getSettingValue function for settings retrieval
   - Enhanced error handling and logging

2. **search.php**
   - Fixed to use the correct database column name (setting_value)
   - Maintained all other functionality

## Installation Instructions

1. **Backup Your Original Files**:
   ```
   cp /home/ppsrsecuritychec/public_html/includes/search.php /home/ppsrsecuritychec/public_html/includes/search.php.bak
   cp /home/ppsrsecuritychec/public_html/includes/stripe_payment.php /home/ppsrsecuritychec/public_html/includes/stripe_payment.php.bak
   ```

2. **Upload the New Files**:
   - Upload `search.php` to `/home/ppsrsecuritychec/public_html/includes/`
   - Upload `stripe_payment.php` to `/home/ppsrsecuritychec/public_html/includes/`

3. **Set File Permissions**:
   ```
   chmod 644 /home/ppsrsecuritychec/public_html/includes/search.php
   chmod 644 /home/ppsrsecuritychec/public_html/includes/stripe_payment.php
   ```

## Testing

After installing the fixed files, verify that:

1. The search page loads without any database errors
2. The Stripe API keys are retrieved from the admin settings panel
3. The payment process works correctly with the Stripe Checkout flow
4. The admin dashboard shows Stripe API as connected (if API keys are valid)

## Important Notes

1. **Admin Settings Panel**
   - Make sure your Stripe API keys are configured in the admin settings panel
   - Go to Admin > Settings > Payment Settings to configure your Stripe API keys

2. **Backward Compatibility**
   - If settings are not found in the database, the system will fall back to using the constants defined in config.php
   - This ensures the system continues to work even if the settings table is not properly configured

3. **Error Handling**
   - The system now logs detailed error messages to help diagnose any issues
   - Check your PHP error log if you encounter any problems
