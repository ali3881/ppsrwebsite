<?php
/**
 * Stripe Payment Integration with Proper SSL Verification
 * 
 * This file handles the Stripe payment integration for processing
 * payments for PPSR searches using the Stripe API with proper
 * SSL certificate verification.
 */

/**
 * Get a setting value from the database
 * 
 * @param string $settingName The name of the setting to retrieve
 * @param string $default The default value to return if the setting is not found
 * @return string The setting value or default if not found
 */
function getSettingValue($settingName, $default = '') {
    global $conn;
    
    if (!$conn) {
        error_log("Database connection not available for getSettingValue");
        return $default;
    }
    
    $stmt = null;
    $result = null;
    
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        if ($stmt) {
            $stmt->bind_param("s", $settingName);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return $row['setting_value'];
            }
        }
    } catch (Exception $e) {
        error_log("Error querying with setting_key: " . $e->getMessage());
    }
    
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_name = ?");
        if ($stmt) {
            $stmt->bind_param("s", $settingName);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return $row['setting_value'];
            }
        }
    } catch (Exception $e) {
        error_log("Error querying with setting_name: " . $e->getMessage());
    }
    
    return $default;
}

$stripePublicKey = getSettingValue('stripe_public_key', defined('STRIPE_PUBLIC_KEY') ? STRIPE_PUBLIC_KEY : '');
$stripeSecretKey = getSettingValue('stripe_secret_key', defined('STRIPE_SECRET_KEY') ? STRIPE_SECRET_KEY : '');

if (!defined('STRIPE_PUBLIC_KEY')) {
    define('STRIPE_PUBLIC_KEY', $stripePublicKey);
}

if (!defined('STRIPE_SECRET_KEY')) {
    define('STRIPE_SECRET_KEY', $stripeSecretKey);
}

if (!defined('SITE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    define('SITE_URL', $protocol . $host);
}

/**
 * Find and set the correct CA certificate bundle path
 * 
 * @return string|null The path to the CA certificate bundle or null if not found
 */
function findCACertPath() {
    $possiblePaths = [
        '/etc/ssl/certs/ca-certificates.crt', // Debian/Ubuntu/Gentoo
        '/etc/pki/tls/certs/ca-bundle.crt',   // Fedora/RHEL/CentOS
        '/etc/ssl/ca-bundle.pem',             // OpenSUSE
        '/etc/pki/tls/cacert.pem',            // OpenELEC
        '/etc/ssl/cert.pem',                  // Alpine Linux
        '/usr/local/share/certs/ca-root-nss.crt', // FreeBSD
        '/usr/local/etc/ssl/cert.pem',        // macOS via Homebrew
        '/opt/local/etc/openssl/cert.pem',    // macOS via MacPorts
        '/usr/local/etc/openssl/cert.pem',    // macOS via OpenSSL
        '/etc/apache2/ssl.crt/ca-bundle.crt', // cPanel
        '/etc/ssl/certs',                     // Directory containing CA certs
        '/usr/share/ca-certificates/mozilla', // Another common directory
        __DIR__ . '/cacert.pem',              // Local copy in the includes directory
        dirname(__DIR__) . '/cacert.pem',     // Local copy in the parent directory
    ];
    
    foreach ($possiblePaths as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }
    
    $localCACertPath = __DIR__ . '/cacert.pem';
    if (downloadCACertBundle($localCACertPath)) {
        return $localCACertPath;
    }
    
    return null;
}

/**
 * Download the Mozilla CA certificate bundle
 * 
 * @param string $savePath The path to save the CA certificate bundle
 * @return bool True if the download was successful, false otherwise
 */
function downloadCACertBundle($savePath) {
    $url = 'https://curl.se/ca/cacert.pem';
    
    $caBundle = @file_get_contents($url);
    if ($caBundle !== false) {
        if (file_put_contents($savePath, $caBundle)) {
            error_log("Downloaded CA certificate bundle to $savePath");
            return true;
        }
    }
    
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $caBundle = curl_exec($ch);
        curl_close($ch);
        
        if ($caBundle !== false) {
            if (file_put_contents($savePath, $caBundle)) {
                error_log("Downloaded CA certificate bundle to $savePath using cURL");
                return true;
            }
        }
    }
    
    error_log("Failed to download CA certificate bundle");
    return false;
}

$caCertPath = findCACertPath();
if ($caCertPath) {
    error_log("Using CA certificate bundle: $caCertPath");
} else {
    error_log("Warning: No CA certificate bundle found. SSL verification may fail.");
}

/**
 * Check if a column exists in a table
 * 
 * @param string $tableName The name of the table
 * @param string $columnName The name of the column
 * @return bool True if the column exists, false otherwise
 */
function columnExists($tableName, $columnName) {
    global $conn;
    
    if (!$conn) {
        error_log("Database connection not available for columnExists");
        return false;
    }
    
    try {
        $result = $conn->query("SHOW COLUMNS FROM $tableName LIKE '$columnName'");
        return ($result && $result->num_rows > 0);
    } catch (Exception $e) {
        error_log("Error checking if column exists: " . $e->getMessage());
        return false;
    }
}

/**
 * Create a checkout session with Stripe
 * 
 * @param float $amount The amount to charge
 * @param string $identifier The search identifier (VIN or registration)
 * @param int|null $userId The user ID or null for guest
 * @param string|null $state The registration state (for registration plates only)
 * @return array The result of the checkout session creation
 */
function createCheckoutSession($amount, $identifier, $userId, $state = null) {
    global $conn, $caCertPath;
    
    $secretKey = STRIPE_SECRET_KEY;
    
    if (empty($secretKey)) {
        return [
            'success' => false,
            'error' => 'Stripe API key not configured. Please set it in the admin settings panel.'
        ];
    }
    
    $amountInCents = (int)($amount * 100);
    $searchReference = 'search_' . time() . '_' . mt_rand(1000, 9999);
    
    $data = [
        'payment_method_types[]' => 'card',
        'line_items[0][price_data][currency]' => 'aud',
        'line_items[0][price_data][product_data][name]' => 'PPSR Search',
        'line_items[0][price_data][product_data][description]' => 'Vehicle: ' . $identifier,
        'line_items[0][price_data][unit_amount]' => $amountInCents,
        'line_items[0][quantity]' => 1,
        'mode' => 'payment',
        'success_url' => SITE_URL . '/payment_success.php?session_id={CHECKOUT_SESSION_ID}&reference=' . $searchReference,
        'cancel_url' => SITE_URL . '/index.php?page=search&cancel=true',
        'metadata[identifier]' => $identifier,
        'metadata[user_id]' => $userId ? $userId : 'guest',
        'metadata[reference]' => $searchReference
    ];
    
    if ($state) {
        $data['metadata[state]'] = $state;
    }
    
    $ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $secretKey,
        'Content-Type: application/x-www-form-urlencoded',
    ]);
    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    
    if ($caCertPath) {
        if (is_dir($caCertPath)) {
            curl_setopt($ch, CURLOPT_CAPATH, $caCertPath);
        } else {
            curl_setopt($ch, CURLOPT_CAINFO, $caCertPath);
        }
    }
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if ($error && strpos($error, 'SSL') !== false) {
        error_log("SSL Error: " . $error);
        error_log("CA Cert Path: " . ($caCertPath ? $caCertPath : 'Not set'));
        error_log("cURL Version: " . curl_version()['version']);
        error_log("SSL Version: " . curl_version()['ssl_version']);
    }
    
    curl_close($ch);
    
    if ($error) {
        error_log("Stripe API Error: " . $error);
        return [
            'success' => false,
            'error' => 'Error communicating with Stripe: ' . $error
        ];
    }
    
    $result = json_decode($response, true);
    
    if ($statusCode != 200) {
        error_log("Stripe API Error: " . print_r($result, true));
        return [
            'success' => false,
            'error' => isset($result['error']['message']) ? $result['error']['message'] : 'Unknown error'
        ];
    }
    
    $hasReferenceColumn = columnExists('payments', 'reference');
    
    if ($userId) {
        if ($hasReferenceColumn) {
            $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status, reference) VALUES (?, 'stripe', ?, ?, 'pending', ?)");
            $stmt->bind_param("idss", $userId, $amount, $result['id'], $searchReference);
        } else {
            $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status) VALUES (?, 'stripe', ?, ?, 'pending')");
            $stmt->bind_param("ids", $userId, $amount, $result['id']);
        }
    } else {
        if ($hasReferenceColumn) {
            $stmt = $conn->prepare("INSERT INTO payments (payment_method, amount, transaction_id, status, reference) VALUES ('stripe', ?, ?, 'pending', ?)");
            $stmt->bind_param("dss", $amount, $result['id'], $searchReference);
        } else {
            $stmt = $conn->prepare("INSERT INTO payments (payment_method, amount, transaction_id, status) VALUES ('stripe', ?, ?, 'pending')");
            $stmt->bind_param("ds", $amount, $result['id']);
        }
    }
    
    $stmt->execute();
    $paymentId = $stmt->insert_id;
    
    $_SESSION['search_reference'] = $searchReference;
    $_SESSION['search_identifier'] = $identifier;
    $_SESSION['payment_id'] = $paymentId;
    
    return [
        'success' => true,
        'payment_id' => $paymentId,
        'checkout_url' => $result['url'],
        'session_id' => $result['id']
    ];
}

/**
 * Process a successful payment
 * 
 * @param string $sessionId The Stripe session ID
 * @param int $paymentId The payment ID in the database
 * @return array The result of the payment processing
 */
function processSuccessfulPayment($sessionId, $paymentId) {
    global $conn, $caCertPath;
    
    $secretKey = STRIPE_SECRET_KEY;
    
    if (empty($secretKey)) {
        return [
            'success' => false,
            'error' => 'Stripe API key not configured. Please set it in the admin settings panel.'
        ];
    }
    
    $ch = curl_init('https://api.stripe.com/v1/checkout/sessions/' . $sessionId);
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $secretKey,
    ]);
    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    
    if ($caCertPath) {
        if (is_dir($caCertPath)) {
            curl_setopt($ch, CURLOPT_CAPATH, $caCertPath);
        } else {
            curl_setopt($ch, CURLOPT_CAINFO, $caCertPath);
        }
    }
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    if ($error) {
        error_log("Stripe API Error: " . $error);
        return [
            'success' => false,
            'error' => 'Error communicating with Stripe: ' . $error
        ];
    }
    
    $result = json_decode($response, true);
    
    if ($statusCode != 200) {
        error_log("Stripe API Error: " . print_r($result, true));
        return [
            'success' => false,
            'error' => isset($result['error']['message']) ? $result['error']['message'] : 'Unknown error'
        ];
    }
    
    if ($result['payment_status'] === 'paid') {
        $stmt = $conn->prepare("UPDATE payments SET status = 'completed' WHERE id = ?");
        $stmt->bind_param("i", $paymentId);
        $stmt->execute();
        
        return [
            'success' => true,
            'payment_id' => $paymentId,
            'identifier' => $result['metadata']['identifier']
        ];
    } else {
        $stmt = $conn->prepare("UPDATE payments SET status = 'failed' WHERE id = ?");
        $stmt->bind_param("i", $paymentId);
        $stmt->execute();
        
        return [
            'success' => false,
            'error' => 'Payment not successful. Status: ' . $result['payment_status']
        ];
    }
}

/**
 * Check if the Stripe API connection is working
 * 
 * @return bool True if the connection is working, false otherwise
 */
function checkStripeApiConnection() {
    global $caCertPath;
    
    $secretKey = STRIPE_SECRET_KEY;
    
    if (empty($secretKey)) {
        return false;
    }
    
    $ch = curl_init('https://api.stripe.com/v1/balance');
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $secretKey,
    ]);
    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    
    if ($caCertPath) {
        if (is_dir($caCertPath)) {
            curl_setopt($ch, CURLOPT_CAPATH, $caCertPath);
        } else {
            curl_setopt($ch, CURLOPT_CAINFO, $caCertPath);
        }
    }
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    return ($error === '' && $statusCode === 200);
}
?>
