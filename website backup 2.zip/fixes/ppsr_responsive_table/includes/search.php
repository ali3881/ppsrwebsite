<?php
/**
 * Search Page
 * 
 * This file handles the search functionality for the PPSR website.
 * It includes the search form and processes search requests.
 */

require_once 'includes/stripe_payment.php';

if (file_exists('includes/functions.php')) {
    require_once 'includes/functions.php';
} elseif (file_exists('functions.php')) {
    require_once 'functions.php';
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$searchFee = 25.00; // Default value

try {
    $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'search_fee'");
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $searchFee = floatval($row['setting_value']);
        }
    }
} catch (Exception $e) {
    error_log("Error querying search_fee with setting_key: " . $e->getMessage());
    
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_name = 'search_fee'");
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $searchFee = floatval($row['setting_value']);
            }
        }
    } catch (Exception $e) {
        error_log("Error querying search_fee with setting_name: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['identifier'])) {
    $identifier = sanitizeInput($_POST['identifier']);
    
    if (empty($identifier)) {
        $error = "Please enter a VIN or registration number.";
    } else {
        $isVin = (strlen($identifier) == 17 && preg_match('/^[A-HJ-NPR-Z0-9]{17}$/i', $identifier));
        $state = null;
        
        if (!$isVin && isset($_POST['state'])) {
            $state = sanitizeInput($_POST['state']);
        }
        
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        
        $checkoutResult = createCheckoutSession($searchFee, $identifier, $userId, $isVin ? null : $state);
        
        if ($checkoutResult['success']) {
            header('Location: ' . $checkoutResult['checkout_url']);
            exit;
        } else {
            $error = "Payment processing error: " . $checkoutResult['error'];
        }
    }
}

if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'invalid_payment':
            $error = "Invalid payment session.";
            break;
        case 'payment_not_found':
            $error = "Payment record not found.";
            break;
        case 'payment_failed':
            $error = "Payment failed. Please try again.";
            if (isset($_GET['message'])) {
                $error .= " Error: " . $_GET['message'];
            }
            break;
        case 'identifier_not_found':
            $error = "Search identifier not found.";
            break;
        default:
            $error = "An error occurred. Please try again.";
            break;
    }
}

if (isset($_GET['cancel']) && $_GET['cancel'] === 'true') {
    $error = "Payment was cancelled. Please try again.";
}
?>

<div class="container">
    <h1>PPSR Search</h1>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <div class="search-form" style="background-color: #fff; padding: 25px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 30px;">
        <form method="post" action="">
            <div class="form-group" style="margin-bottom: 20px;">
                <label for="identifier" style="font-weight: 500; margin-bottom: 8px; display: block;">Vehicle Identifier (VIN or Registration Number)</label>
                <input type="text" class="form-control" id="identifier" name="identifier" placeholder="Enter either a 17-character VIN or a registration number" required onkeyup="detectIdentifierType(this.value)" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px;">
                <small class="form-text text-muted" style="display: block; margin-top: 5px;">The system will automatically detect whether you've entered a VIN or registration number.</small>
            </div>
            
            <div class="form-group" id="state-container" style="display: none; margin-top: 20px; margin-bottom: 20px;">
                <label for="state" style="font-weight: 500; margin-bottom: 8px; display: block;">Registration State</label>
                <select class="form-control" id="state" name="state" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; background-color: #fff;">
                    <option value="ACT">Australian Capital Territory</option>
                    <option value="NSW">New South Wales</option>
                    <option value="NT">Northern Territory</option>
                    <option value="QLD">Queensland</option>
                    <option value="SA">South Australia</option>
                    <option value="TAS">Tasmania</option>
                    <option value="VIC">Victoria</option>
                    <option value="WA">Western Australia</option>
                </select>
            </div>
            
            <div class="payment-info" style="margin-top: 30px; margin-bottom: 30px;">
                <h3 style="font-size: 20px; margin-bottom: 15px;">Payment Information</h3>
                <div class="alert alert-info" style="background-color: #e3f2fd; border: none; border-radius: 4px; padding: 15px; color: #0c5460;">
                    <p style="margin-bottom: 10px; font-size: 16px;">Search Fee: $<?php echo number_format($searchFee, 2); ?> AUD</p>
                    <p style="margin-bottom: 0; font-size: 16px;">You will be redirected to Stripe's secure payment page to complete your payment.</p>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="background-color: #007bff; border: none; padding: 12px 25px; font-size: 16px; border-radius: 4px; color: white; cursor: pointer; font-weight: 500;">Search PPSR</button>
        </form>
    </div>
</div>

<script>
function detectIdentifierType(value) {
    value = value.trim();
    
    const isVin = value.length === 17 && /^[A-HJ-NPR-Z0-9]{17}$/i.test(value);
    
    if (!isVin && value.length > 0) {
        document.getElementById('state-container').style.display = 'block';
        
        if (typeof(Storage) !== "undefined") {
            sessionStorage.setItem('identifier_type', 'registration');
        }
    } else {
        document.getElementById('state-container').style.display = 'none';
        
        if (typeof(Storage) !== "undefined" && isVin) {
            sessionStorage.setItem('identifier_type', 'vin');
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const identifierInput = document.getElementById('identifier');
    if (identifierInput.value) {
        detectIdentifierType(identifierInput.value);
    }
});
</script>
