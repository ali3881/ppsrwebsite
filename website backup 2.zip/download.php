<?php

$file = isset($_GET['file']) ? $_GET['file'] : '';

if (empty($file) || !preg_match('/^reports\/[a-zA-Z0-9_]+\.(pdf|html)$/', $file)) {
    header('HTTP/1.0 403 Forbidden');
    echo 'Access denied';
    exit;
}

if (!file_exists($file)) {
    header('HTTP/1.0 404 Not Found');
    echo 'File not found';
    exit;
}

$extension = pathinfo($file, PATHINFO_EXTENSION);

if ($extension == 'pdf') {
    header('Content-Type: application/pdf');
} elseif ($extension == 'html') {
    header('Content-Type: text/html');
} else {
    header('HTTP/1.0 403 Forbidden');
    echo 'Invalid file type';
    exit;
}

header('Content-Disposition: inline; filename="' . basename($file) . '"');

header('Content-Length: ' . filesize($file));

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

readfile($file);
exit;
?>
