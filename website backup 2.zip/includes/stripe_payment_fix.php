<?php
/**
 * Stripe Payment Integration Fix
 * 
 * This file provides a fix for the createPaymentIntent function that's missing in the functions.php file.
 */

if (!function_exists('createPaymentIntent')) {
    function createPaymentIntent($amount, $vin, $userId) {
        global $conn;
        
        try {
            if (file_exists(__DIR__ . '/stripe-php/init.php') && extension_loaded('curl') && extension_loaded('mbstring')) {
                require_once __DIR__ . '/stripe-php/init.php';
                \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
                
                $amountInCents = $amount * 100;
                
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $amountInCents,
                    'currency' => 'aud',
                    'description' => 'PPSR Search for VIN: ' . $vin,
                    'metadata' => [
                        'vin' => $vin,
                        'user_id' => $userId ? $userId : 'guest'
                    ]
                ]);
                
                $paymentIntentId = $paymentIntent->id;
                $clientSecret = $paymentIntent->client_secret;
            } else {
                $paymentIntentId = 'pi_' . time() . rand(1000, 9999);
                $clientSecret = 'pi_' . time() . rand(1000, 9999) . '_secret_' . rand(1000, 9999);
            }
            
            $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status) VALUES (?, 'stripe', ?, ?, 'pending')");
            $stmt->bind_param("ids", $userId, $amount, $paymentIntentId);
            $stmt->execute();
            $paymentId = $stmt->insert_id;
            
            return [
                'success' => true,
                'payment_id' => $paymentId,
                'client_secret' => $clientSecret,
                'public_key' => STRIPE_PUBLIC_KEY
            ];
        } catch (Exception $e) {
            error_log("Stripe Payment Error: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
?>
