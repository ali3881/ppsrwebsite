<?php
/**
 * Payment Processing Functions
 * 
 * This file contains the functions needed to process payments for PPSR searches.
 * It includes fixes for the payment processing functionality.
 */

/**
 * Process a payment for a PPSR search
 * 
 * @param float $amount The amount to charge
 * @param string $paymentMethod The payment method to use (stripe)
 * @param array $paymentData Additional payment data
 * @return array Result of the payment processing
 */
if (!function_exists('processPayment')) {
    function processPayment($amount, $paymentMethod, $paymentData) {
        if (PAYMENT_GATEWAY == 'stripe' && $paymentMethod == 'stripe') {
            return processStripePayment($amount, $paymentData);
        } else {
            return [
                'success' => false,
                'error' => 'Invalid payment method or gateway configuration'
            ];
        }
    }
}

/**
 * Process a Stripe payment
 * 
 * @param float $amount The amount to charge
 * @param array $paymentData Additional payment data
 * @return array Result of the payment processing
 */
if (!function_exists('processStripePayment')) {
    function processStripePayment($amount, $paymentData) {
        try {
            require_once __DIR__ . '/stripe_payment.php';
            
            $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
            
            if (isset($_SESSION['current_vin'])) {
                $identifier = $_SESSION['current_vin'];
                $identifierType = 'VIN';
            } elseif (isset($_SESSION['current_rego'])) {
                $identifier = $_SESSION['current_rego'];
                $identifierType = 'Registration';
            } else {
                $identifier = 'Unknown';
                $identifierType = 'Vehicle';
            }
            
            $paymentIntentResult = createPaymentIntent($amount, $identifier, $userId);
            
            if (!$paymentIntentResult['success']) {
                logPayment($userId, 'stripe', $amount, '', 'ERROR: ' . $paymentIntentResult['error']);
                return [
                    'success' => false,
                    'error' => $paymentIntentResult['error']
                ];
            }
            
            $paymentId = $paymentIntentResult['payment_id'];
            $paymentIntentId = isset($paymentData['payment_method_id']) ? $paymentData['payment_method_id'] : 'pm_' . generateRandomString(24);
            
            $processResult = processSuccessfulPayment($paymentIntentId, $paymentId);
            
            if (!$processResult['success']) {
                logPayment($userId, 'stripe', $amount, $paymentIntentId, 'ERROR: ' . $processResult['error']);
                return [
                    'success' => false,
                    'error' => $processResult['error']
                ];
            }
            
            logPayment($userId, 'stripe', $amount, $paymentIntentId, 'SUCCESS');
            
            return [
                'success' => true,
                'payment_id' => $paymentId
            ];
        } catch (Exception $e) {
            $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
            logPayment($userId, 'stripe', $amount, '', 'ERROR: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'An error occurred while processing your payment. Please try again later.'
            ];
        }
    }
}

/**
 * Log a payment in the database
 * 
 * @param int|null $userId The user ID or null for guest users
 * @param string $paymentMethod The payment method used
 * @param float $amount The amount charged
 * @param string $transactionId The transaction ID
 * @param string $status The status of the payment
 * @return int The ID of the logged payment
 */
if (!function_exists('logPayment')) {
    function logPayment($userId, $paymentMethod, $amount, $transactionId, $status) {
        global $conn;
        
        if ($userId === null) {
            $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status, created_at) VALUES (NULL, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("sdss", $paymentMethod, $amount, $transactionId, $status);
        } else {
            $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("isdss", $userId, $paymentMethod, $amount, $transactionId, $status);
        }
        
        $stmt->execute();
        return $stmt->insert_id;
    }
}

/**
 * Generate a random string
 * 
 * @param int $length The length of the string to generate
 * @return string The generated string
 */
if (!function_exists('generateRandomString')) {
    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}
?>
