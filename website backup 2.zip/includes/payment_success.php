<?php
/**
 * Payment Success Page
 * 
 * This file handles the payment success page for PPSR searches.
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php?page=login');
    exit;
}

if (!isset($_SESSION['payment_id'])) {
    header('Location: index.php?page=search');
    exit;
}

$paymentId = $_SESSION['payment_id'];
$vin = $_SESSION['search_vin'];

require_once 'stripe_payment.php';
$paymentResult = processSuccessfulPayment('simulated_payment_intent_id', $paymentId);

if (!$paymentResult['success']) {
    $_SESSION['error'] = 'Error processing payment: ' . $paymentResult['error'];
    header('Location: index.php?page=search');
    exit;
}

require_once 'soap_client.php';
$searchResult = performVinSearch($vin, $_SESSION['user_id']);

if (!$searchResult['success']) {
    $_SESSION['error'] = 'Error performing search: ' . $searchResult['error'];
    header('Location: index.php?page=search');
    exit;
}

$pdfReport = generatePdfReport($searchResult['data'], $vin, $paymentId);
$htmlReport = generateHtmlReport($searchResult['data'], $vin, $paymentId);

global $conn;
$stmt = $conn->prepare("INSERT INTO searches (user_id, payment_id, vin, status, response_data, pdf_report, html_report) VALUES (?, ?, ?, 'completed', ?, ?, ?)");
$responseData = $searchResult['raw_response'];
$stmt->bind_param("iissss", $_SESSION['user_id'], $paymentId, $vin, $responseData, $pdfReport, $htmlReport);
$stmt->execute();
$searchId = $stmt->insert_id;

unset($_SESSION['payment_id']);
unset($_SESSION['search_vin']);

?>

<div class="success-container">
    <div class="success-message">
        <h2>Payment Successful</h2>
        <p>Your payment has been processed successfully and your PPSR search is complete.</p>
        
        <div class="search-details">
            <p><strong>Search ID:</strong> <?php echo $searchId; ?></p>
            <p><strong>VIN:</strong> <?php echo htmlspecialchars($vin); ?></p>
            <p><strong>Date:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
        
        <div class="report-links">
            <h3>Your Reports</h3>
            <p>You can view or download your reports using the links below:</p>
            
            <div class="report-buttons">
                <a href="<?php echo $pdfReport; ?>" class="btn btn-primary" target="_blank">View PDF Report</a>
                <a href="<?php echo $htmlReport; ?>" class="btn btn-secondary" target="_blank">View HTML Report</a>
            </div>
        </div>
        
        <div class="next-steps">
            <h3>Next Steps</h3>
            <p>You can:</p>
            <ul>
                <li>View your search history in your <a href="index.php?page=dashboard">dashboard</a></li>
                <li>Perform <a href="index.php?page=search">another search</a></li>
                <li>Return to the <a href="index.php">home page</a></li>
            </ul>
        </div>
    </div>
</div>
