<?php
/**
 * Contact Us Page
 * 
 * This file handles the contact form and email sending functionality.
 * Updated for PHP 8.3 compatibility.
 */

$name = $email = $subject = $message = '';
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    if (empty($_POST['name'])) {
        $errors['name'] = 'Name is required';
    } else {
        $name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8');
    }
    
    if (empty($_POST['email'])) {
        $errors['email'] = 'Email is required';
    } else {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Please enter a valid email address';
        }
    }
    
    if (empty($_POST['subject'])) {
        $errors['subject'] = 'Subject is required';
    } else {
        $subject = htmlspecialchars(trim($_POST['subject']), ENT_QUOTES, 'UTF-8');
    }
    
    if (empty($_POST['message'])) {
        $errors['message'] = 'Message is required';
    } else {
        $message = htmlspecialchars(trim($_POST['message']), ENT_QUOTES, 'UTF-8');
    }
    
    if (empty($errors)) {
        global $conn;
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message, status, created_at) VALUES (?, ?, ?, ?, 'new', NOW())");
        $stmt->bind_param("ssss", $name, $email, $subject, $message);
        
        if ($stmt->execute()) {
            $message_id = $conn->insert_id;
            $current_date = date('Y-m-d H:i:s');
            $status = 'new';
            
            $to = 'info@ppsrsecuritycheck.com.au';
            $email_subject = "PPSR Contact Form: $subject";
            
            $email_body = "You have received a new message from the PPSR contact form.\n\n";
            $email_body .= "ID\tName\tEmail\tSubject\tDate\tStatus\n";
            $email_body .= "---------------------------------------------------\n";
            $email_body .= "$message_id\t$name\t$email\t$subject\t$current_date\t$status\n\n";
            $email_body .= "Message:\n$message\n";
            
            $headers = "From: noreply@ppsrsecuritycheck.com.au\r\n";
            $headers .= "Reply-To: $email\r\n";
            
            mail($to, $email_subject, $email_body, $headers);
            
            $success = true;
            $name = $email = $subject = $message = '';
        } else {
            $errors['db'] = 'Failed to save your message. Please try again later.';
        }
    }
}
?>

<div class="contact-page">
    <h2>Contact Us</h2>
    
    <div class="contact-container">
        <div class="contact-info">
            <h3>Get in Touch</h3>
            <p>Have questions about our PPSR search service? We're here to help! Fill out the form and we'll get back to you as soon as possible.</p>
            
            <div class="contact-details">
                <div class="contact-item">
                    <i class="fas fa-envelope"></i>
                    <span>info@ppsrsecuritycheck.com.au</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <span>+61 2 1234 5678</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>123 Business Street, Sydney NSW 2000, Australia</span>
                </div>
            </div>
            
            <div class="business-hours">
                <h4>Business Hours</h4>
                <p>Monday - Friday: 9:00 AM - 5:00 PM</p>
                <p>Saturday - Sunday: Closed</p>
            </div>
        </div>
        
        <div class="contact-form">
            <?php if ($success): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <p>Thank you for your message! We'll get back to you as soon as possible.</p>
                </div>
            <?php else: ?>
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="index.php?page=contact">
                    <div class="form-group">
                        <label for="name">Your Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Your Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subject <span class="required">*</span></label>
                        <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($subject); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Message <span class="required">*</span></label>
                        <textarea id="message" name="message" rows="6" required><?php echo htmlspecialchars($message); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="contact_submit" class="btn btn-primary">Send Message</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
