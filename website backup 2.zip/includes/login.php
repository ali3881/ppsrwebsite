<?php
if (file_exists('includes/functions.php')) {
    require_once 'includes/functions.php';
} elseif (file_exists('functions.php')) {
    require_once 'functions.php';
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}

if (!function_exists('verifyPassword')) {
    function verifyPassword($password, $hashedPassword) {
        if (function_exists('password_verify')) {
            if (password_verify($password, $hashedPassword)) {
                return true;
            }
        }
        
        if (md5($password) === $hashedPassword) {
            return true;
        }
        
        return false;
    }
}
?>
<div class="auth-container">
    <h2>Login</h2>
    
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = sanitizeInput($_POST['email']);
        $password = $_POST['password'];
        
        $errors = [];
        
        if (empty($email)) {
            $errors[] = "Email is required";
        }
        
        if (empty($password)) {
            $errors[] = "Password is required";
        }
        
        if (empty($errors)) {
            try {
                $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 1) {
                    $user = $result->fetch_assoc();
                    
                    if (verifyPassword($password, $user['password'])) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['email'] = $user['email'];
                        
                        $nameFields = ['name', 'username', 'display_name'];
                        foreach ($nameFields as $field) {
                            if (isset($user[$field])) {
                                $_SESSION['name'] = $user[$field];
                                break;
                            }
                        }
                        
                        header('Location: index.php?page=dashboard');
                        exit;
                    } else {
                        $errors[] = "Invalid email or password";
                    }
                } else {
                    $errors[] = "Invalid email or password";
                }
            } catch (Exception $e) {
                error_log("Login error: " . $e->getMessage());
                $errors[] = "An error occurred during login. Please try again.";
            }
        }
        
        if (!empty($errors)) {
            echo '<div class="error-container">';
            foreach ($errors as $error) {
                echo '<p class="error">' . $error . '</p>';
            }
            echo '</div>';
        }
    }
    ?>
    
    <form method="POST" action="index.php?page=login">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Login</button>
        </div>
        
        <p>Don't have an account? <a href="index.php?page=register">Register</a></p>
    </form>
</div>
