<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once 'config.php';
include_once 'functions.php';

if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/includes/functions-isadmin.php')) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/includes/functions-isadmin.php';
}

$siteTitle = 'PPSR Security Check';
$siteDescription = 'Vehicle Registration Check Service';
$primaryColor = '#007bff';
$secondaryColor = '#6c757d';
$logoUrl = '';
$faviconUrl = '';

$result = $conn->query("SELECT * FROM settings WHERE id = 1");
if ($result && $result->num_rows > 0) {
    $settings = $result->fetch_assoc();
    $siteTitle = $settings['site_title'] ?? $siteTitle;
    $siteDescription = $settings['site_description'] ?? $siteDescription;
    $primaryColor = $settings['primary_color'] ?? $primaryColor;
    $secondaryColor = $settings['secondary_color'] ?? $secondaryColor;
    $logoUrl = $settings['logo_url'] ?? '';
    $faviconUrl = $settings['favicon_url'] ?? '';
}

$logoExists = false;
if (!empty($logoUrl)) {
    $logoPath = $_SERVER['DOCUMENT_ROOT'] . $logoUrl;
    $logoExists = file_exists($logoPath);
}

$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = false;

if ($isLoggedIn) {
    if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
        $isAdmin = true;
    } 
    elseif (isset($_SESSION['email']) && $_SESSION['email'] == 'admin@example.com') {
        $isAdmin = true;
        $_SESSION['is_admin'] = 1; // Cache for future checks
    }
    elseif (function_exists('isAdmin')) {
        $isAdmin = isAdmin($_SESSION['user_id']);
    }
    else {
        $stmt = $conn->prepare("SHOW COLUMNS FROM users LIKE 'is_admin'");
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                $isAdmin = $user['is_admin'] == 1;
                $_SESSION['is_admin'] = $isAdmin ? 1 : 0; // Cache for future checks
            }
        } else {
            $stmt = $conn->prepare("SHOW COLUMNS FROM users LIKE 'role'");
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $user = $result->fetch_assoc();
                    $isAdmin = $user['role'] == 'admin';
                    $_SESSION['is_admin'] = $isAdmin ? 1 : 0; // Cache for future checks
                }
            } else {
                $isAdmin = $_SESSION['user_id'] == 1;
                $_SESSION['is_admin'] = $isAdmin ? 1 : 0; // Cache for future checks
            }
        }
    }
}

$currentPage = isset($_GET['page']) ? $_GET['page'] : 'home';

$navPages = [];

$navColumnExists = false;
$result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
if ($result && $result->num_rows > 0) {
    $navColumnExists = true;
    
    $result = $conn->query("SELECT id, title, slug FROM pages WHERE status = 'published' AND show_in_nav = 1 ORDER BY menu_order ASC, title ASC");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $navPages[] = $row;
        }
    }
} else {
    $result = $conn->query("SELECT id, title, slug FROM pages WHERE status = 'published' ORDER BY menu_order ASC, title ASC LIMIT 5");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $navPages[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteTitle); ?> - <?php echo htmlspecialchars($siteDescription); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($siteDescription); ?>">
    <?php if (!empty($faviconUrl) && file_exists($_SERVER['DOCUMENT_ROOT'] . $faviconUrl)): ?>
    <link rel="icon" href="<?php echo htmlspecialchars($faviconUrl); ?>" type="image/x-icon">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <style>
        :root {
            --primary-color: <?php echo htmlspecialchars($primaryColor); ?>;
            --secondary-color: <?php echo htmlspecialchars($secondaryColor); ?>;
        }
        
        .site-title {
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: inline-block;
            padding: 10px 0;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="index.php">
                    <?php if ($logoExists): ?>
                        <img src="<?php echo htmlspecialchars($logoUrl); ?>" alt="<?php echo htmlspecialchars($siteTitle); ?>">
                    <?php else: ?>
                        <span class="site-title"><?php echo htmlspecialchars($siteTitle); ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="<?php echo $currentPage == 'home' ? 'active' : ''; ?>">Home</a></li>
                    <li><a href="index.php?page=search" class="<?php echo $currentPage == 'search' ? 'active' : ''; ?>">Search</a></li>
                    
                    <?php foreach ($navPages as $navPage): ?>
                        <?php if ($navPage['slug'] != 'home' && $navPage['slug'] != 'search'): ?>
                        <li><a href="index.php?page=<?php echo htmlspecialchars($navPage['slug']); ?>" class="<?php echo $currentPage == $navPage['slug'] ? 'active' : ''; ?>"><?php echo htmlspecialchars($navPage['title']); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    
                    <li><a href="index.php?page=contact" class="<?php echo $currentPage == 'contact' ? 'active' : ''; ?>">Contact</a></li>
                    
                    <?php if ($isLoggedIn): ?>
                        <li><a href="index.php?page=dashboard" class="<?php echo $currentPage == 'dashboard' ? 'active' : ''; ?>">Dashboard</a></li>
                        <?php if ($isAdmin): ?>
                            <li><a href="index.php?page=admin" class="<?php echo $currentPage == 'admin' ? 'active' : ''; ?>">Admin</a></li>
                        <?php endif; ?>
                        <li><a href="includes/logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="index.php?page=login" class="<?php echo $currentPage == 'login' ? 'active' : ''; ?>">Login</a></li>
                        <li><a href="index.php?page=register" class="<?php echo $currentPage == 'register' ? 'active' : ''; ?>">Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    
    <main>
        <div class="container">
            <?php if ($isAdmin): ?>
                <?php 
                if ($currentPage == 'home' && !$logoExists): 
                ?>
                <div class="alert alert-info">
                    <strong>Admin Notice:</strong> Your site logo is not displaying correctly. 
                    <a href="index.php?page=admin&action=settings">Go to Settings</a> to upload a logo.
                </div>
                <?php endif; ?>
            <?php endif; ?>
