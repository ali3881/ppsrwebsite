<div class="hero">
    <div class="hero-content">
        <h2>Welcome to PPSR Service</h2>
        <p>Search the Personal Property Securities Register (PPSR) to check if a vehicle has money owing on it or if it has been reported as written off or stolen.</p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="hero-buttons">
                <a href="index.php?page=search" class="btn btn-primary">Start a Search</a>
                <a href="index.php?page=register" class="btn btn-secondary">Register</a>
                <a href="index.php?page=login" class="btn btn-tertiary">Login</a>
            </div>
        <?php else: ?>
            <div class="hero-buttons">
                <a href="index.php?page=search" class="btn btn-primary">Start a Search</a>
                <a href="index.php?page=dashboard" class="btn btn-secondary">View Dashboard</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="features">
    <div class="feature">
        <div class="feature-icon">
            <i class="fas fa-search"></i>
        </div>
        <h3>Multiple Search Options</h3>
        <p>Search by Vehicle Identification Number (VIN) or Registration Number to get detailed information about a vehicle's history.</p>
    </div>
    
    <div class="feature">
        <div class="feature-icon">
            <i class="fas fa-file-pdf"></i>
        </div>
        <h3>Detailed Reports</h3>
        <p>Get comprehensive reports in PDF and HTML formats that you can download, print, or share.</p>
    </div>
    
    <div class="feature">
        <div class="feature-icon">
            <i class="fas fa-shield-alt"></i>
        </div>
        <h3>Secure & Reliable</h3>
        <p>Our service uses secure connections and follows Australian data privacy regulations to protect your information.</p>
    </div>
</div>

<div class="about-section">
    <h2>About PPSR</h2>
    <p>The Personal Property Securities Register (PPSR) is the single, national online database of security interests in personal property in Australia.</p>
    <p>Personal property generally includes all forms of property other than land, buildings and fixtures. Searching the PPSR before you buy could save you from buying something that has money owing on it.</p>
    <p>Our service provides an easy-to-use interface for searching the PPSR database and getting detailed reports about vehicles.</p>
</div>

<div class="how-it-works">
    <h2>How It Works</h2>
    
    <div class="steps">
        <div class="step">
            <div class="step-number">1</div>
            <h3>Start a Search</h3>
            <p>Begin a PPSR search as a guest or create an account to save your search history.</p>
        </div>
        
        <div class="step">
            <div class="step-number">2</div>
            <h3>Enter Vehicle Details</h3>
            <p>Enter either the Vehicle Identification Number (VIN) or Registration Number of the vehicle you want to check.</p>
        </div>
        
        <div class="step">
            <div class="step-number">3</div>
            <h3>Make Payment</h3>
            <p>Pay the search fee using our secure payment gateway.</p>
        </div>
        
        <div class="step">
            <div class="step-number">4</div>
            <h3>Get Your Report</h3>
            <p>View and download your detailed PPSR report in PDF or HTML format.</p>
        </div>
    </div>
</div>
