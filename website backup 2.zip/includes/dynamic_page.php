<div class="dynamic-page">
    <?php if (isset($pageData) && !empty($pageData)): ?>
        <h2><?php echo htmlspecialchars($pageData['title']); ?></h2>
        
        <?php if (!empty($pageData['meta_description'])): ?>
            <meta name="description" content="<?php echo htmlspecialchars($pageData['meta_description']); ?>">
        <?php endif; ?>
        
        <div class="page-content">
            <?php echo html_entity_decode($pageData['content']); ?>
        </div>
    <?php else: ?>
        <div class="error-message">
            <h2>Page Not Found</h2>
            <p>The requested page could not be found.</p>
            <a href="index.php" class="btn btn-primary">Return to Home</a>
        </div>
    <?php endif; ?>
</div>
