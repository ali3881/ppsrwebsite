<?php
/**
 * Connection Status Functions
 * 
 * This file contains functions for checking the status of various connections
 * used by the PPSR website, including database, PPSR API, and Stripe API.
 */

if (!function_exists('checkDatabaseConnection')) {
    /**
     * Check if the database connection is working
     * 
     * @return bool True if connected, false otherwise
     */
    function checkDatabaseConnection() {
        global $conn;
        
        if (!$conn) {
            return false;
        }
        
        try {
            $result = $conn->query("SELECT 1");
            return ($result !== false);
        } catch (Exception $e) {
            error_log("Database connection check failed: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('checkPpsrApiConnection')) {
    /**
     * Check if the PPSR API connection is working
     * 
     * @return bool True if connected, false otherwise
     */
    function checkPpsrApiConnection() {
        if (!extension_loaded('soap')) {
            return false;
        }
        
        if (!defined('PPSR_ACCOUNT_NAME') || !defined('PPSR_ACCOUNT_NUMBER') || 
            !defined('PPSR_USERNAME') || !defined('PPSR_PASSWORD') || 
            !defined('PPSR_ENDPOINT_URL')) {
            return false;
        }
        
        try {
            $wsdl = null; // No WSDL mode
            $options = [
                'location' => PPSR_ENDPOINT_URL,
                'uri' => 'http://afsa.gov.au/services/',
                'login' => PPSR_USERNAME,
                'password' => PPSR_PASSWORD,
                'connection_timeout' => 5, // Short timeout for connection check
                'exceptions' => true
            ];
            
            if (class_exists('SoapClient')) {
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("PPSR API connection check failed: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('checkStripeApiConnection')) {
    /**
     * Check if the Stripe API connection is working
     * 
     * @return bool True if connected, false otherwise
     */
    function checkStripeApiConnection() {
        if (!defined('STRIPE_PUBLIC_KEY') || !defined('STRIPE_SECRET_KEY') || 
            empty(STRIPE_PUBLIC_KEY) || empty(STRIPE_SECRET_KEY)) {
            return false;
        }
        
        if (!extension_loaded('curl')) {
            return false;
        }
        
        try {
            if (!class_exists('Stripe\Stripe')) {
                $ch = curl_init('https://api.stripe.com/v1/account');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_USERPWD, STRIPE_SECRET_KEY . ":");
                curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                $response = curl_exec($ch);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                return ($httpcode == 200 || $httpcode == 401);
            }
            
            return true;
        } catch (Exception $e) {
            error_log("Stripe API connection check failed: " . $e->getMessage());
            return false;
        }
    }
}
?>
