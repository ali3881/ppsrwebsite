<div class="dashboard-container">
    <h2>Dashboard</h2>
    
    <div class="dashboard-welcome">
        <h3>Welcome, <?php 
        $displayName = '';
        if (isset($_SESSION['display_name'])) {
            $displayName = $_SESSION['display_name'];
        } elseif (isset($_SESSION['name'])) {
            $displayName = $_SESSION['name'];
        } elseif (isset($_SESSION['first_name']) && isset($_SESSION['last_name'])) {
            $displayName = $_SESSION['first_name'] . ' ' . $_SESSION['last_name'];
        } elseif (isset($_SESSION['email'])) {
            $displayName = $_SESSION['email'];
        }
        echo htmlspecialchars($displayName);
        ?></h3>
        <p>Here you can view your search history and manage your account.</p>
    </div>
    
    <div class="dashboard-actions">
        <a href="index.php?page=search" class="btn btn-primary">New Search</a>
    </div>
    
    <div class="dashboard-content">
        <h3>Recent Searches</h3>
        
        <?php
        if (!function_exists('getUserSearchHistory')) {
            function getUserSearchHistory($userId) {
                global $conn;
                
                if (!$conn) {
                    return [];
                }
                
                $searches = [];
                
                try {
                    $tableCheck = $conn->query("SHOW TABLES LIKE 'searches'");
                    if ($tableCheck && $tableCheck->num_rows > 0) {
                        $stmt = $conn->prepare("SELECT * FROM searches WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
                        if ($stmt) {
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            
                            while ($row = $result->fetch_assoc()) {
                                $searches[] = $row;
                            }
                        }
                    }
                } catch (Exception $e) {
                    error_log("Error getting search history: " . $e->getMessage());
                }
                
                return $searches;
            }
        }
        
        $searches = getUserSearchHistory($_SESSION['user_id']);
        
        if (empty($searches)) {
            echo '<div class="alert alert-info">You have not performed any searches yet.</div>';
        } else {
            echo '<div class="search-history">';
            echo '<table class="table">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Date</th>';
            echo '<th>Search Type</th>';
            echo '<th>VIN/Registration</th>';
            echo '<th>Status</th>';
            echo '<th>Actions</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            foreach ($searches as $search) {
                echo '<tr>';
                echo '<td>' . date('Y-m-d H:i:s', strtotime($search['created_at'])) . '</td>';
                echo '<td>' . htmlspecialchars(isset($search['search_type']) ? ucfirst($search['search_type']) : 'VIN') . '</td>';
                
                if (isset($search['search_type']) && $search['search_type'] == 'registration') {
                    echo '<td>' . htmlspecialchars(isset($search['rego']) ? $search['rego'] : 'N/A') . '</td>';
                } else {
                    echo '<td>' . htmlspecialchars(isset($search['vin']) ? $search['vin'] : 'N/A') . '</td>';
                }
                
                echo '<td>' . htmlspecialchars(isset($search['status']) ? $search['status'] : 'Completed') . '</td>';
                echo '<td>';
                
                if (isset($search['pdf_report']) && !empty($search['pdf_report'])) {
                    echo '<a href="download.php?file=' . htmlspecialchars($search['pdf_report']) . '" class="btn btn-sm btn-primary" target="_blank">PDF</a> ';
                }
                
                if (isset($search['html_report']) && !empty($search['html_report'])) {
                    echo '<a href="download.php?file=' . htmlspecialchars($search['html_report']) . '" class="btn btn-sm btn-secondary" target="_blank">HTML</a> ';
                }
                
                echo '<a href="index.php?page=search_details&id=' . $search['id'] . '" class="btn btn-sm btn-tertiary">Details</a>';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        }
        ?>
    </div>
    
    <div class="dashboard-section">
        <h3>Account Information</h3>
        
        <?php
        if (!function_exists('getUserById')) {
            function getUserById($userId) {
                global $conn;
                
                if (!$conn) {
                    return [
                        'email' => isset($_SESSION['email']) ? $_SESSION['email'] : 'Unknown',
                        'created_at' => date('Y-m-d')
                    ];
                }
                
                $user = [
                    'email' => isset($_SESSION['email']) ? $_SESSION['email'] : 'Unknown',
                    'created_at' => date('Y-m-d')
                ];
                
                try {
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
                    if ($stmt) {
                        $stmt->bind_param("i", $userId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            $user = $result->fetch_assoc();
                        }
                    }
                } catch (Exception $e) {
                    error_log("Error getting user by ID: " . $e->getMessage());
                }
                
                return $user;
            }
        }
        
        $user = getUserById($_SESSION['user_id']);
        ?>
        
        <div class="account-info">
            <p><strong>Name:</strong> <?php 
            $displayName = '';
            if (isset($user['name'])) {
                $displayName = $user['name'];
            } elseif (isset($user['first_name']) && isset($user['last_name'])) {
                $displayName = $user['first_name'] . ' ' . $user['last_name'];
            } elseif (isset($_SESSION['display_name'])) {
                $displayName = $_SESSION['display_name'];
            } elseif (isset($_SESSION['email'])) {
                $displayName = $_SESSION['email'];
            }
            echo htmlspecialchars($displayName);
            ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars(isset($user['email']) ? $user['email'] : 'Unknown'); ?></p>
            <p><strong>Account Created:</strong> <?php echo isset($user['created_at']) ? date('Y-m-d', strtotime($user['created_at'])) : date('Y-m-d'); ?></p>
        </div>
        
        <div class="account-actions">
            <a href="index.php?page=edit_profile" class="btn btn-secondary">Edit Profile</a>
            <a href="index.php?page=change_password" class="btn btn-secondary">Change Password</a>
        </div>
    </div>
</div>
