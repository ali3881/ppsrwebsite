        </div>
    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            <p>This service provides access to the Personal Property Securities Register (PPSR) in Australia.</p>
        </div>
    </footer>
    <script src="js/main.js"></script>
</body>
</html>
