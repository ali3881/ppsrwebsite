<?php
function isAdmin($userId) {
    global $conn;
    
    if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
        return true;
    }
    
    if (isset($_SESSION['email']) && $_SESSION['email'] == 'admin@example.com') {
        $_SESSION['is_admin'] = 1;
        return true;
    }
    
    if ($conn) {
        try {
            $adminCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
            if ($adminCheck && $adminCheck->num_rows > 0) {
                $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result && $result->num_rows === 1) {
                        $user = $result->fetch_assoc();
                        $_SESSION['is_admin'] = $user['is_admin'];
                        return $user['is_admin'] == 1;
                    }
                }
            }
            
            $roleCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
            if ($roleCheck && $roleCheck->num_rows > 0) {
                $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result && $result->num_rows === 1) {
                        $user = $result->fetch_assoc();
                        $isAdmin = ($user['role'] == 'admin');
                        $_SESSION['is_admin'] = $isAdmin ? 1 : 0;
                        return $isAdmin;
                    }
                }
            }
            
            if ($userId == 1) {
                $_SESSION['is_admin'] = 1;
                return true;
            }
        } catch (Exception $e) {
            error_log("Error checking admin status: " . $e->getMessage());
        }
    }
    
    return false;
}
