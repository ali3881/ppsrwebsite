<?php
define('DB_HOST', 'localhost'); // Your database host
define('DB_USER', 'ppsrsecuritychec_ppsr_db'); // Updated database username
define('DB_PASS', 'Qwazwsxedc12'); // Updated database password
define('DB_NAME', 'ppsrsecuritychec_ppsr_db'); // Updated database name

define('PPSR_ACCOUNT_NAME', 'ppsrseccheck');
define('PPSR_ACCOUNT_NUMBER', '101321866');
define('PPSR_USERNAME', 'pps834');
define('PPSR_PASSWORD', 'M4GZ3RPYLFN6');
define('PPSR_ENDPOINT', 'https://ppsr.gov.au/b2g/production');
define('PPSR_SOAP_ACTION', 'http://afsa.gov.au/services/SearchByVIN');

define('PAYMENT_GATEWAY', 'stripe'); // Only Stripe is supported
define('STRIPE_PUBLIC_KEY', 'pk_live_51RELMbFstInCsLbCZQIc3qa0kymaSbwtXld8hn00vL1XkHG9qCA1CzYeBKYkkoAtmPgJPxG02HHC6MPCEN6ZIaTU008WcUvxAY');
define('STRIPE_SECRET_KEY', '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');

define('SITE_NAME', 'PPSR Australia');
define('SITE_DESCRIPTION', 'Australian Personal Property Securities Register Search Service');
define('SITE_URL', 'https://ppsrsecuritycheck.com.au'); // Using HTTPS
define('ADMIN_EMAIL', 'admin@example.com');

define('PRIMARY_COLOR', '#0056b3');
define('SECONDARY_COLOR', '#6c757d');
define('BACKGROUND_COLOR', '#f8f9fa');
define('TEXT_COLOR', '#212529');
define('LOGO_PATH', '');
define('FAVICON_PATH', '');
define('CUSTOM_CSS', '');

define('SEARCH_FEE', '1');
define('USE_REAL_XML_DATA', '1'); // Default to mock data

if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    if (!strpos($_SERVER['HTTP_HOST'], 'localhost') && !strpos($_SERVER['HTTP_HOST'], '127.0.0.1')) {
        $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: ' . $redirect);
        exit();
    }
}

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    error_log("Database connection failed: " . $e->getMessage());
    
    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 20px; margin: 20px; border-radius: 5px; border: 1px solid #f5c6cb;'>";
    echo "<h3>Database Connection Error</h3>";
    echo "<p>There was a problem connecting to the database. Please check your database credentials in the config.php file.</p>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "</div>";
    exit();
}

if (defined('LOGO_PATH') && !empty(LOGO_PATH)) {
    define('LOGO', LOGO_PATH);
} else {
    define('LOGO', '../uploads/logos/logo_1746677589.png');
}

if (defined('FAVICON_PATH') && !empty(FAVICON_PATH)) {
    define('FAVICON', FAVICON_PATH);
} else {
    define('FAVICON', '../uploads/favicons/favicon_1746677589.ico');
}
?>
