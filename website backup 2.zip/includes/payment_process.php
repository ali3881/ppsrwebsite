<?php
/**
 * Payment Processing
 * 
 * This file handles the payment processing for PPSR searches.
 */

require_once 'config.php';
require_once 'functions.php';
require_once 'stripe_payment.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php?page=login');
    exit;
}

initStripe();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['search_vin'])) {
        $_SESSION['error'] = 'No VIN found for search. Please try again.';
        header('Location: index.php?page=search');
        exit;
    }
    
    $vin = $_SESSION['search_vin'];
    $userId = $_SESSION['user_id'];
    
    $searchFee = 25.00; // AUD
    
    $paymentIntent = createPaymentIntent($searchFee, $vin, $userId);
    
    if (!$paymentIntent['success']) {
        $_SESSION['error'] = 'Error creating payment: ' . $paymentIntent['error'];
        header('Location: index.php?page=search');
        exit;
    }
    
    $_SESSION['payment_id'] = $paymentIntent['payment_id'];
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment - <?php echo SITE_NAME; ?></title>
        <link rel="stylesheet" href="css/style.css">
        <script src="https://js.stripe.com/v3/"></script>
    </head>
    <body>
        <?php include 'header.php'; ?>
        
        <div class="container">
            <div class="payment-container">
                <h2>Payment for PPSR Search</h2>
                
                <div class="payment-details">
                    <p><strong>VIN:</strong> <?php echo htmlspecialchars($vin); ?></p>
                    <p><strong>Amount:</strong> $<?php echo number_format($searchFee, 2); ?> AUD</p>
                </div>
                
                <div class="payment-form">
                    <form id="payment-form">
                        <div class="form-group">
                            <label for="card-element">Credit or Debit Card</label>
                            <div id="card-element">
                                <!-- Stripe Card Element will be inserted here -->
                            </div>
                            <div id="card-errors" role="alert"></div>
                        </div>
                        
                        <button type="submit" id="submit-button" class="btn btn-primary">Pay Now</button>
                    </form>
                </div>
                
                <div class="payment-info">
                    <p>Your payment is processed securely through Stripe. We do not store your card details.</p>
                </div>
            </div>
        </div>
        
        <?php include 'footer.php'; ?>
        
        <script>
            var stripe = Stripe('<?php echo STRIPE_PUBLIC_KEY; ?>');
            var elements = stripe.elements();
            
            var card = elements.create('card');
            
            card.mount('#card-element');
            
            card.addEventListener('change', function(event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
            
            var form = document.getElementById('payment-form');
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                
                var submitButton = document.getElementById('submit-button');
                submitButton.disabled = true;
                submitButton.textContent = 'Processing...';
                
                
                setTimeout(function() {
                    window.location.href = 'index.php?page=payment_success';
                }, 2000);
            });
        </script>
    </body>
    </html>
    <?php
    exit;
} else {
    header('Location: index.php?page=search');
    exit;
}
?>
