<?php
/**
 * SOAP Client for PPSR API Integration
 * 
 * This file handles the SOAP API integration with the PPSR database
 * for VIN searches, registration number searches, and other PPSR-related operations.
 */

/**
 * Performs a VIN search using the PPSR SOAP API
 * 
 * @param string $vin The Vehicle Identification Number to search for
 * @param int $userId The ID of the user performing the search
 * @return array The search result data
 */
function searchPpsrByVin($vin) {
    global $conn;
    
    $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    
    return performVinSearch($vin, $userId);
}

/**
 * Performs a Registration Number search using the PPSR SOAP API
 * 
 * @param string $rego The Registration Number to search for
 * @param string $state The state or territory of registration
 * @return array The search result data
 */
function searchPpsrByRego($rego, $state) {
    global $conn;
    
    $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    
    return performRegoSearch($rego, $state, $userId);
}

/**
 * Performs a Registration Number search using the PPSR SOAP API
 * 
 * @param string $rego The Registration Number to search for
 * @param string $state The state or territory of registration
 * @param int $userId The ID of the user performing the search
 * @return array The search result data
 */
function performRegoSearch($rego, $state, $userId) {
    global $conn;
    
    $requestData = json_encode(['rego' => $rego, 'state' => $state]);
    $stmt = $conn->prepare("INSERT INTO api_logs (user_id, request_type, request_data, status) VALUES (?, 'REGO_SEARCH', ?, 'PENDING')");
    $stmt->bind_param("is", $userId, $requestData);
    $stmt->execute();
    $logId = $stmt->insert_id;
    
    try {
        $options = [
            'trace' => 1,
            'exceptions' => true,
            'login' => PPSR_USERNAME,
            'password' => PPSR_PASSWORD
        ];
        
        $client = new SoapClient(PPSR_ENDPOINT, $options);
        
        $headers = [
            'AccountName' => PPSR_ACCOUNT_NAME,
            'AccountNumber' => PPSR_ACCOUNT_NUMBER,
            'Action' => 'http://afsa.gov.au/services/SearchByRegistration'
        ];
        
        $soapHeaders = new SoapHeader('http://afsa.gov.au/services/', 'AuthenticationHeader', $headers);
        $client->__setSoapHeaders($soapHeaders);
        
        $requestParams = [
            'RegistrationNumber' => $rego,
            'State' => $state
        ];
        
        $response = $client->SearchByRegistration($requestParams);
        
        $responseData = json_encode($response);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'SUCCESS' WHERE id = ?");
        $stmt->bind_param("si", $responseData, $logId);
        $stmt->execute();
        
        return [
            'success' => true,
            'data' => $response,
            'raw_response' => $responseData
        ];
    } catch (SoapFault $fault) {
        $errorMessage = "SOAP Fault: " . $fault->getMessage();
        $errorData = json_encode([
            'faultcode' => $fault->faultcode,
            'faultstring' => $fault->faultstring,
            'detail' => isset($fault->detail) ? $fault->detail : null
        ]);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'ERROR' WHERE id = ?");
        $stmt->bind_param("si", $errorData, $logId);
        $stmt->execute();
        
        error_log("PPSR SOAP Error: " . $errorMessage);
        
        return [
            'success' => false,
            'error' => $errorMessage,
            'error_data' => $errorData
        ];
    } catch (Exception $e) {
        $errorMessage = "Error: " . $e->getMessage();
        $errorData = json_encode([
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'trace' => $e->getTraceAsString()
        ]);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'ERROR' WHERE id = ?");
        $stmt->bind_param("si", $errorData, $logId);
        $stmt->execute();
        
        error_log("PPSR API Error: " . $errorMessage);
        
        return [
            'success' => false,
            'error' => $errorMessage,
            'error_data' => $errorData
        ];
    }
}

/**
 * Performs a VIN search using the PPSR SOAP API
 * 
 * @param string $vin The Vehicle Identification Number to search for
 * @param int $userId The ID of the user performing the search
 * @return array The search result data
 */
function performVinSearch($vin, $userId) {
    global $conn;
    
    $requestData = json_encode(['vin' => $vin]);
    $stmt = $conn->prepare("INSERT INTO api_logs (user_id, request_type, request_data, status) VALUES (?, 'VIN_SEARCH', ?, 'PENDING')");
    $stmt->bind_param("is", $userId, $requestData);
    $stmt->execute();
    $logId = $stmt->insert_id;
    
    try {
        $options = [
            'trace' => 1,
            'exceptions' => true,
            'login' => PPSR_USERNAME,
            'password' => PPSR_PASSWORD
        ];
        
        $client = new SoapClient(PPSR_ENDPOINT, $options);
        
        $headers = [
            'AccountName' => PPSR_ACCOUNT_NAME,
            'AccountNumber' => PPSR_ACCOUNT_NUMBER,
            'Action' => PPSR_SOAP_ACTION
        ];
        
        $soapHeaders = new SoapHeader('http://afsa.gov.au/services/', 'AuthenticationHeader', $headers);
        $client->__setSoapHeaders($soapHeaders);
        
        $requestParams = [
            'VIN' => $vin
        ];
        
        $response = $client->SearchByVIN($requestParams);
        
        $responseData = json_encode($response);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'SUCCESS' WHERE id = ?");
        $stmt->bind_param("si", $responseData, $logId);
        $stmt->execute();
        
        return [
            'success' => true,
            'data' => $response,
            'raw_response' => $responseData
        ];
    } catch (SoapFault $fault) {
        $errorMessage = "SOAP Fault: " . $fault->getMessage();
        $errorData = json_encode([
            'faultcode' => $fault->faultcode,
            'faultstring' => $fault->faultstring,
            'detail' => isset($fault->detail) ? $fault->detail : null
        ]);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'ERROR' WHERE id = ?");
        $stmt->bind_param("si", $errorData, $logId);
        $stmt->execute();
        
        error_log("PPSR SOAP Error: " . $errorMessage);
        
        return [
            'success' => false,
            'error' => $errorMessage,
            'error_data' => $errorData
        ];
    } catch (Exception $e) {
        $errorMessage = "Error: " . $e->getMessage();
        $errorData = json_encode([
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'trace' => $e->getTraceAsString()
        ]);
        
        $stmt = $conn->prepare("UPDATE api_logs SET response_data = ?, status = 'ERROR' WHERE id = ?");
        $stmt->bind_param("si", $errorData, $logId);
        $stmt->execute();
        
        error_log("PPSR API Error: " . $errorMessage);
        
        return [
            'success' => false,
            'error' => $errorMessage,
            'error_data' => $errorData
        ];
    }
}

/**
 * Generates a PDF report from search results
 * 
 * @param array $searchData The search result data
 * @param string $vin The Vehicle Identification Number
 * @param int $searchId The ID of the search record
 * @return string The path to the generated PDF file
 */
function generatePdfReport($searchData, $vin, $searchId) {
    
    $reportDir = __DIR__ . '/../reports';
    if (!file_exists($reportDir)) {
        mkdir($reportDir, 0755, true);
    }
    
    $filename = 'report_' . $searchId . '_' . time() . '.pdf';
    $filepath = $reportDir . '/' . $filename;
    
    $content = '<html><head><title>PPSR Report: ' . $vin . '</title></head><body>';
    $content .= '<h1>PPSR Vehicle Search Report</h1>';
    $content .= '<p>VIN: ' . htmlspecialchars($vin) . '</p>';
    $content .= '<p>Search Date: ' . date('Y-m-d H:i:s') . '</p>';
    
    $content .= '<h2>Search Results</h2>';
    $content .= '<pre>' . print_r($searchData, true) . '</pre>';
    
    $content .= '</body></html>';
    
    file_put_contents($filepath, $content);
    
    return $filepath;
}

/**
 * Generates an HTML report from search results
 * 
 * @param array $searchData The search result data
 * @param string $vin The Vehicle Identification Number
 * @param int $searchId The ID of the search record
 * @return string The path to the generated HTML file
 */
function generateHtmlReport($searchData, $vin, $searchId) {
    $reportDir = __DIR__ . '/../reports';
    if (!file_exists($reportDir)) {
        mkdir($reportDir, 0755, true);
    }
    
    $filename = 'report_' . $searchId . '_' . time() . '.html';
    $filepath = $reportDir . '/' . $filename;
    
    $content = '<!DOCTYPE html>
<html>
<head>
    <title>PPSR Report: ' . $vin . '</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .report-header {
            background-color: #f5f5f5;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .report-section {
            margin-bottom: 30px;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #3498db;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="report-header">
        <h1>PPSR Vehicle Search Report</h1>
        <p><strong>VIN:</strong> ' . htmlspecialchars($vin) . '</p>
        <p><strong>Search Date:</strong> ' . date('Y-m-d H:i:s') . '</p>
        <p><strong>Report ID:</strong> ' . $searchId . '</p>
    </div>
    
    <div class="report-section">
        <h2>Vehicle Information</h2>
        <table>
            <tr>
                <th>VIN</th>
                <td>' . htmlspecialchars($vin) . '</td>
            </tr>
            <!-- In a real implementation, this would include actual vehicle data -->
            <tr>
                <th>Make</th>
                <td>Sample Make</td>
            </tr>
            <tr>
                <th>Model</th>
                <td>Sample Model</td>
            </tr>
            <tr>
                <th>Year</th>
                <td>2023</td>
            </tr>
        </table>
    </div>
    
    <div class="report-section">
        <h2>Security Interests</h2>
        <table>
            <tr>
                <th>Registration Number</th>
                <th>Secured Party</th>
                <th>Registration Date</th>
                <th>Status</th>
            </tr>
            <!-- Sample data - would be populated from actual API response -->
            <tr>
                <td>123456789</td>
                <td>Sample Bank Ltd</td>
                <td>2023-01-15</td>
                <td>Active</td>
            </tr>
        </table>
    </div>
    
    <div class="report-section">
        <h2>Written-Off Vehicle Register</h2>
        <p>No written-off records found for this vehicle.</p>
    </div>
    
    <div class="report-section">
        <h2>Stolen Vehicle Check</h2>
        <p>This vehicle is not currently recorded as stolen.</p>
    </div>
    
    <div class="footer">
        <p>This report was generated by PPSR Service on ' . date('Y-m-d H:i:s') . '</p>
        <p>The information contained in this report is based on data provided by the Personal Property Securities Register (PPSR).</p>
        <p>© ' . date('Y') . ' PPSR Service. All rights reserved.</p>
    </div>
</body>
</html>';
    
    file_put_contents($filepath, $content);
    
    return $filepath;
}
/**
 * Generates a PDF report for registration number search results
 * 
 * @param int $searchId The ID of the search record
 * @return string The path to the generated PDF file
 */
function generateRegoReport($searchId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM searches WHERE id = ?");
    $stmt->bind_param("i", $searchId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return false;
    }
    
    $searchData = $result->fetch_assoc();
    $rego = $searchData['rego'];
    $state = $searchData['state'];
    $responseData = json_decode($searchData['response_data'], true);
    
    $reportDir = __DIR__ . '/../reports';
    if (!file_exists($reportDir)) {
        mkdir($reportDir, 0755, true);
    }
    
    $filename = 'rego_report_' . $searchId . '_' . time() . '.pdf';
    $filepath = $reportDir . '/' . $filename;
    
    $content = '<html><head><title>PPSR Report: ' . $rego . ' (' . $state . ')</title></head><body>';
    $content .= '<h1>PPSR Vehicle Search Report</h1>';
    $content .= '<p>Registration Number: ' . htmlspecialchars($rego) . '</p>';
    $content .= '<p>State/Territory: ' . htmlspecialchars($state) . '</p>';
    $content .= '<p>Search Date: ' . date('Y-m-d H:i:s') . '</p>';
    
    $content .= '<h2>Search Results</h2>';
    $content .= '<pre>' . print_r($responseData, true) . '</pre>';
    
    $content .= '</body></html>';
    
    file_put_contents($filepath, $content);
    
    return $filepath;
}

/**
 * Generates an HTML report for registration number search results
 * 
 * @param int $searchId The ID of the search record
 * @return string The path to the generated HTML file
 */
function generateRegoHtmlReport($searchId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT * FROM searches WHERE id = ?");
    $stmt->bind_param("i", $searchId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return false;
    }
    
    $searchData = $result->fetch_assoc();
    $rego = $searchData['rego'];
    $state = $searchData['state'];
    $responseData = json_decode($searchData['response_data'], true);
    
    $reportDir = __DIR__ . '/../reports';
    if (!file_exists($reportDir)) {
        mkdir($reportDir, 0755, true);
    }
    
    $filename = 'rego_report_' . $searchId . '_' . time() . '.html';
    $filepath = $reportDir . '/' . $filename;
    
    $content = '<!DOCTYPE html>
<html>
<head>
    <title>PPSR Report: ' . $rego . ' (' . $state . ')</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .report-header {
            background-color: #f5f5f5;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        .report-section {
            margin-bottom: 30px;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #3498db;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            font-size: 0.9em;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="report-header">
        <h1>PPSR Vehicle Search Report</h1>
        <p><strong>Registration Number:</strong> ' . htmlspecialchars($rego) . '</p>
        <p><strong>State/Territory:</strong> ' . htmlspecialchars($state) . '</p>
        <p><strong>Search Date:</strong> ' . date('Y-m-d H:i:s') . '</p>
        <p><strong>Report ID:</strong> ' . $searchId . '</p>
    </div>
    
    <div class="report-section">
        <h2>Vehicle Information</h2>
        <table>
            <tr>
                <th>Registration Number</th>
                <td>' . htmlspecialchars($rego) . '</td>
            </tr>
            <tr>
                <th>State/Territory</th>
                <td>' . htmlspecialchars($state) . '</td>
            </tr>
            <!-- In a real implementation, this would include actual vehicle data -->
            <tr>
                <th>Make</th>
                <td>Sample Make</td>
            </tr>
            <tr>
                <th>Model</th>
                <td>Sample Model</td>
            </tr>
            <tr>
                <th>Year</th>
                <td>2023</td>
            </tr>
        </table>
    </div>
    
    <div class="report-section">
        <h2>Security Interests</h2>
        <table>
            <tr>
                <th>Registration Number</th>
                <th>Secured Party</th>
                <th>Registration Date</th>
                <th>Status</th>
            </tr>
            <!-- Sample data - would be populated from actual API response -->
            <tr>
                <td>123456789</td>
                <td>Sample Bank Ltd</td>
                <td>2023-01-15</td>
                <td>Active</td>
            </tr>
        </table>
    </div>
    
    <div class="report-section">
        <h2>Written-Off Vehicle Register</h2>
        <p>No written-off records found for this vehicle.</p>
    </div>
    
    <div class="report-section">
        <h2>Stolen Vehicle Check</h2>
        <p>This vehicle is not currently recorded as stolen.</p>
    </div>
    
    <div class="footer">
        <p>This report was generated by PPSR Service on ' . date('Y-m-d H:i:s') . '</p>
        <p>The information contained in this report is based on data provided by the Personal Property Securities Register (PPSR).</p>
        <p>© ' . date('Y') . ' PPSR Service. All rights reserved.</p>
    </div>
</body>
</html>';
    
    file_put_contents($filepath, $content);
    
    return $filepath;
}
?>
