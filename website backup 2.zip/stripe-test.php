<?php
/**
 * Stripe SSL Connection Test Script
 * 
 * This script tests the Stripe API connection with proper SSL certificate verification.
 * It helps diagnose issues with the Stripe SSL integration.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stripe SSL Connection Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            padding: 0;
            color: #333;
        }
        h1, h2, h3 {
            color: #0056b3;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background-color: #fff3cd;
            color: #856404;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ffeeba;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #bee5eb;
        }
        pre {
            background-color: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
        .test-section {
            margin-bottom: 30px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Stripe SSL Connection Test</h1>
        
        <div class="info">
            <p>This script tests the Stripe API connection with proper SSL certificate verification. It helps diagnose issues with the Stripe SSL integration.</p>
        </div>
        
        <?php
        echo '<div class="test-section">';
        echo '<h2>Test 1: PHP Environment</h2>';
        
        $phpVersion = phpversion();
        echo '<p>PHP Version: ' . $phpVersion . '</p>';
        
        if (version_compare($phpVersion, '7.4.0', '<')) {
            echo '<div class="warning">PHP version is below 7.4.0. Stripe recommends PHP 7.4 or higher.</div>';
        } else {
            echo '<div class="success">PHP version is 7.4 or higher.</div>';
        }
        
        $requiredExtensions = ['curl', 'json', 'mbstring', 'openssl'];
        $missingExtensions = [];
        
        foreach ($requiredExtensions as $extension) {
            if (!extension_loaded($extension)) {
                $missingExtensions[] = $extension;
            }
        }
        
        if (empty($missingExtensions)) {
            echo '<div class="success">All required PHP extensions are installed.</div>';
        } else {
            echo '<div class="error">Missing required PHP extensions: ' . implode(', ', $missingExtensions) . '</div>';
        }
        
        echo '</div>';
        
        echo '<div class="test-section">';
        echo '<h2>Test 2: SSL Configuration</h2>';
        
        $opensslVersion = OPENSSL_VERSION_TEXT;
        echo '<p>OpenSSL Version: ' . $opensslVersion . '</p>';
        
        $caCertPath = __DIR__ . '/includes/cacert.pem';
        
        if (file_exists($caCertPath)) {
            echo '<div class="success">CA certificate bundle found at: ' . $caCertPath . '</div>';
            
            putenv("CURL_CA_BUNDLE=$caCertPath");
            ini_set('curl.cainfo', $caCertPath);
            ini_set('openssl.cafile', $caCertPath);
            
            echo '<div class="success">CA certificate bundle configured for cURL and OpenSSL.</div>';
        } else {
            echo '<div class="error">CA certificate bundle not found at: ' . $caCertPath . '</div>';
            echo '<p>Please make sure the cacert.pem file exists in the includes directory.</p>';
        }
        
        $ch = curl_init('https://api.stripe.com/v1/');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        if (file_exists($caCertPath)) {
            curl_setopt($ch, CURLOPT_CAINFO, $caCertPath);
        }
        
        $result = curl_exec($ch);
        $error = curl_error($ch);
        $info = curl_getinfo($ch);
        
        if ($result !== false) {
            echo '<div class="success">SSL connection to Stripe API successful!</div>';
            echo '<p>HTTP Status Code: ' . $info['http_code'] . '</p>';
        } else {
            echo '<div class="error">SSL connection to Stripe API failed: ' . $error . '</div>';
            echo '<p>HTTP Status Code: ' . $info['http_code'] . '</p>';
            
            echo '<h3>Error Details:</h3>';
            echo '<pre>';
            print_r($info);
            echo '</pre>';
        }
        
        curl_close($ch);
        
        echo '</div>';
        
        echo '<div class="test-section">';
        echo '<h2>Test 3: Stripe Library</h2>';
        
        $stripePath = __DIR__ . '/includes/stripe-php/init.php';
        
        if (file_exists($stripePath)) {
            echo '<div class="success">Stripe library found at: ' . $stripePath . '</div>';
            
            try {
                require_once $stripePath;
                echo '<div class="success">Stripe library loaded successfully.</div>';
            } catch (Exception $e) {
                echo '<div class="error">Error loading Stripe library: ' . $e->getMessage() . '</div>';
            }
        } else {
            echo '<div class="error">Stripe library not found at: ' . $stripePath . '</div>';
            echo '<p>Please make sure the stripe-php directory exists in the includes directory.</p>';
            
            $composerPath = __DIR__ . '/vendor/autoload.php';
            
            if (file_exists($composerPath)) {
                echo '<div class="info">Composer autoload.php found at: ' . $composerPath . '</div>';
                
                try {
                    require_once $composerPath;
                    echo '<div class="success">Composer autoload.php loaded successfully.</div>';
                    
                    if (class_exists('\\Stripe\\Stripe')) {
                        echo '<div class="success">Stripe class found in Composer packages.</div>';
                    } else {
                        echo '<div class="error">Stripe class not found in Composer packages.</div>';
                    }
                } catch (Exception $e) {
                    echo '<div class="error">Error loading Composer autoload.php: ' . $e->getMessage() . '</div>';
                }
            } else {
                echo '<div class="warning">Composer autoload.php not found at: ' . $composerPath . '</div>';
            }
            
            echo '</div>';
            echo '<div class="error">Cannot continue without Stripe library.</div>';
            echo '</div></body></html>';
            exit;
        }
        
        echo '</div>';
        
        echo '<div class="test-section">';
        echo '<h2>Test 4: Stripe API Keys</h2>';
        
        if (!defined('STRIPE_PUBLIC_KEY')) {
            define('STRIPE_PUBLIC_KEY', 'pk_test_51RELMnFjuaRQIb2ZvNSjHjmT1WiRudPCjsXzonPNbETjW8fCu4Ge3nwajCBdMp4AG1cJHaS4be6Kt7LTpFsR4eWh00OujzBQNC');
        }
        
        if (!defined('STRIPE_SECRET_KEY')) {
            define('STRIPE_SECRET_KEY', 'sk_test_51RELMnFjuaRQIb2ZfuhokP8oejQvptz9OnS2PFEeihhGkPVUcMqoxw77fj2j1iUBYPU109E6jdmfffUfuWA9Z5QF00KHe076ji');
        }
        
        $publicKey = STRIPE_PUBLIC_KEY;
        $secretKey = STRIPE_SECRET_KEY;
        
        if (strpos($publicKey, 'pk_') === 0) {
            echo '<div class="success">Public key format is valid: ' . substr($publicKey, 0, 8) . '...</div>';
        } else {
            echo '<div class="error">Public key format is invalid: ' . substr($publicKey, 0, 8) . '...</div>';
        }
        
        if (strpos($secretKey, 'sk_') === 0) {
            echo '<div class="success">Secret key format is valid: ' . substr($secretKey, 0, 8) . '...</div>';
        } else {
            echo '<div class="error">Secret key format is invalid: ' . substr($secretKey, 0, 8) . '...</div>';
        }
        
        echo '</div>';
        
        echo '<div class="test-section">';
        echo '<h2>Test 5: Stripe API Connection</h2>';
        
        try {
            \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
            
            $curlOptions = [];
            
            if (file_exists($caCertPath)) {
                $curlOptions[CURLOPT_CAINFO] = $caCertPath;
                $curlOptions[CURLOPT_SSL_VERIFYPEER] = true;
                $curlOptions[CURLOPT_SSL_VERIFYHOST] = 2;
            }
            
            if (!empty($curlOptions)) {
                $curl = new \Stripe\HttpClient\CurlClient($curlOptions);
                \Stripe\ApiRequestor::setHttpClient($curl);
            }
            
            echo '<div class="success">Stripe API key set successfully with proper SSL configuration.</div>';
            
            $balance = \Stripe\Balance::retrieve();
            
            echo '<div class="success">Stripe API connection successful!</div>';
            echo '<pre>' . print_r($balance->toArray(), true) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="error">Stripe API connection failed: ' . $e->getMessage() . '</div>';
            
            echo '<h3>Error Details:</h3>';
            echo '<pre>';
            print_r($e);
            echo '</pre>';
        }
        
        echo '</div>';
        
        echo '<div class="test-section">';
        echo '<h2>Test 6: Create Payment Intent</h2>';
        
        try {
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => 2500, // $25.00
                'currency' => 'aud',
                'description' => 'PPSR Search Test',
                'metadata' => [
                    'identifier' => 'TEST123',
                    'user_id' => 'test'
                ]
            ]);
            
            echo '<div class="success">Payment intent created successfully!</div>';
            echo '<pre>' . print_r($paymentIntent->toArray(), true) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="error">Payment intent creation failed: ' . $e->getMessage() . '</div>';
            
            echo '<h3>Error Details:</h3>';
            echo '<pre>';
            print_r($e);
            echo '</pre>';
        }
        
        echo '</div>';
        ?>
        
        <div class="info">
            <h3>Next Steps</h3>
            <p>If all tests passed, the Stripe API is working correctly with proper SSL certificate verification. If any tests failed, please check the error messages and fix the issues.</p>
            <p>Common issues:</p>
            <ul>
                <li>Missing CA certificate bundle - Make sure cacert.pem is in the includes directory</li>
                <li>Missing PHP extensions - Make sure curl, json, mbstring, and openssl are installed</li>
                <li>Invalid API keys - Make sure the API keys are correct</li>
                <li>Network issues - Make sure your server can connect to api.stripe.com</li>
            </ul>
        </div>
    </div>
</body>
</html>
