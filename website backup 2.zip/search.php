<div class="search-container">
    <h2>PPSR Vehicle Search</h2>
    
    <?php if (!isset($_SESSION['user_id'])): ?>
    <div class="guest-notice">
        <p>You are searching as a guest. Your search results will not be saved to an account.</p>
        <p>Already have an account? <a href="index.php?page=login">Login</a> or <a href="index.php?page=register">Register</a> to save your search history.</p>
    </div>
    <?php endif; ?>
    
    <?php
    $searchCompleted = false;
    $searchResults = null;
    $searchError = null;
    $searchId = null;
    $searchType = null;
    $vin = null;
    $rego = null;
    $state = null;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $searchInput = sanitizeInput($_POST['search_input']);
        $state = isset($_POST['state']) ? sanitizeInput($_POST['state']) : '';
        
        if (preg_match('/^[A-HJ-NPR-Z0-9]{17}$/i', $searchInput)) {
            $searchType = 'vin';
            $vin = $searchInput;
            $_SESSION['current_vin'] = $vin;
            
            if (empty($vin)) {
                $searchError = "Vehicle identifier is required";
            }
        } else {
            $searchType = 'rego';
            $rego = $searchInput;
            $_SESSION['current_rego'] = $rego;
            $_SESSION['current_state'] = $state;
            
            if (empty($rego)) {
                $searchError = "Vehicle identifier is required";
            }
            if (empty($state)) {
                $searchError = "State/Territory is required for registration number searches";
            }
        }
        
        if (!$searchError) {
            $paymentMethod = sanitizeInput($_POST['payment_method']);
            $paymentData = [];
            
            if ($paymentMethod === 'stripe') {
                $paymentData['payment_method_id'] = sanitizeInput($_POST['stripe_payment_method_id']);
            }
            
            $searchFee = defined('SEARCH_FEE') ? SEARCH_FEE : 25.00;
            
            $paymentResult = processPayment($searchFee, $paymentMethod, $paymentData);
            
            if ($paymentResult['success']) {
                set_time_limit(60); // 60 seconds timeout
                
                try {
                    if ($searchType === 'vin') {
                        $searchResult = searchPpsrByVin($vin);
                        $requestData = json_encode(['search_type' => 'vin', 'vin' => $vin]);
                    } else {
                        $searchResult = searchPpsrByRego($rego, $state);
                        $requestData = json_encode(['search_type' => 'rego', 'rego' => $rego, 'state' => $state]);
                    }
                    
                    if ($searchResult['success']) {
                        $searchCompleted = true;
                        $searchResults = $searchResult['data'];
                    } else {
                        $searchError = "PPSR search failed: " . $searchResult['error'];
                        $searchCompleted = false;
                    }
                } catch (Exception $e) {
                    $searchError = "Search operation timed out. Please try again.";
                    error_log("Search timeout error: " . $e->getMessage());
                }
                
                if ($searchError) {
                    $searchCompleted = false;
                } else {
                    $responseData = json_encode($searchResults);
                    $status = 'SUCCESS';
                    $paymentId = $paymentResult['payment_id'];
                    
                    if (isset($_SESSION['user_id'])) {
                        if ($searchType === 'vin') {
                            $stmt = $conn->prepare("INSERT INTO searches (user_id, search_type, vin, rego, state, request_data, response_data, status, payment_id) VALUES (?, 'vin', ?, NULL, NULL, ?, ?, ?, ?)");
                            $userId = $_SESSION['user_id'];
                            $stmt->bind_param("issssi", $userId, $vin, $requestData, $responseData, $status, $paymentId);
                        } else {
                            $stmt = $conn->prepare("INSERT INTO searches (user_id, search_type, vin, rego, state, request_data, response_data, status, payment_id) VALUES (?, 'rego', '', ?, ?, ?, ?, ?, ?)");
                            $userId = $_SESSION['user_id'];
                            $stmt->bind_param("isssssi", $userId, $rego, $state, $requestData, $responseData, $status, $paymentId);
                        }
                    } else {
                        if ($searchType === 'vin') {
                            $stmt = $conn->prepare("INSERT INTO searches (user_id, search_type, vin, rego, state, request_data, response_data, status, payment_id) VALUES (NULL, 'vin', ?, NULL, NULL, ?, ?, ?, ?)");
                            $stmt->bind_param("ssssi", $vin, $requestData, $responseData, $status, $paymentId);
                        } else {
                            $stmt = $conn->prepare("INSERT INTO searches (user_id, search_type, vin, rego, state, request_data, response_data, status, payment_id) VALUES (NULL, 'rego', '', ?, ?, ?, ?, ?, ?)");
                            $stmt->bind_param("sssssi", $rego, $state, $requestData, $responseData, $status, $paymentId);
                        }
                    }
                    
                    if ($stmt->execute()) {
                        $searchId = $stmt->insert_id;
                        
                        if ($searchType === 'vin') {
                            $pdfReport = generatePdfReport($searchId);
                            $htmlReport = generateHtmlReport($searchId);
                        } else {
                            $pdfReport = generateRegoReport($searchId);
                            $htmlReport = generateRegoHtmlReport($searchId);
                        }
                        
                        $isDevelopment = (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false);
                        if ($isDevelopment && $pdfReport && strpos($pdfReport, '.html') !== false) {
                            $pdfReportLabel = "View PDF-Style Report";
                        } else {
                            $pdfReportLabel = "Download PDF Report";
                        }
                        
                        if ($pdfReport && $htmlReport) {
                            $stmt = $conn->prepare("UPDATE searches SET pdf_report = ?, html_report = ? WHERE id = ?");
                            $stmt->bind_param("ssi", $pdfReport, $htmlReport, $searchId);
                            $stmt->execute();
                        }
                    } else {
                        $searchError = "Error saving search: " . $stmt->error;
                    }
                }
            } else {
                $searchError = "Payment failed: " . $paymentResult['error'];
                $searchCompleted = false;
            }
        }
    }
    ?>
    
    <?php if ($searchCompleted && $searchResults): ?>
        <div class="search-results">
            <div class="alert alert-success">
                <p>Search completed successfully!</p>
            </div>
            
            <h3>Search Results</h3>
            
            <div class="result-summary">
                <?php if ($searchType === 'vin'): ?>
                    <p><strong>VIN:</strong> <?php echo htmlspecialchars($vin); ?></p>
                <?php else: ?>
                    <p><strong>Registration Number:</strong> <?php echo htmlspecialchars($rego); ?></p>
                    <p><strong>State/Territory:</strong> <?php echo htmlspecialchars($state); ?></p>
                <?php endif; ?>
                <p><strong>Search Date:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
                <p><strong>Search ID:</strong> <?php echo $searchId; ?></p>
            </div>
            
            <div class="result-details">
                <!-- Display search results based on the structure of the PPSR API response -->
                <!-- This will need to be customized based on the actual PPSR API response structure -->
                <pre><?php print_r($searchResults); ?></pre>
            </div>
            
            <div class="result-actions">
                <h4>Download Reports</h4>
                <a href="download.php?file=<?php echo $pdfReport; ?>" class="btn btn-primary" target="_blank"><?php echo $pdfReportLabel; ?></a>
                <a href="download.php?file=<?php echo $htmlReport; ?>" class="btn btn-secondary" target="_blank">View HTML Report</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="index.php?page=dashboard" class="btn btn-tertiary">Back to Dashboard</a>
                <?php else: ?>
                    <a href="index.php" class="btn btn-tertiary">Back to Home</a>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <?php if ($searchError): ?>
            <div class="alert alert-danger">
                <p><?php echo $searchError; ?></p>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="index.php?page=search" id="search-form">
            <div class="unified-search-fields">
                <div class="form-group">
                    <label for="search_input">Vehicle Identifier (VIN or Registration Number)</label>
                    <input type="text" id="search_input" name="search_input" maxlength="17" required>
                    <small>Enter either a 17-character VIN or a registration number.</small>
                </div>
                
                <div class="state-select" id="state_container" style="display: none;">
                    <label for="state">State/Territory (Required for Registration Number)</label>
                    <div class="select-wrapper">
                        <select id="state" name="state" class="styled-select">
                            <option value="">-- Select State --</option>
                            <option value="NSW">New South Wales</option>
                            <option value="VIC">Victoria</option>
                            <option value="QLD">Queensland</option>
                            <option value="WA">Western Australia</option>
                            <option value="SA">South Australia</option>
                            <option value="TAS">Tasmania</option>
                            <option value="ACT">Australian Capital Territory</option>
                            <option value="NT">Northern Territory</option>
                        </select>
                    </div>
                    <small>Select the state or territory where the vehicle is registered.</small>
                </div>
            </div>
            
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const searchInput = document.getElementById('search_input');
                    const stateContainer = document.getElementById('state_container');
                    const stateSelect = document.getElementById('state');
                    
                    function detectInputType() {
                        const input = searchInput.value.trim();
                        
                        const isVin = /^[A-HJ-NPR-Z0-9]{17}$/i.test(input);
                        
                        if (isVin) {
                            stateContainer.style.display = 'none';
                            stateSelect.removeAttribute('required');
                        } else if (input.length > 0) {
                            stateContainer.style.display = 'block';
                            stateSelect.setAttribute('required', 'required');
                        } else {
                            stateContainer.style.display = 'none';
                            stateSelect.removeAttribute('required');
                        }
                    }
                    
                    searchInput.addEventListener('input', detectInputType);
                    
                    detectInputType();
                });
            </script>
            
            <!-- Removed old toggle script -->
            
            <div class="payment-section">
                <h3>Payment Details</h3>
                <p>Search Fee: $<?php echo defined('SEARCH_FEE') ? number_format((float)SEARCH_FEE, 2) : '25.00'; ?> AUD</p>
                
                <div class="payment-methods">
                    <div class="form-group">
                        <label>
                            <input type="radio" name="payment_method" value="stripe" checked>
                            Pay with Credit Card
                        </label>
                    </div>
                </div>
                
                <div id="stripe-payment-element" class="payment-element">
                    <!-- Stripe Elements will be inserted here -->
                </div>
                
                <!-- Hidden fields for payment data -->
                <input type="hidden" id="stripe_payment_method_id" name="stripe_payment_method_id">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary" id="submit-button">Search PPSR</button>
            </div>
        </form>
        
        <script>
            const stripe = Stripe('<?php echo STRIPE_PUBLIC_KEY; ?>');
            const elements = stripe.elements();
            
            const cardElement = elements.create('card');
            cardElement.mount('#stripe-payment-element');
            
            const form = document.getElementById('search-form');
            const submitButton = document.getElementById('submit-button');
            
            
            form.addEventListener('submit', async (event) => {
                event.preventDefault();
                
                const searchInput = document.getElementById('search_input').value.trim();
                const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
                
                let isValid = true;
                let errorMessage = '';
                
                if (!searchInput) {
                    isValid = false;
                    errorMessage = 'Vehicle identifier is required';
                }
                
                const isVin = /^[A-HJ-NPR-Z0-9]{17}$/i.test(searchInput);
                
                if (!isVin) {
                    const state = document.getElementById('state').value;
                    if (!state) {
                        isValid = false;
                        errorMessage = 'State/Territory is required for registration number searches';
                    }
                }
                
                if (!isValid) {
                    alert(errorMessage);
                    return;
                }
                
                if (paymentMethod === 'stripe') {
                    submitButton.disabled = true;
                    submitButton.textContent = 'Processing...';
                    
                    try {
                        const result = await stripe.createPaymentMethod({
                            type: 'card',
                            card: cardElement,
                        });
                        
                        if (result.error) {
                            alert(result.error.message);
                            submitButton.disabled = false;
                            submitButton.textContent = 'Search PPSR';
                        } else {
                            document.getElementById('stripe_payment_method_id').value = result.paymentMethod.id;
                            
                            form.submit();
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        alert('An error occurred while processing your payment. Please try again.');
                        submitButton.disabled = false;
                        submitButton.textContent = 'Search PPSR';
                    }
                }
            });
            
            const stripeElement = document.getElementById('stripe-payment-element');
        </script>
    <?php endif; ?>
</div>
