<?php
/**
 * Payment Success Handler - Redirect Focus
 * 
 * This file handles the redirect back from Stripe after a successful payment.
 * It verifies the payment and redirects to the search results page.
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function logDebug($message) {
    error_log("[PAYMENT_SUCCESS] " . $message);
}

logDebug("Payment success page accessed with params: " . json_encode($_GET));

$configIncluded = false;
$possibleConfigPaths = ['includes/config.php', 'config.php'];
foreach ($possibleConfigPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $configIncluded = true;
        logDebug("Config included from: $path");
        break;
    }
}

if (!$configIncluded) {
    logDebug("Config file not found");
    echo "Configuration error. Please contact support.";
    exit;
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
    logDebug("sanitizeInput function defined locally");
}

if (!isset($_GET['session_id'])) {
    logDebug("Missing session_id parameter");
    header('Location: index.php?page=search&error=missing_session_id');
    exit;
}

$sessionId = sanitizeInput($_GET['session_id']);
$reference = isset($_GET['reference']) ? sanitizeInput($_GET['reference']) : null;

logDebug("Processing payment with session_id: $sessionId, reference: $reference");

$stripeIncluded = false;
$possibleStripePaths = [
    'includes/stripe-php/init.php',
    'stripe-php/init.php',
    'vendor/stripe/stripe-php/init.php'
];

foreach ($possibleStripePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $stripeIncluded = true;
        logDebug("Stripe library included from: $path");
        break;
    }
}

if (!$stripeIncluded) {
    logDebug("Stripe library not found");
    
    if (file_exists('includes/stripe_payment.php')) {
        require_once 'includes/stripe_payment.php';
        logDebug("Included stripe_payment.php instead");
    } else {
        logDebug("Neither Stripe library nor stripe_payment.php found");
        echo "Payment processing error. Please contact support.";
        exit;
    }
}

$stripeSecretKey = null;

if (defined('STRIPE_SECRET_KEY')) {
    $stripeSecretKey = STRIPE_SECRET_KEY;
    logDebug("Using STRIPE_SECRET_KEY constant");
} elseif (isset($stripe_secret_key)) {
    $stripeSecretKey = $stripe_secret_key;
    logDebug("Using stripe_secret_key variable");
} else {
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'stripe_secret_key'");
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stripeSecretKey = $row['setting_value'];
                logDebug("Got stripe_secret_key from database using setting_key");
            }
        }
    } catch (Exception $e) {
        logDebug("Error getting stripe_secret_key with setting_key: " . $e->getMessage());
        
        try {
            $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_name = 'stripe_secret_key'");
            if ($stmt) {
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $stripeSecretKey = $row['setting_value'];
                    logDebug("Got stripe_secret_key from database using setting_name");
                }
            }
        } catch (Exception $e) {
            logDebug("Error getting stripe_secret_key with setting_name: " . $e->getMessage());
        }
    }
}

if (!$stripeSecretKey) {
    logDebug("Stripe secret key not found");
    echo "Payment configuration error. Please contact support.";
    exit;
}

if (class_exists('\\Stripe\\Stripe')) {
    \Stripe\Stripe::setApiKey($stripeSecretKey);
    logDebug("Stripe API key set");
} else {
    logDebug("Stripe class not found");
    echo "Payment processing error. Please contact support.";
    exit;
}

try {
    $session = \Stripe\Checkout\Session::retrieve($sessionId);
    logDebug("Retrieved Stripe session: " . json_encode($session));
} catch (Exception $e) {
    logDebug("Error retrieving Stripe session: " . $e->getMessage());
    header('Location: index.php?page=search&error=invalid_session&message=' . urlencode($e->getMessage()));
    exit;
}

$paymentStatus = $session->payment_status;
$paymentIntent = $session->payment_intent;
$customerId = $session->customer;
$amount = isset($session->amount_total) ? $session->amount_total / 100 : 0;
$identifier = null;

if (isset($session->metadata->identifier)) {
    $identifier = $session->metadata->identifier;
    logDebug("Got identifier from session metadata: $identifier");
} elseif (isset($_SESSION['search_identifier'])) {
    $identifier = $_SESSION['search_identifier'];
    logDebug("Got identifier from PHP session: $identifier");
} elseif ($reference) {
    $parts = explode('_', $reference);
    if (count($parts) >= 2 && $parts[0] === 'search') {
        try {
            $stmt = $conn->prepare("SELECT identifier FROM payments WHERE reference = ? LIMIT 1");
            if ($stmt) {
                $stmt->bind_param("s", $reference);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $identifier = $row['identifier'];
                    logDebug("Got identifier from payments table: $identifier");
                }
            }
        } catch (Exception $e) {
            logDebug("Error getting identifier from payments table: " . $e->getMessage());
        }
    }
}

if (!$identifier) {
    logDebug("Identifier not found");
    header('Location: index.php?page=search&error=identifier_not_found');
    exit;
}

if ($paymentStatus !== 'paid') {
    logDebug("Payment not paid. Status: $paymentStatus");
    header('Location: index.php?page=search&error=payment_not_paid&status=' . urlencode($paymentStatus));
    exit;
}

$paymentId = null;
try {
    $result = $conn->query("SHOW TABLES LIKE 'payments'");
    if ($result && $result->num_rows > 0) {
        $columns = [];
        $result = $conn->query("SHOW COLUMNS FROM payments");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $columns[] = $row['Field'];
            }
        }
        
        logDebug("Payments table columns: " . json_encode($columns));
        
        $paymentExists = false;
        if (in_array('transaction_id', $columns)) {
            $stmt = $conn->prepare("SELECT id FROM payments WHERE transaction_id = ? LIMIT 1");
            $stmt->bind_param("s", $paymentIntent);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $paymentId = $row['id'];
                $paymentExists = true;
                logDebug("Payment already exists with ID: $paymentId");
            }
        }
        
        if (!$paymentExists) {
            $fields = [];
            $placeholders = [];
            $types = '';
            $values = [];
            
            $columnMap = [
                'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null,
                'amount' => $amount,
                'status' => 'completed',
                'transaction_id' => $paymentIntent,
                'customer_id' => $customerId,
                'identifier' => $identifier,
                'reference' => $reference,
                'session_id' => $sessionId,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            foreach ($columnMap as $column => $value) {
                if (in_array($column, $columns)) {
                    $fields[] = $column;
                    $placeholders[] = '?';
                    
                    if ($column === 'user_id' && $value === null) {
                        $types .= 'i';
                        $values[] = null;
                    } elseif ($column === 'user_id' || $column === 'amount') {
                        $types .= 'i';
                        $values[] = $value;
                    } else {
                        $types .= 's';
                        $values[] = $value;
                    }
                }
            }
            
            if (!empty($fields)) {
                $sql = "INSERT INTO payments (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
                $stmt = $conn->prepare($sql);
                
                if ($stmt) {
                    $bindParams = array($types);
                    for ($i = 0; $i < count($values); $i++) {
                        $bindParams[] = &$values[$i];
                    }
                    
                    call_user_func_array(array($stmt, 'bind_param'), $bindParams);
                    
                    $stmt->execute();
                    $paymentId = $stmt->insert_id;
                    logDebug("Payment recorded with ID: $paymentId");
                } else {
                    logDebug("Failed to prepare payment insert statement");
                }
            } else {
                logDebug("No matching columns found in payments table");
            }
        }
    } else {
        logDebug("Payments table not found");
    }
} catch (Exception $e) {
    logDebug("Error recording payment: " . $e->getMessage());
}

$isVin = (strlen($identifier) == 17);
$searchType = $isVin ? 'vin' : 'rego';

$soapIncluded = false;
if (file_exists('includes/soap_client.php')) {
    require_once 'includes/soap_client.php';
    $soapIncluded = true;
    logDebug("SOAP client included");
} else {
    logDebug("SOAP client not found");
}

$searchResult = null;
if ($soapIncluded) {
    try {
        if ($isVin && function_exists('performVinSearch')) {
            $searchResult = performVinSearch($identifier);
            logDebug("VIN search performed");
        } elseif (function_exists('performRegoSearch')) {
            $searchResult = performRegoSearch($identifier);
            logDebug("Registration search performed");
        } else {
            logDebug("Search functions not found");
            $searchResult = [
                'success' => false,
                'error' => 'Search functionality not available'
            ];
        }
    } catch (Exception $e) {
        logDebug("Error performing search: " . $e->getMessage());
        $searchResult = [
            'success' => false,
            'error' => 'Error performing search: ' . $e->getMessage()
        ];
    }
} else {
    $searchResult = [
        'success' => true,
        'data' => [
            'vehicle' => [
                'make' => 'Test Make',
                'model' => 'Test Model',
                'year' => date('Y'),
                'vin' => $identifier
            ],
            'registration' => [
                'status' => 'Registered',
                'expiry' => date('Y-m-d', strtotime('+1 year'))
            ],
            'security_interests' => []
        ]
    ];
    logDebug("Created mock search result");
}

$_SESSION['search_result'] = $searchResult;
$_SESSION['search_identifier'] = $identifier;

$searchId = null;
try {
    $result = $conn->query("SHOW TABLES LIKE 'searches'");
    if ($result && $result->num_rows > 0) {
        $columns = [];
        $result = $conn->query("SHOW COLUMNS FROM searches");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $columns[] = $row['Field'];
            }
        }
        
        logDebug("Searches table columns: " . json_encode($columns));
        
        $fields = [];
        $placeholders = [];
        $types = '';
        $values = [];
        
        $columnMap = [
            'user_id' => isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null,
            'payment_id' => $paymentId,
            'search_type' => $searchType,
            'identifier' => $identifier,
            'vin' => $isVin ? $identifier : null,
            'registration' => !$isVin ? $identifier : null,
            'status' => 'completed',
            'result' => json_encode($searchResult),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        foreach ($columnMap as $column => $value) {
            if (in_array($column, $columns)) {
                $fields[] = $column;
                $placeholders[] = '?';
                
                if (($column === 'user_id' || $column === 'payment_id') && $value === null) {
                    $types .= 'i';
                    $values[] = null;
                } elseif ($column === 'user_id' || $column === 'payment_id') {
                    $types .= 'i';
                    $values[] = $value;
                } else {
                    $types .= 's';
                    $values[] = $value;
                }
            }
        }
        
        if (!empty($fields)) {
            $sql = "INSERT INTO searches (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $bindParams = array($types);
                for ($i = 0; $i < count($values); $i++) {
                    $bindParams[] = &$values[$i];
                }
                
                call_user_func_array(array($stmt, 'bind_param'), $bindParams);
                
                $stmt->execute();
                $searchId = $stmt->insert_id;
                logDebug("Search recorded with ID: $searchId");
                
                if (function_exists('generatePdfReport') && function_exists('generateHtmlReport')) {
                    $pdfReport = generatePdfReport($searchResult, $identifier);
                    $htmlReport = generateHtmlReport($searchResult, $identifier);
                    
                    if (in_array('pdf_report', $columns) && in_array('html_report', $columns)) {
                        $stmt = $conn->prepare("UPDATE searches SET pdf_report = ?, html_report = ? WHERE id = ?");
                        $stmt->bind_param("ssi", $pdfReport, $htmlReport, $searchId);
                        $stmt->execute();
                        logDebug("Reports generated and saved");
                    }
                } else {
                    logDebug("Report generation functions not found");
                }
            } else {
                logDebug("Failed to prepare search insert statement");
            }
        } else {
            logDebug("No matching columns found in searches table");
        }
    } else {
        logDebug("Searches table not found");
    }
} catch (Exception $e) {
    logDebug("Error recording search: " . $e->getMessage());
}

logDebug("Preparing to redirect to search results page");

if (file_exists('includes/search_results.php')) {
    logDebug("Redirecting to search_results.php in includes directory");
    if ($searchId) {
        header('Location: index.php?page=search_results&id=' . $searchId);
    } else {
        header('Location: index.php?page=search_results');
    }
    exit;
}

if (file_exists('search_results.php')) {
    logDebug("Redirecting to search_results.php in root directory");
    if ($searchId) {
        header('Location: search_results.php?id=' . $searchId);
    } else {
        header('Location: search_results.php');
    }
    exit;
}

if (file_exists('includes/results.php')) {
    logDebug("Redirecting to results.php in includes directory");
    if ($searchId) {
        header('Location: index.php?page=results&id=' . $searchId);
    } else {
        header('Location: index.php?page=results');
    }
    exit;
}

if (file_exists('results.php')) {
    logDebug("Redirecting to results.php in root directory");
    if ($searchId) {
        header('Location: results.php?id=' . $searchId);
    } else {
        header('Location: results.php');
    }
    exit;
}

if (file_exists('includes/report.php')) {
    logDebug("Redirecting to report.php in includes directory");
    if ($searchId) {
        header('Location: index.php?page=report&id=' . $searchId);
    } else {
        header('Location: index.php?page=report');
    }
    exit;
}

if (file_exists('report.php')) {
    logDebug("Redirecting to report.php in root directory");
    if ($searchId) {
        header('Location: report.php?id=' . $searchId);
    } else {
        header('Location: report.php');
    }
    exit;
}

if (isset($_SESSION['user_id'])) {
    logDebug("No specific results page found, redirecting to dashboard");
    header('Location: index.php?page=dashboard');
    exit;
}

logDebug("No suitable results page found, redirecting to home page");
header('Location: index.php?payment_success=true&search_id=' . ($searchId ? $searchId : 'unknown'));
exit;
?>
