<?php
/**
 * Stripe Payment Integration
 * 
 * This file handles the Stripe payment integration for processing
 * payments for PPSR searches.
 */

function generateRandomStringForMock($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function generateRandomString($length = 10) {
    return generateRandomStringForMock($length);
}

class StripePaymentHandler {
    private static $instance = null;
    private $useMock = false;
    
    private function __construct() {
        $this->useMock = !class_exists('Stripe\Stripe');
        
        if ($this->useMock) {
            error_log("Using mock Stripe payment handler because Stripe library is not available");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new StripePaymentHandler();
        }
        return self::$instance;
    }
    
    public function initStripe() {
        if (!$this->useMock) {
            if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
                error_log("Stripe secret key is not defined or empty");
                $this->useMock = true;
                return;
            }
            
            try {
                \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
            } catch (Exception $e) {
                error_log("Error initializing Stripe: " . $e->getMessage());
                $this->useMock = true;
            }
        }
    }
    
    public function createPaymentIntent($amount, $identifier, $userId) {
        global $conn;
        
        try {
            $this->initStripe();
            
            $amountInCents = $amount * 100;
            
            if ($this->useMock) {
                $paymentIntent = (object)[
                    'id' => 'pi_' . generateRandomStringForMock(24),
                    'client_secret' => 'pi_' . generateRandomStringForMock(24) . '_secret_' . generateRandomStringForMock(24),
                    'status' => 'succeeded'
                ];
            } else {
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => $amountInCents,
                    'currency' => 'aud',
                    'description' => 'PPSR Search for Vehicle: ' . $identifier,
                    'metadata' => [
                        'identifier' => $identifier,
                        'user_id' => $userId ? $userId : 'guest'
                    ]
                ]);
            }
            
            $paymentIntentId = $paymentIntent->id;
            $clientSecret = $paymentIntent->client_secret;
            
            if ($userId) {
                $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status) VALUES (?, 'stripe', ?, ?, 'pending')");
                $stmt->bind_param("ids", $userId, $amount, $paymentIntentId);
            } else {
                $stmt = $conn->prepare("INSERT INTO payments (user_id, payment_method, amount, transaction_id, status) VALUES (NULL, 'stripe', ?, ?, 'pending')");
                $stmt->bind_param("ds", $amount, $paymentIntentId);
            }
            
            $stmt->execute();
            $paymentId = $stmt->insert_id;
            
            return [
                'success' => true,
                'payment_id' => $paymentId,
                'client_secret' => $clientSecret,
                'public_key' => STRIPE_PUBLIC_KEY
            ];
        } catch (Exception $e) {
            error_log("Stripe Payment Error: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    public function processSuccessfulPayment($paymentIntentId, $paymentId) {
        global $conn;
        
        try {
            $this->initStripe();
            
            if ($this->useMock) {
                $paymentIntent = (object)[
                    'id' => $paymentIntentId,
                    'status' => 'succeeded'
                ];
            } else {
                $paymentIntent = \Stripe\PaymentIntent::retrieve($paymentIntentId);
            }
            
            if ($paymentIntent->status === 'succeeded') {
                $stmt = $conn->prepare("UPDATE payments SET status = 'completed' WHERE id = ?");
                $stmt->bind_param("i", $paymentId);
                $stmt->execute();
                
                return [
                    'success' => true,
                    'payment_id' => $paymentId
                ];
            } else {
                $stmt = $conn->prepare("UPDATE payments SET status = 'failed' WHERE id = ?");
                $stmt->bind_param("i", $paymentId);
                $stmt->execute();
                
                return [
                    'success' => false,
                    'error' => 'Payment not successful. Status: ' . $paymentIntent->status
                ];
            }
        } catch (Exception $e) {
            error_log("Stripe Payment Processing Error: " . $e->getMessage());
            
            $stmt = $conn->prepare("UPDATE payments SET status = 'failed' WHERE id = ?");
            $stmt->bind_param("i", $paymentId);
            $stmt->execute();
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}

function initStripe() {
    StripePaymentHandler::getInstance()->initStripe();
}

function createPaymentIntent($amount, $identifier, $userId) {
    return StripePaymentHandler::getInstance()->createPaymentIntent($amount, $identifier, $userId);
}

function processSuccessfulPayment($paymentIntentId, $paymentId) {
    return StripePaymentHandler::getInstance()->processSuccessfulPayment($paymentIntentId, $paymentId);
}
?>
