<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include_once 'includes/functions-isadmin.php';
include_once 'includes/config.php';
include_once 'includes/functions.php';
include_once 'includes/header.php';

$loggedIn = isset($_SESSION['user_id']) ? true : false;

$page = isset($_GET['page']) ? $_GET['page'] : 'home';

$systemPages = ['home', 'register', 'login', 'dashboard', 'search', 'admin', 'contact'];

if (in_array($page, $systemPages)) {
    switch ($page) {
        case 'home':
            include_once 'includes/home.php';
            break;
        case 'register':
            include_once 'includes/register.php';
            break;
        case 'login':
            include_once 'includes/login.php';
            break;
        case 'dashboard':
            if (!$loggedIn) {
                header('Location: index.php?page=login');
                exit;
            }
            include_once 'includes/dashboard.php';
            break;
        case 'search':
            include_once 'includes/search.php';
            break;
        case 'contact':
            include_once 'includes/contact.php';
            break;
        case 'admin':
            if (!$loggedIn || !isAdmin($_SESSION['user_id'])) {
                header('Location: index.php?page=login');
                exit;
            }
            include_once 'admin/index.php';
            break;
    }
} else {
    $stmt = $conn->prepare("SELECT * FROM pages WHERE slug = ? AND status = 'published'");
    $stmt->bind_param("s", $page);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $pageData = $result->fetch_assoc();
        include_once 'includes/dynamic_page.php';
    } else {
        include_once 'includes/home.php';
    }
}

include_once 'includes/footer.php';
?>
