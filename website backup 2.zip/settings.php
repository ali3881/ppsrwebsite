<?php
/**
 * Admin Settings Page
 * 
 * This file handles the admin settings page for the PPSR website.
 * It includes fixes for:
 * 1. The sanitizeInput function issue
 * 2. The search fee update issue
 * 3. Logo and favicon removal functionality
 */

if (!function_exists('sanitizeInput')) {
    if (file_exists(__DIR__ . '/../includes/functions.php')) {
        require_once __DIR__ . '/../includes/functions.php';
    } else {
        function sanitizeInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    }
}

$generalSettings = [
    'site_name' => [
        'label' => 'Site Name',
        'type' => 'text',
        'value' => defined('SITE_NAME') ? SITE_NAME : 'PPSR Security Check',
        'description' => 'The name of the website'
    ],
    'site_description' => [
        'label' => 'Site Description',
        'type' => 'textarea',
        'value' => defined('SITE_DESCRIPTION') ? SITE_DESCRIPTION : '',
        'description' => 'A brief description of the website'
    ],
    'admin_email' => [
        'label' => 'Admin Email',
        'type' => 'email',
        'value' => defined('ADMIN_EMAIL') ? ADMIN_EMAIL : '',
        'description' => 'The email address for admin notifications'
    ],
    'search_fee' => [
        'label' => 'Search Fee (AUD)',
        'type' => 'number',
        'value' => defined('SEARCH_FEE') ? SEARCH_FEE : '25.00',
        'description' => 'The fee charged for each PPSR search'
    ]
];

$appearanceSettings = [
    'primary_color' => [
        'label' => 'Primary Color',
        'type' => 'color',
        'value' => defined('PRIMARY_COLOR') ? PRIMARY_COLOR : '#007bff',
        'description' => 'The main color used throughout the website'
    ],
    'secondary_color' => [
        'label' => 'Secondary Color',
        'type' => 'color',
        'value' => defined('SECONDARY_COLOR') ? SECONDARY_COLOR : '#6c757d',
        'description' => 'The secondary color used throughout the website'
    ],
    'background_color' => [
        'label' => 'Background Color',
        'type' => 'color',
        'value' => defined('BACKGROUND_COLOR') ? BACKGROUND_COLOR : '#f8f9fa',
        'description' => 'The background color of the website'
    ],
    'text_color' => [
        'label' => 'Text Color',
        'type' => 'color',
        'value' => defined('TEXT_COLOR') ? TEXT_COLOR : '#212529',
        'description' => 'The color of text on the website'
    ],
    'logo' => [
        'label' => 'Logo',
        'type' => 'file',
        'value' => '',
        'description' => 'The logo displayed in the header (recommended size: 200x50px)'
    ],
    'favicon' => [
        'label' => 'Favicon',
        'type' => 'file',
        'value' => '',
        'description' => 'The favicon displayed in the browser tab (recommended size: 32x32px)'
    ],
    'custom_css' => [
        'label' => 'Custom CSS',
        'type' => 'textarea',
        'value' => defined('CUSTOM_CSS') ? CUSTOM_CSS : '',
        'description' => 'Custom CSS to be applied to the website'
    ]
];

$apiSettings = [
    'ppsr_account_name' => [
        'label' => 'PPSR Account Name',
        'type' => 'text',
        'value' => defined('PPSR_ACCOUNT_NAME') ? PPSR_ACCOUNT_NAME : '',
        'description' => 'Your PPSR account name'
    ],
    'ppsr_account_number' => [
        'label' => 'PPSR Account Number',
        'type' => 'text',
        'value' => defined('PPSR_ACCOUNT_NUMBER') ? PPSR_ACCOUNT_NUMBER : '',
        'description' => 'Your PPSR account number'
    ],
    'ppsr_username' => [
        'label' => 'PPSR Username',
        'type' => 'text',
        'value' => defined('PPSR_USERNAME') ? PPSR_USERNAME : '',
        'description' => 'Your PPSR username'
    ],
    'ppsr_password' => [
        'label' => 'PPSR Password',
        'type' => 'password',
        'value' => defined('PPSR_PASSWORD') ? PPSR_PASSWORD : '',
        'description' => 'Your PPSR password'
    ],
    'ppsr_endpoint' => [
        'label' => 'PPSR Endpoint',
        'type' => 'text',
        'value' => defined('PPSR_ENDPOINT') ? PPSR_ENDPOINT : '',
        'description' => 'The PPSR API endpoint URL'
    ],
    'payment_gateway' => [
        'label' => 'Payment Gateway',
        'type' => 'select',
        'options' => [
            'stripe' => 'Stripe'
        ],
        'value' => defined('PAYMENT_GATEWAY') ? PAYMENT_GATEWAY : 'stripe',
        'description' => 'The payment gateway to use for processing payments'
    ],
    'stripe_public_key' => [
        'label' => 'Stripe Public Key',
        'type' => 'text',
        'value' => defined('STRIPE_PUBLIC_KEY') ? STRIPE_PUBLIC_KEY : '',
        'description' => 'Your Stripe public key'
    ],
    'stripe_secret_key' => [
        'label' => 'Stripe Secret Key',
        'type' => 'password',
        'value' => defined('STRIPE_SECRET_KEY') ? STRIPE_SECRET_KEY : '',
        'description' => 'Your Stripe secret key'
    ]
];

$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE 'settings'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

if (!$tableExists) {
    $sql = "CREATE TABLE settings (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        setting_name VARCHAR(255) NOT NULL,
        setting_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    $conn->query($sql);
}

$existingColumns = [];
$result = $conn->query("SHOW COLUMNS FROM settings");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $existingColumns[] = $row['Field'];
    }
}

if (!in_array('logo_url', $existingColumns)) {
    $conn->query("ALTER TABLE settings ADD COLUMN logo_url VARCHAR(255) DEFAULT NULL");
}

if (!in_array('favicon_url', $existingColumns)) {
    $conn->query("ALTER TABLE settings ADD COLUMN favicon_url VARCHAR(255) DEFAULT NULL");
}

$settings = [];
$result = $conn->query("SELECT * FROM settings LIMIT 1");
if ($result->num_rows > 0) {
    $settings = $result->fetch_assoc();
}

$logoUrl = isset($settings['logo_url']) ? $settings['logo_url'] : '';
$faviconUrl = isset($settings['favicon_url']) ? $settings['favicon_url'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $configFile = __DIR__ . '/../includes/config.php';
    $configContent = file_get_contents($configFile);
    
    foreach ($generalSettings as $key => $setting) {
        if (isset($_POST[$key])) {
            $value = sanitizeInput($_POST[$key]);
            
            $constantName = strtoupper($key);
            if (strpos($configContent, "define('$constantName'") !== false) {
                $configContent = preg_replace("/define\('$constantName', '.*?'\);/", "define('$constantName', '$value');", $configContent);
            } else {
                $configContent .= "\ndefine('$constantName', '$value');";
            }
        }
    }
    
    foreach ($appearanceSettings as $key => $setting) {
        if ($key === 'logo' || $key === 'favicon') {
            continue; // Handle file uploads separately
        }
        
        if (isset($_POST[$key])) {
            $value = sanitizeInput($_POST[$key]);
            
            $constantName = strtoupper($key);
            if (strpos($configContent, "define('$constantName'") !== false) {
                $configContent = preg_replace("/define\('$constantName', '.*?'\);/", "define('$constantName', '$value');", $configContent);
            } else {
                $configContent .= "\ndefine('$constantName', '$value');";
            }
        }
    }
    
    foreach ($apiSettings as $key => $setting) {
        if (isset($_POST[$key])) {
            $value = sanitizeInput($_POST[$key]);
            
            $constantName = strtoupper($key);
            if (strpos($configContent, "define('$constantName'") !== false) {
                $configContent = preg_replace("/define\('$constantName', '.*?'\);/", "define('$constantName', '$value');", $configContent);
            } else {
                $configContent .= "\ndefine('$constantName', '$value');";
            }
        }
    }
    
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadsDir = __DIR__ . '/../uploads';
        if (!file_exists($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }
        
        $fileName = 'logo_' . time() . '_' . $_FILES['logo']['name'];
        $filePath = $uploadsDir . '/' . $fileName;
        
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $filePath)) {
            $logoUrl = 'uploads/' . $fileName;
        }
    }
    
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
        $uploadsDir = __DIR__ . '/../uploads';
        if (!file_exists($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }
        
        $fileName = 'favicon_' . time() . '_' . $_FILES['favicon']['name'];
        $filePath = $uploadsDir . '/' . $fileName;
        
        if (move_uploaded_file($_FILES['favicon']['tmp_name'], $filePath)) {
            $faviconUrl = 'uploads/' . $fileName;
        }
    }
    
    if (isset($_POST['remove_logo']) && $_POST['remove_logo'] === '1') {
        if (!empty($logoUrl) && file_exists(__DIR__ . '/../' . $logoUrl)) {
            unlink(__DIR__ . '/../' . $logoUrl);
        }
        $logoUrl = '';
    }
    
    if (isset($_POST['remove_favicon']) && $_POST['remove_favicon'] === '1') {
        if (!empty($faviconUrl) && file_exists(__DIR__ . '/../' . $faviconUrl)) {
            unlink(__DIR__ . '/../' . $faviconUrl);
        }
        $faviconUrl = '';
    }
    
    if ($result->num_rows > 0) {
        $sql = "UPDATE settings SET ";
        $updates = [];
        
        foreach ($generalSettings as $key => $setting) {
            if (isset($_POST[$key])) {
                $value = sanitizeInput($_POST[$key]);
                $updates[] = "$key = '$value'";
            }
        }
        
        foreach ($appearanceSettings as $key => $setting) {
            if ($key === 'logo' || $key === 'favicon') {
                continue; // Handle file uploads separately
            }
            
            if (isset($_POST[$key])) {
                $value = sanitizeInput($_POST[$key]);
                $updates[] = "$key = '$value'";
            }
        }
        
        foreach ($apiSettings as $key => $setting) {
            if (isset($_POST[$key])) {
                $value = sanitizeInput($_POST[$key]);
                $updates[] = "$key = '$value'";
            }
        }
        
        $updates[] = "logo_url = '$logoUrl'";
        $updates[] = "favicon_url = '$faviconUrl'";
        
        $sql .= implode(', ', $updates);
        $sql .= " WHERE id = " . $settings['id'];
        
        $conn->query($sql);
    } else {
        $columns = [];
        $values = [];
        
        foreach ($generalSettings as $key => $setting) {
            if (isset($_POST[$key])) {
                $columns[] = $key;
                $values[] = "'" . sanitizeInput($_POST[$key]) . "'";
            }
        }
        
        foreach ($appearanceSettings as $key => $setting) {
            if ($key === 'logo' || $key === 'favicon') {
                continue; // Handle file uploads separately
            }
            
            if (isset($_POST[$key])) {
                $columns[] = $key;
                $values[] = "'" . sanitizeInput($_POST[$key]) . "'";
            }
        }
        
        foreach ($apiSettings as $key => $setting) {
            if (isset($_POST[$key])) {
                $columns[] = $key;
                $values[] = "'" . sanitizeInput($_POST[$key]) . "'";
            }
        }
        
        $columns[] = 'logo_url';
        $values[] = "'" . $logoUrl . "'";
        $columns[] = 'favicon_url';
        $values[] = "'" . $faviconUrl . "'";
        
        $sql = "INSERT INTO settings (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $values) . ")";
        
        $conn->query($sql);
    }
    
    file_put_contents($configFile, $configContent);
    
    $successMessage = "Settings saved successfully.";
}

$result = $conn->query("SELECT * FROM settings LIMIT 1");
if ($result->num_rows > 0) {
    $settings = $result->fetch_assoc();
    
    $logoUrl = isset($settings['logo_url']) ? $settings['logo_url'] : '';
    $faviconUrl = isset($settings['favicon_url']) ? $settings['favicon_url'] : '';
}
?>

<div class="admin-content">
    <h2>Settings</h2>
    
    <?php if (isset($successMessage)): ?>
        <div class="alert alert-success">
            <?php echo $successMessage; ?>
        </div>
    <?php endif; ?>
    
    <div class="settings-tabs">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#general">General</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#appearance">Appearance</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#api">API & Integration</a>
            </li>
        </ul>
        
        <div class="tab-content">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="tab-pane fade show active" id="general">
                    <h3>General Settings</h3>
                    
                    <?php foreach ($generalSettings as $key => $setting): ?>
                        <div class="form-group">
                            <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                            
                            <?php if ($setting['type'] === 'text' || $setting['type'] === 'email' || $setting['type'] === 'number'): ?>
                                <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" value="<?php echo isset($settings[$key]) ? $settings[$key] : $setting['value']; ?>">
                            <?php elseif ($setting['type'] === 'textarea'): ?>
                                <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control"><?php echo isset($settings[$key]) ? $settings[$key] : $setting['value']; ?></textarea>
                            <?php elseif ($setting['type'] === 'select'): ?>
                                <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                                    <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                        <option value="<?php echo $optionValue; ?>" <?php echo (isset($settings[$key]) && $settings[$key] === $optionValue) || (!isset($settings[$key]) && $setting['value'] === $optionValue) ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                            
                            <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="tab-pane fade" id="appearance">
                    <h3>Appearance Settings</h3>
                    
                    <?php foreach ($appearanceSettings as $key => $setting): ?>
                        <?php if ($key === 'logo'): ?>
                            <div class="form-group">
                                <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                                
                                <?php if (!empty($logoUrl)): ?>
                                    <div class="current-logo">
                                        <p>Current Logo:</p>
                                        <img src="<?php echo '../' . $logoUrl; ?>" alt="Current Logo" style="max-width: 200px; max-height: 50px;">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="remove_logo" name="remove_logo" value="1">
                                            <label class="form-check-label" for="remove_logo">Remove Logo</label>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <input type="file" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control-file">
                                <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                            </div>
                        <?php elseif ($key === 'favicon'): ?>
                            <div class="form-group">
                                <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                                
                                <?php if (!empty($faviconUrl)): ?>
                                    <div class="current-favicon">
                                        <p>Current Favicon:</p>
                                        <img src="<?php echo '../' . $faviconUrl; ?>" alt="Current Favicon" style="max-width: 32px; max-height: 32px;">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="remove_favicon" name="remove_favicon" value="1">
                                            <label class="form-check-label" for="remove_favicon">Remove Favicon</label>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <input type="file" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control-file">
                                <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                            </div>
                        <?php elseif ($setting['type'] === 'color'): ?>
                            <div class="form-group">
                                <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                                <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" value="<?php echo isset($settings[$key]) ? $settings[$key] : $setting['value']; ?>">
                                <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                            </div>
                        <?php elseif ($setting['type'] === 'textarea'): ?>
                            <div class="form-group">
                                <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                                <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control"><?php echo isset($settings[$key]) ? $settings[$key] : $setting['value']; ?></textarea>
                                <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                
                <div class="tab-pane fade" id="api">
                    <h3>API & Integration Settings</h3>
                    
                    <?php foreach ($apiSettings as $key => $setting): ?>
                        <div class="form-group">
                            <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                            
                            <?php if ($setting['type'] === 'text' || $setting['type'] === 'password'): ?>
                                <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" value="<?php echo isset($settings[$key]) ? $settings[$key] : $setting['value']; ?>">
                            <?php elseif ($setting['type'] === 'select'): ?>
                                <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                                    <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                        <option value="<?php echo $optionValue; ?>" <?php echo (isset($settings[$key]) && $settings[$key] === $optionValue) || (!isset($settings[$key]) && $setting['value'] === $optionValue) ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                            
                            <small class="form-text text-muted"><?php echo $setting['description']; ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save Settings</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const tabLinks = document.querySelectorAll('.nav-link');
        const tabPanes = document.querySelectorAll('.tab-pane');
        
        tabLinks.forEach(function(tabLink) {
            tabLink.addEventListener('click', function(e) {
                e.preventDefault();
                
                tabLinks.forEach(function(link) {
                    link.classList.remove('active');
                });
                
                tabPanes.forEach(function(pane) {
                    pane.classList.remove('show');
                    pane.classList.remove('active');
                });
                
                this.classList.add('active');
                
                const tabId = this.getAttribute('href').substring(1);
                const tabPane = document.getElementById(tabId);
                tabPane.classList.add('show');
                tabPane.classList.add('active');
            });
        });
    });
</script>
