# PPSR XML Manager

This package adds a new feature to the PPSR service website that allows administrators to download and upload PPSR API XML files. This functionality is essential for debugging, testing, and data recovery purposes.

## Features

1. **XML File Upload**
   - Upload XML files for testing or data restoration
   - Validates XML format before accepting
   - Stores files both in the file system and database (if available)

2. **XML File Download**
   - Download raw XML responses from successful PPSR API queries
   - Access XML files from both database and file system
   - Easily export XML data for external analysis

3. **XML Content Viewing**
   - View XML content directly in the browser
   - Properly formatted for readability
   - No need to download files to inspect content

4. **XML Extraction from Searches**
   - Extract XML data from existing search records
   - Automatically saves extracted XML to files and database
   - Recover historical XML data that might not have been saved

5. **Database Integration**
   - Creates and uses a dedicated api_xml table
   - Stores XML content, filename, upload date, and user information
   - Links XML files to search records when possible

6. **File System Management**
   - Manages XML files in a dedicated directory
   - Provides file size and modification date information
   - Allows deletion of files from both database and file system

## Installation Instructions

1. **Create XML Storage Directory**:
   ```
   mkdir -p /home/ppsrsecuritychec/public_html/xml_storage
   chmod 755 /home/ppsrsecuritychec/public_html/xml_storage
   ```

2. **Upload the XML Manager File**:
   - Extract the attached zip file
   - Upload `xml_manager.php` to `/home/ppsrsecuritychec/public_html/admin/`

3. **Set File Permissions**:
   ```
   chmod 644 /home/ppsrsecuritychec/public_html/admin/xml_manager.php
   ```

4. **Add Menu Link**:
   - Edit your admin menu to include a link to the XML Manager:
   - Add the following line to your admin navigation menu:
   ```html
   <li><a href="index.php?page=xml_manager">XML Manager</a></li>
   ```

5. **Update Admin Index**:
   - Edit your admin/index.php file to include the XML Manager page:
   - Add the following case to your page switch statement:
   ```php
   case 'xml_manager':
       include_once 'xml_manager.php';
       break;
   ```

## Usage

1. **Uploading XML Files**:
   - Go to Admin > XML Manager
   - Click "Choose File" and select an XML file
   - Click "Upload XML"

2. **Extracting XML from Searches**:
   - Go to Admin > XML Manager
   - Click "Extract XML from Searches"
   - This will extract XML data from all search records

3. **Creating the api_xml Table**:
   - Go to Admin > XML Manager
   - Click "Create api_xml Table"
   - This will create the database table if it doesn't exist

4. **Viewing XML Files**:
   - Go to Admin > XML Manager
   - Click "View" next to any XML file
   - The XML content will be displayed in a formatted view

5. **Downloading XML Files**:
   - Go to Admin > XML Manager
   - Click "Download" next to any XML file
   - The XML file will be downloaded to your computer

6. **Deleting XML Files**:
   - Go to Admin > XML Manager
   - Click "Delete" next to any XML file
   - Confirm the deletion when prompted

## Security Considerations

1. The XML Manager is only accessible to administrators
2. XML files are validated before being accepted
3. File paths are sanitized to prevent directory traversal attacks
4. User input is properly sanitized to prevent SQL injection
5. XML content is properly escaped when displayed to prevent XSS attacks

This feature complements the existing PPSR service website by providing administrators with tools to manage and analyze the raw XML data from the PPSR API.
