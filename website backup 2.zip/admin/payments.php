<?php
/**
 * Admin Payments Page
 * 
 * This file displays and manages payment records in the admin panel.
 * Fixed to include the formatCurrency function if it's not defined.
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$functionsIncluded = false;
$possiblePaths = ['../includes/functions.php', 'includes/functions.php', 'functions.php'];
foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functionsIncluded = true;
        break;
    }
}

$isAdminIncluded = false;
$possibleIsAdminPaths = ['../includes/functions-isadmin.php', 'includes/functions-isadmin.php', 'functions-isadmin.php'];
foreach ($possibleIsAdminPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $isAdminIncluded = true;
        break;
    }
}

if (!function_exists('formatCurrency')) {
    function formatCurrency($amount, $currency = 'AUD') {
        if ($currency == 'AUD') {
            return '$' . number_format((float)$amount, 2, '.', ',');
        } else {
            return number_format((float)$amount, 2, '.', ',') . ' ' . $currency;
        }
    }
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin($conn = null) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
}

if (file_exists('../includes/config.php')) {
    require_once '../includes/config.php';
} elseif (file_exists('includes/config.php')) {
    require_once 'includes/config.php';
} else {
    die("Configuration file not found");
}

if (!isset($_SESSION['user_id']) || !isAdmin($conn)) {
    header('Location: ../index.php?page=login');
    exit;
}

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $paymentId = sanitizeInput($_GET['delete']);
    
    $stmt = $conn->prepare("DELETE FROM payments WHERE id = ?");
    $stmt->bind_param("i", $paymentId);
    
    if ($stmt->execute()) {
        $successMessage = "Payment deleted successfully";
    } else {
        $errorMessage = "Error deleting payment: " . $conn->error;
    }
}

$payments = [];
$sql = "SELECT * FROM payments ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $payments[] = $row;
    }
}

$columns = [];
if (!empty($payments)) {
    $columns = array_keys($payments[0]);
}

function getUserEmail($userId, $conn) {
    if (!$userId) return 'Guest';
    
    $stmt = $conn->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['email'];
    }
    
    return 'Unknown';
}

function formatDate($date) {
    return date('Y-m-d H:i:s', strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Payments</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .payment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 5px;
            overflow-x: auto;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .payment-table-container {
            width: 100%;
            overflow-x: auto;
            margin-bottom: 20px;
        }
        
        .payment-table th, .payment-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
            white-space: normal;
            word-break: break-word;
        }
        
        .payment-table th {
            background-color: #007bff;
            color: white;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
        }
        
        .payment-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        .payment-table tr:hover {
            background-color: #e9f0f7;
        }
        
        .payment-table td {
            font-size: 14px;
        }
        
        /* Column width control */
        .payment-table th:nth-child(1), .payment-table td:nth-child(1) { /* ID */
            width: 5%;
            min-width: 50px;
        }
        
        .payment-table th:nth-child(2), .payment-table td:nth-child(2) { /* User */
            width: 15%;
            min-width: 120px;
        }
        
        .payment-table th:nth-child(3), .payment-table td:nth-child(3) { /* Amount */
            width: 8%;
            min-width: 80px;
        }
        
        .payment-table th:nth-child(4), .payment-table td:nth-child(4) { /* Status */
            width: 10%;
            min-width: 100px;
        }
        
        .payment-table th:nth-child(5), .payment-table td:nth-child(5) { /* Transaction ID */
            width: 35%;
            min-width: 200px;
        }
        
        .payment-table th:nth-child(6), .payment-table td:nth-child(6) { /* Date */
            width: 15%;
            min-width: 120px;
        }
        
        .payment-table th:nth-child(7), .payment-table td:nth-child(7) { /* Actions */
            width: 8%;
            min-width: 80px;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .payment-table th, .payment-table td {
                padding: 8px 10px;
                font-size: 13px;
            }
            
            .payment-table th {
                font-size: 12px;
            }
        }
        
        .action-links a {
            display: inline-block;
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .action-links a:hover {
            color: #0056b3;
        }
        
        .action-links a.delete {
            color: #dc3545;
        }
        
        .action-links a.delete:hover {
            color: #a71d2a;
        }
        
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            border-left: 4px solid #28a745;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            border-left: 4px solid #dc3545;
        }
        
        /* Status styling */
        .status-pending {
            display: inline-block;
            padding: 4px 8px;
            background-color: #ffc107;
            color: #212529;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-completed {
            display: inline-block;
            padding: 4px 8px;
            background-color: #28a745;
            color: white;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-error {
            display: inline-block;
            padding: 4px 8px;
            background-color: #dc3545;
            color: white;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment Management</h1>
        
        <?php if (isset($successMessage)): ?>
            <div class="success-message"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        
        <?php if (isset($errorMessage)): ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        
        <?php if (empty($payments)): ?>
            <p>No payments found.</p>
        <?php else: ?>
            <div class="payment-table-container">
                <table class="payment-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                        <?php if (in_array('amount', $columns)): ?>
                            <th>Amount</th>
                        <?php endif; ?>
                        <?php if (in_array('status', $columns)): ?>
                            <th>Status</th>
                        <?php endif; ?>
                        <?php if (in_array('transaction_id', $columns)): ?>
                            <th>Transaction ID</th>
                        <?php endif; ?>
                        <?php if (in_array('identifier', $columns)): ?>
                            <th>Identifier</th>
                        <?php endif; ?>
                        <?php if (in_array('created_at', $columns)): ?>
                            <th>Date</th>
                        <?php endif; ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $payment): ?>
                        <tr>
                            <td><?php echo $payment['id']; ?></td>
                            <td><?php echo getUserEmail($payment['user_id'] ?? null, $conn); ?></td>
                            <?php if (in_array('amount', $columns)): ?>
                                <td><?php echo formatCurrency($payment['amount']); ?></td>
                            <?php endif; ?>
                            <?php if (in_array('status', $columns)): ?>
                                <td>
                                    <?php 
                                    $status = strtolower($payment['status']);
                                    $statusClass = 'status-pending';
                                    
                                    if (strpos($status, 'complete') !== false || $status === 'success') {
                                        $statusClass = 'status-completed';
                                    } elseif (strpos($status, 'error') !== false || strpos($status, 'fail') !== false || strpos($status, 'unexpected') !== false) {
                                        $statusClass = 'status-error';
                                    }
                                    
                                    echo '<span class="' . $statusClass . '">' . ucfirst($payment['status']) . '</span>';
                                    ?>
                                </td>
                            <?php endif; ?>
                            <?php if (in_array('transaction_id', $columns)): ?>
                                <td><?php echo $payment['transaction_id']; ?></td>
                            <?php endif; ?>
                            <?php if (in_array('identifier', $columns)): ?>
                                <td><?php echo $payment['identifier']; ?></td>
                            <?php endif; ?>
                            <?php if (in_array('created_at', $columns)): ?>
                                <td><?php echo formatDate($payment['created_at']); ?></td>
                            <?php endif; ?>
                            <td class="action-links">
                                <a href="index.php?page=payments&delete=<?php echo $payment['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this payment?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
