<?php
/**
 * Admin Contact Messages Page
 * 
 * This file handles the admin interface for viewing and managing contact form messages.
 */

if (!isset($_SESSION['user_id']) || !isAdmin($_SESSION['user_id'])) {
    header('Location: ../index.php?page=login');
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'update_status' && isset($_GET['id']) && isset($_GET['status'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];
    
    if (in_array($status, ['new', 'read', 'replied'])) {
        $stmt = $conn->prepare("UPDATE contact_messages SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    $stmt = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

$page = isset($_GET['message_page']) ? (int)$_GET['message_page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM contact_messages");
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_messages = $row['total'];
$total_pages = ceil($total_messages / $limit);

$stmt = $conn->prepare("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
?>

<div class="admin-section">
    <h3>Contact Messages</h3>
    
    <?php if (empty($messages)): ?>
        <div class="info-message">
            <p>No contact messages found.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message): ?>
                        <tr class="<?php echo $message['status'] === 'new' ? 'new-message' : ''; ?>">
                            <td><?php echo $message['id']; ?></td>
                            <td><?php echo htmlspecialchars($message['name']); ?></td>
                            <td><a href="mailto:<?php echo htmlspecialchars($message['email']); ?>"><?php echo htmlspecialchars($message['email']); ?></a></td>
                            <td><?php echo htmlspecialchars($message['subject']); ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($message['created_at'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $message['status']; ?>">
                                    <?php echo ucfirst($message['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="#" class="view-message" data-id="<?php echo $message['id']; ?>" title="View Message">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="index.php?page=admin&action=contact_messages&action=update_status&id=<?php echo $message['id']; ?>&status=read" title="Mark as Read">
                                        <i class="fas fa-check"></i>
                                    </a>
                                    <a href="index.php?page=admin&action=contact_messages&action=update_status&id=<?php echo $message['id']; ?>&status=replied" title="Mark as Replied">
                                        <i class="fas fa-reply"></i>
                                    </a>
                                    <a href="index.php?page=admin&action=contact_messages&action=delete&id=<?php echo $message['id']; ?>" class="delete-action" title="Delete" onclick="return confirm('Are you sure you want to delete this message?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="index.php?page=admin&action=contact_messages&message_page=<?php echo $page - 1; ?>" class="page-link">&laquo; Previous</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="index.php?page=admin&action=contact_messages&message_page=<?php echo $i; ?>" class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="index.php?page=admin&action=contact_messages&message_page=<?php echo $page + 1; ?>" class="page-link">Next &raquo;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    
    <!-- Message Modal -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Message Details</h3>
            <div id="messageDetails"></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('messageModal');
    const messageDetails = document.getElementById('messageDetails');
    const closeBtn = document.getElementsByClassName('close')[0];
    
    const viewButtons = document.querySelectorAll('.view-message');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const messageId = this.getAttribute('data-id');
            
            const row = this.closest('tr');
            const name = row.cells[1].textContent;
            const email = row.cells[2].textContent;
            const subject = row.cells[3].textContent;
            const date = row.cells[4].textContent;
            const messageContent = row.getAttribute('data-message');
            
            if (row.classList.contains('new-message')) {
                fetch(`index.php?page=admin&action=contact_messages&action=update_status&id=${messageId}&status=read`, {
                    method: 'GET'
                }).then(() => {
                    row.classList.remove('new-message');
                    row.cells[5].innerHTML = '<span class="status-badge status-read">Read</span>';
                });
            }
            
            messageDetails.innerHTML = `
                <div class="message-header">
                    <p><strong>From:</strong> ${name} (${email})</p>
                    <p><strong>Subject:</strong> ${subject}</p>
                    <p><strong>Date:</strong> ${date}</p>
                </div>
                <div class="message-body">
                    <p>${messageContent}</p>
                </div>
                <div class="message-actions">
                    <a href="mailto:${email}?subject=Re: ${subject}" class="btn btn-primary">Reply via Email</a>
                    <a href="index.php?page=admin&action=contact_messages&action=update_status&id=${messageId}&status=replied" class="btn btn-secondary">Mark as Replied</a>
                </div>
            `;
            
            modal.style.display = 'block';
        });
    });
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>
