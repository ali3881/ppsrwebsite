<div class="admin-dashboard">
    <h3>Admin Dashboard</h3>
    
    <?php
    if (!function_exists('checkStripeApiConnection')) {
        include_once $_SERVER['DOCUMENT_ROOT'] . '/includes/functions-connection.php';
    }
    
    if (!function_exists('formatCurrency')) {
        function formatCurrency($amount) {
            return '$' . number_format((float)$amount, 2, '.', ',');
        }
    }
    
    $stats = [];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $stats['total_users'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM searches");
    $stats['total_searches'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM payments");
    $stats['total_payments'] = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT SUM(amount) as total FROM payments WHERE status = 'SUCCESS'");
    $stats['total_revenue'] = $result->fetch_assoc()['total'] ?: 0;
    
    $result = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
    $recentUsers = [];
    while ($row = $result->fetch_assoc()) {
        $recentUsers[] = $row;
    }
    
    $result = $conn->query("SELECT s.*, u.email FROM searches s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC LIMIT 5");
    $recentSearches = [];
    while ($row = $result->fetch_assoc()) {
        $recentSearches[] = $row;
    }
    
    $result = $conn->query("SELECT p.*, u.email FROM payments p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC LIMIT 5");
    $recentPayments = [];
    while ($row = $result->fetch_assoc()) {
        $recentPayments[] = $row;
    }
    
    $dbConnection = function_exists('checkDatabaseConnection') ? checkDatabaseConnection() : true;
    $ppsrApiConnection = function_exists('checkPpsrApiConnection') ? checkPpsrApiConnection() : false;
    $stripeApiConnection = function_exists('checkStripeApiConnection') ? checkStripeApiConnection() : false;
    ?>
    
    <div class="connection-status">
        <h4>Connection Status</h4>
        <div class="connection-cards">
            <div class="connection-card <?php echo $dbConnection ? 'connected' : 'disconnected'; ?>">
                <div class="connection-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="connection-content">
                    <h5>Database</h5>
                    <p class="connection-value">
                        <?php if ($dbConnection): ?>
                            <span class="status-connected"><i class="fas fa-check-circle"></i> Connected</span>
                        <?php else: ?>
                            <span class="status-disconnected"><i class="fas fa-times-circle"></i> Disconnected</span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            
            <div class="connection-card <?php echo $ppsrApiConnection ? 'connected' : 'disconnected'; ?>">
                <div class="connection-icon">
                    <i class="fas fa-cloud"></i>
                </div>
                <div class="connection-content">
                    <h5>PPSR API</h5>
                    <p class="connection-value">
                        <?php if ($ppsrApiConnection): ?>
                            <span class="status-connected"><i class="fas fa-check-circle"></i> Connected</span>
                        <?php else: ?>
                            <span class="status-disconnected"><i class="fas fa-times-circle"></i> Disconnected</span>
                        <?php endif; ?>
                    </p>
                    <p class="data-source">
                        <?php if (defined('USE_REAL_XML_DATA') && USE_REAL_XML_DATA == '1'): ?>
                            <span class="data-source-real"><i class="fas fa-globe"></i> Using Real XML Data</span>
                        <?php else: ?>
                            <span class="data-source-mock"><i class="fas fa-code"></i> Using Mock Data</span>
                        <?php endif; ?>
                    </p>
                    <div class="data-source-toggle">
                        <a href="index.php?page=admin&action=settings#xml_settings" class="btn btn-sm btn-primary">
                            <i class="fas fa-cog"></i> Configure Data Source
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="connection-card <?php echo $stripeApiConnection ? 'connected' : 'disconnected'; ?>">
                <div class="connection-icon">
                    <i class="fab fa-stripe"></i>
                </div>
                <div class="connection-content">
                    <h5>Stripe API</h5>
                    <p class="connection-value">
                        <?php if ($stripeApiConnection): ?>
                            <span class="status-connected"><i class="fas fa-check-circle"></i> Connected</span>
                        <?php else: ?>
                            <span class="status-disconnected"><i class="fas fa-times-circle"></i> Disconnected</span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-content">
                <h4>Total Users</h4>
                <p class="stat-value"><?php echo $stats['total_users']; ?></p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-search"></i>
            </div>
            <div class="stat-content">
                <h4>Total Searches</h4>
                <p class="stat-value"><?php echo $stats['total_searches']; ?></p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-credit-card"></i>
            </div>
            <div class="stat-content">
                <h4>Total Payments</h4>
                <p class="stat-value"><?php echo $stats['total_payments']; ?></p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="stat-content">
                <h4>Total Revenue</h4>
                <p class="stat-value"><?php echo formatCurrency($stats['total_revenue']); ?></p>
            </div>
        </div>
    </div>
    
    <div class="admin-sections">
        <div class="admin-section">
            <h4>Recent Users</h4>
            
            <?php if (empty($recentUsers)): ?>
                <p>No users found.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentUsers as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php 
                                    $name = '';
                                    if (isset($user['first_name']) && isset($user['last_name'])) {
                                        $name = $user['first_name'] . ' ' . $user['last_name'];
                                    } elseif (isset($user['name'])) {
                                        $name = $user['name'];
                                    } else {
                                        $name = $user['email'];
                                    }
                                    echo htmlspecialchars($name);
                                ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="view-all">
                    <a href="index.php?page=admin&action=users">View All Users</a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="admin-section">
            <h4>Recent Searches</h4>
            
            <?php if (empty($recentSearches)): ?>
                <p>No searches found.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>VIN</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentSearches as $search): ?>
                            <tr>
                                <td><?php echo $search['id']; ?></td>
                                <td><?php echo htmlspecialchars($search['email']); ?></td>
                                <td><?php echo htmlspecialchars($search['vin']); ?></td>
                                <td><?php echo htmlspecialchars($search['status']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($search['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="view-all">
                    <a href="index.php?page=admin&action=searches">View All Searches</a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="admin-section">
            <h4>Recent Payments</h4>
            
            <?php if (empty($recentPayments)): ?>
                <p>No payments found.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentPayments as $payment): ?>
                            <tr>
                                <td><?php echo $payment['id']; ?></td>
                                <td><?php echo htmlspecialchars($payment['email']); ?></td>
                                <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                <td><?php echo formatCurrency($payment['amount']); ?></td>
                                <td><?php echo htmlspecialchars($payment['status']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($payment['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="view-all">
                    <a href="index.php?page=admin&action=payments">View All Payments</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
