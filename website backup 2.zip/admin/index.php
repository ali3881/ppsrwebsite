<?php
if (!isset($_SESSION['user_id']) || !isAdmin($_SESSION['user_id'])) {
    header('Location: ../index.php?page=login');
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : 'dashboard';
?>

<div class="admin-container">
    <h2>Admin Panel</h2>
    
    <div class="admin-navigation" style="background-color: #f8f9fa; border-radius: 5px; padding: 15px 0; margin-bottom: 25px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
        <ul style="display: flex; flex-wrap: wrap; list-style: none; margin: 0; padding: 0; justify-content: flex-start;">
            <li style="margin: 5px;"><a href="index.php?page=admin&action=dashboard" class="<?php echo $action === 'dashboard' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'dashboard' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'dashboard' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Dashboard</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=users" class="<?php echo $action === 'users' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'users' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'users' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Users</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=searches" class="<?php echo $action === 'searches' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'searches' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'searches' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Searches</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=payments" class="<?php echo $action === 'payments' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'payments' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'payments' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Payments</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=api_logs" class="<?php echo $action === 'api_logs' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'api_logs' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'api_logs' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">API Logs</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=contact_messages" class="<?php echo $action === 'contact_messages' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'contact_messages' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'contact_messages' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Contact Messages</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=pages" class="<?php echo $action === 'pages' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'pages' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'pages' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Pages</a></li>
            <li style="margin: 5px;"><a href="index.php?page=admin&action=settings" class="<?php echo $action === 'settings' ? 'active' : ''; ?>" style="display: inline-block; padding: 10px 15px; background-color: <?php echo $action === 'settings' ? '#007bff' : '#fff'; ?>; color: <?php echo $action === 'settings' ? '#fff' : '#007bff'; ?>; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">Settings</a></li>
            <li style="margin: 5px;"><a href="index.php?page=xml_manager" style="display: inline-block; padding: 10px 15px; background-color: #fff; color: #007bff; text-decoration: none; border-radius: 4px; font-weight: 500; box-shadow: 0 1px 3px rgba(0,0,0,0.1); transition: all 0.2s ease;">XML Manager</a></li>
        </ul>
    </div>
    
    <div class="admin-content">
        <?php
        switch ($action) {
            case 'dashboard':
                include_once 'admin/dashboard.php';
                break;
            case 'users':
                include_once 'admin/users.php';
                break;
            case 'searches':
                include_once 'admin/searches.php';
                break;
            case 'payments':
                include_once 'admin/payments.php';
                break;
            case 'api_logs':
                include_once 'admin/api_logs.php';
                break;
            case 'contact_messages':
                include_once 'admin/contact_messages.php';
                break;
            case 'pages':
                include_once 'admin/pages.php';
                break;
            case 'settings':
                include_once 'admin/settings.php';
                break;
                 break;
            case 'xml_manager':
                include_once 'xml_manager.php';
                break;
            default:
                include_once 'admin/dashboard.php';
               
        }
        ?>
    </div>
</div>
