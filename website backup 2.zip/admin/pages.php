<div class="admin-pages">
    <h3>Page Management</h3>
    
    <?php
    if (isset($_GET['action']) && isset($_GET['page_id'])) {
        $pageId = (int)$_GET['page_id'];
        $action = $_GET['action'];
        
        switch ($action) {
            case 'delete':
                $stmt = $conn->prepare("SELECT * FROM pages WHERE id = ?");
                $stmt->bind_param("i", $pageId);
                $stmt->execute();
                $result = $stmt->get_result();
                $page = $result->fetch_assoc();
                
                $isSystemPage = isset($page['is_system_page']) && $page['is_system_page'] == 1;
                
                if ($isSystemPage) {
                    echo '<div class="alert alert-danger">System pages cannot be deleted.</div>';
                } else {
                    $stmt = $conn->prepare("DELETE FROM pages WHERE id = ?");
                    $stmt->bind_param("i", $pageId);
                    
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">Page deleted successfully.</div>';
                    } else {
                        echo '<div class="alert alert-danger">Error deleting page: ' . $stmt->error . '</div>';
                    }
                }
                break;
                
            case 'toggle_status':
                $stmt = $conn->prepare("UPDATE pages SET status = CASE WHEN status = 'published' THEN 'draft' ELSE 'published' END WHERE id = ?");
                $stmt->bind_param("i", $pageId);
                
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success">Page status updated successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger">Error updating page: ' . $stmt->error . '</div>';
                }
                break;
                
            case 'toggle_nav':
                $navColumnExists = false;
                $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
                if ($result && $result->num_rows > 0) {
                    $navColumnExists = true;
                    $stmt = $conn->prepare("UPDATE pages SET show_in_nav = NOT show_in_nav WHERE id = ?");
                    $stmt->bind_param("i", $pageId);
                    
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">Navigation visibility updated successfully.</div>';
                    } else {
                        echo '<div class="alert alert-danger">Error updating navigation visibility: ' . $stmt->error . '</div>';
                    }
                } else {
                    $result = $conn->query("ALTER TABLE pages ADD COLUMN show_in_nav TINYINT(1) NOT NULL DEFAULT 0");
                    if ($result) {
                        $stmt = $conn->prepare("UPDATE pages SET show_in_nav = 1 WHERE id = ?");
                        $stmt->bind_param("i", $pageId);
                        
                        if ($stmt->execute()) {
                            echo '<div class="alert alert-success">Navigation visibility updated successfully.</div>';
                        } else {
                            echo '<div class="alert alert-danger">Error updating navigation visibility: ' . $stmt->error . '</div>';
                        }
                    } else {
                        echo '<div class="alert alert-warning">Could not update navigation visibility. The show_in_nav column does not exist in the database.</div>';
                    }
                }
                break;
        }
    }
    
    $page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM pages");
    $totalPages = $result->fetch_assoc()['count'];
    $totalPagination = ceil($totalPages / $perPage);
    
    $result = $conn->query("SELECT * FROM pages ORDER BY menu_order ASC, created_at DESC LIMIT $offset, $perPage");
    
    $pages = [];
    while ($row = $result->fetch_assoc()) {
        $pages[] = $row;
    }
    
    $navColumnExists = false;
    $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
    if ($result && $result->num_rows > 0) {
        $navColumnExists = true;
    } else {
        $conn->query("ALTER TABLE pages ADD COLUMN show_in_nav TINYINT(1) NOT NULL DEFAULT 0");
        $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
        if ($result && $result->num_rows > 0) {
            $navColumnExists = true;
            echo '<div class="alert alert-success">Added "Show in Navigation" feature to the database.</div>';
        }
    }
    ?>
    
    <div class="admin-actions">
        <a href="index.php?page=admin&action=pages&add=1" class="btn btn-primary">Add New Page</a>
    </div>
    
    <?php if (isset($_GET['add']) || (isset($_GET['edit']) && isset($_GET['page_id']))): ?>
        <?php
        $isEdit = isset($_GET['edit']) && isset($_GET['page_id']);
        $pageId = $isEdit ? (int)$_GET['page_id'] : 0;
        $pageData = null;
        
        if ($isEdit) {
            $stmt = $conn->prepare("SELECT * FROM pages WHERE id = ?");
            $stmt->bind_param("i", $pageId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $pageData = $result->fetch_assoc();
            } else {
                echo '<div class="alert alert-danger">Page not found.</div>';
                $isEdit = false;
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = sanitizeInput($_POST['title']);
            $slug = sanitizeInput($_POST['slug']);
            $content = $_POST['content']; // Don't sanitize WYSIWYG content
            $metaDescription = sanitizeInput($_POST['meta_description']);
            $status = sanitizeInput($_POST['status']);
            $menuOrder = (int)$_POST['menu_order'];
            $isSystemPage = isset($_POST['is_system_page']) ? 1 : 0;
            $showInNav = isset($_POST['show_in_nav']) ? 1 : 0;
            
            $errors = [];
            
            if (empty($title)) {
                $errors[] = "Title is required";
            }
            
            if (empty($slug)) {
                $errors[] = "Slug is required";
            } else {
                if (empty($slug)) {
                    $slug = createSlug($title);
                }
                
                $stmt = $conn->prepare("SELECT id FROM pages WHERE slug = ? AND id != ?");
                $stmt->bind_param("si", $slug, $pageId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $errors[] = "Slug already exists";
                }
            }
            
            if (empty($errors)) {
                if ($isEdit) {
                    $systemPageColumnExists = false;
                    $navColumnExists = false;
                    
                    $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'is_system_page'");
                    if ($result && $result->num_rows > 0) {
                        $systemPageColumnExists = true;
                    }
                    
                    $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
                    if ($result && $result->num_rows > 0) {
                        $navColumnExists = true;
                    }
                    
                    if ($systemPageColumnExists && $navColumnExists) {
                        $stmt = $conn->prepare("UPDATE pages SET title = ?, slug = ?, content = ?, meta_description = ?, status = ?, menu_order = ?, is_system_page = ?, show_in_nav = ? WHERE id = ?");
                        $stmt->bind_param("sssssiiis", $title, $slug, $content, $metaDescription, $status, $menuOrder, $isSystemPage, $showInNav, $pageId);
                    } elseif ($systemPageColumnExists) {
                        $stmt = $conn->prepare("UPDATE pages SET title = ?, slug = ?, content = ?, meta_description = ?, status = ?, menu_order = ?, is_system_page = ? WHERE id = ?");
                        $stmt->bind_param("sssssiis", $title, $slug, $content, $metaDescription, $status, $menuOrder, $isSystemPage, $pageId);
                    } elseif ($navColumnExists) {
                        $stmt = $conn->prepare("UPDATE pages SET title = ?, slug = ?, content = ?, meta_description = ?, status = ?, menu_order = ?, show_in_nav = ? WHERE id = ?");
                        $stmt->bind_param("sssssiiis", $title, $slug, $content, $metaDescription, $status, $menuOrder, $showInNav, $pageId);
                    } else {
                        $stmt = $conn->prepare("UPDATE pages SET title = ?, slug = ?, content = ?, meta_description = ?, status = ?, menu_order = ? WHERE id = ?");
                        $stmt->bind_param("sssssii", $title, $slug, $content, $metaDescription, $status, $menuOrder, $pageId);
                    }
                } else {
                    $systemPageColumnExists = false;
                    $navColumnExists = false;
                    
                    $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'is_system_page'");
                    if ($result && $result->num_rows > 0) {
                        $systemPageColumnExists = true;
                    }
                    
                    $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
                    if ($result && $result->num_rows > 0) {
                        $navColumnExists = true;
                    }
                    
                    if ($systemPageColumnExists && $navColumnExists) {
                        $stmt = $conn->prepare("INSERT INTO pages (title, slug, content, meta_description, status, menu_order, is_system_page, show_in_nav) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssiii", $title, $slug, $content, $metaDescription, $status, $menuOrder, $isSystemPage, $showInNav);
                    } elseif ($systemPageColumnExists) {
                        $stmt = $conn->prepare("INSERT INTO pages (title, slug, content, meta_description, status, menu_order, is_system_page) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssi", $title, $slug, $content, $metaDescription, $status, $menuOrder, $isSystemPage);
                    } elseif ($navColumnExists) {
                        $stmt = $conn->prepare("INSERT INTO pages (title, slug, content, meta_description, status, menu_order, show_in_nav) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssii", $title, $slug, $content, $metaDescription, $status, $menuOrder, $showInNav);
                    } else {
                        $stmt = $conn->prepare("INSERT INTO pages (title, slug, content, meta_description, status, menu_order) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssi", $title, $slug, $content, $metaDescription, $status, $menuOrder);
                    }
                }
                
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success">Page ' . ($isEdit ? 'updated' : 'created') . ' successfully.</div>';
                    echo '<script>window.location.href = "index.php?page=admin&action=pages";</script>';
                } else {
                    $errors[] = "Error " . ($isEdit ? 'updating' : 'creating') . " page: " . $stmt->error;
                }
            }
            
            if (!empty($errors)) {
                echo '<div class="error-container">';
                foreach ($errors as $error) {
                    echo '<p class="error">' . $error . '</p>';
                }
                echo '</div>';
            }
        }
        ?>
        
        <div class="admin-form">
            <h4><?php echo $isEdit ? 'Edit Page' : 'Add New Page'; ?></h4>
            
            <form method="POST">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" value="<?php echo $isEdit ? htmlspecialchars($pageData['title']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" id="slug" name="slug" value="<?php echo $isEdit ? htmlspecialchars($pageData['slug']) : ''; ?>" required>
                    <small>The slug is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</small>
                </div>
                
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea id="content" name="content" class="wysiwyg-editor"><?php echo $isEdit ? $pageData['content'] : ''; ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="meta_description">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" rows="3"><?php echo $isEdit ? htmlspecialchars($pageData['meta_description']) : ''; ?></textarea>
                    <small>The meta description is a short description of the page that appears in search engine results.</small>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="published" <?php echo $isEdit && $pageData['status'] == 'published' ? 'selected' : ''; ?>>Published</option>
                        <option value="draft" <?php echo $isEdit && $pageData['status'] == 'draft' ? 'selected' : ''; ?>>Draft</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="menu_order">Menu Order</label>
                    <input type="number" id="menu_order" name="menu_order" value="<?php echo $isEdit ? (int)$pageData['menu_order'] : 0; ?>" min="0">
                    <small>Pages with lower menu order will appear first in the navigation menu.</small>
                </div>
                
                <?php
                $navColumnExists = false;
                $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'show_in_nav'");
                if ($result && $result->num_rows > 0) {
                    $navColumnExists = true;
                }
                
                if ($navColumnExists):
                ?>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="show_in_nav" <?php 
                            if ($isEdit && isset($pageData['show_in_nav']) && $pageData['show_in_nav'] == 1) {
                                echo 'checked';
                            }
                        ?>>
                        Show in Header Navigation
                    </label>
                    <small>If checked, this page will appear in the main navigation menu in the header.</small>
                </div>
                <?php endif; ?>
                
                <?php
                $systemPageColumnExists = false;
                $result = $conn->query("SHOW COLUMNS FROM pages LIKE 'is_system_page'");
                if ($result && $result->num_rows > 0) {
                    $systemPageColumnExists = true;
                }
                
                if ($systemPageColumnExists):
                ?>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_system_page" <?php 
                            if ($isEdit && isset($pageData['is_system_page']) && $pageData['is_system_page'] == 1) {
                                echo 'checked';
                            }
                        ?>>
                        System Page
                    </label>
                    <small>System pages cannot be deleted and are required for the website to function properly.</small>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo $isEdit ? 'Update Page' : 'Add Page'; ?></button>
                    <a href="index.php?page=admin&action=pages" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    <?php else: ?>
        <?php if (empty($pages)): ?>
            <div class="alert alert-info">No pages found.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Slug</th>
                        <th>Status</th>
                        <th>System Page</th>
                        <?php if ($navColumnExists): ?>
                        <th>In Header</th>
                        <?php endif; ?>
                        <th>Menu Order</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pages as $pageItem): ?>
                        <tr>
                            <td><?php echo $pageItem['id']; ?></td>
                            <td><?php echo htmlspecialchars($pageItem['title']); ?></td>
                            <td><?php echo htmlspecialchars($pageItem['slug']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($pageItem['status'])); ?></td>
                            <td><?php 
                                $isSystemPage = isset($pageItem['is_system_page']) ? $pageItem['is_system_page'] : 0;
                                echo $isSystemPage ? 'Yes' : 'No'; 
                            ?></td>
                            <?php if ($navColumnExists): ?>
                            <td><?php 
                                $showInNav = isset($pageItem['show_in_nav']) ? $pageItem['show_in_nav'] : 0;
                                echo $showInNav ? 'Yes' : 'No'; 
                            ?></td>
                            <?php endif; ?>
                            <td><?php echo (int)$pageItem['menu_order']; ?></td>
                            <td>
                                <a href="index.php?page=admin&action=pages&edit=1&page_id=<?php echo $pageItem['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="index.php?page=admin&action=pages&action=toggle_status&page_id=<?php echo $pageItem['id']; ?>" class="btn btn-sm btn-secondary"><?php echo $pageItem['status'] == 'published' ? 'Unpublish' : 'Publish'; ?></a>
                                <?php if ($navColumnExists): ?>
                                <a href="index.php?page=admin&action=pages&action=toggle_nav&page_id=<?php echo $pageItem['id']; ?>" class="btn btn-sm btn-info">
                                    <?php 
                                        $showInNav = isset($pageItem['show_in_nav']) ? $pageItem['show_in_nav'] : 0;
                                        echo $showInNav ? 'Remove from Header' : 'Add to Header'; 
                                    ?>
                                </a>
                                <?php endif; ?>
                                <?php 
                                $isSystemPage = isset($pageItem['is_system_page']) ? $pageItem['is_system_page'] : 0;
                                if (!$isSystemPage): 
                                ?>
                                <a href="index.php?page=admin&action=pages&action=delete&page_id=<?php echo $pageItem['id']; ?>" class="btn btn-sm btn-tertiary" onclick="return confirmDelete('Are you sure you want to delete this page?')">Delete</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($totalPagination > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPagination; $i++): ?>
                        <a href="index.php?page=admin&action=pages&page_num=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.wysiwyg-editor')) {
        $('.wysiwyg-editor').summernote({
            height: 300,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'italic', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
    }
    
    const titleInput = document.getElementById('title');
    const slugInput = document.getElementById('slug');
    
    if (titleInput && slugInput) {
        titleInput.addEventListener('blur', function() {
            if (slugInput.value === '') {
                slugInput.value = createSlug(titleInput.value);
            }
        });
    }
    
    function createSlug(text) {
        return text.toString().toLowerCase()
            .replace(/\s+/g, '-')           // Replace spaces with -
            .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
            .replace(/\-\-+/g, '-')         // Replace multiple - with single -
            .replace(/^-+/, '')             // Trim - from start of text
            .replace(/-+$/, '');            // Trim - from end of text
    }
});
</script>
