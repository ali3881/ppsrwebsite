<div class="admin-users">
    <h3>User Management</h3>
    
    <?php
    if (isset($_GET['action']) && isset($_GET['user_id'])) {
        $userId = (int)$_GET['user_id'];
        $action = $_GET['action'];
        
        switch ($action) {
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success">User deleted successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger">Error deleting user: ' . $stmt->error . '</div>';
                }
                break;
                
            case 'toggle_admin':
                $adminColumnExists = false;
                $result = $conn->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
                if ($result && $result->num_rows > 0) {
                    $adminColumnExists = true;
                    $stmt = $conn->prepare("UPDATE users SET is_admin = NOT is_admin WHERE id = ?");
                    $stmt->bind_param("i", $userId);
                    
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">User admin status updated successfully.</div>';
                    } else {
                        echo '<div class="alert alert-danger">Error updating user: ' . $stmt->error . '</div>';
                    }
                } else {
                    echo '<div class="alert alert-warning">Admin column does not exist in the database. Please run the database setup script.</div>';
                }
                break;
        }
    }
    
    $page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $totalUsers = $result->fetch_assoc()['count'];
    $totalPages = ceil($totalUsers / $perPage);
    
    $result = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT $offset, $perPage");
    
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    ?>
    
    <div class="admin-actions">
        <a href="index.php?page=admin&action=users&add=1" class="btn btn-primary">Add New User</a>
    </div>
    
    <?php if (isset($_GET['add']) || (isset($_GET['edit']) && isset($_GET['user_id']))): ?>
        <?php
        $isEdit = isset($_GET['edit']) && isset($_GET['user_id']);
        $userId = $isEdit ? (int)$_GET['user_id'] : 0;
        $user = null;
        
        if ($isEdit) {
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
            } else {
                echo '<div class="alert alert-danger">User not found.</div>';
                $isEdit = false;
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $firstNameExists = false;
            $lastNameExists = false;
            $adminColumnExists = false;
            
            $result = $conn->query("SHOW COLUMNS FROM users LIKE 'first_name'");
            if ($result && $result->num_rows > 0) {
                $firstNameExists = true;
            }
            
            $result = $conn->query("SHOW COLUMNS FROM users LIKE 'last_name'");
            if ($result && $result->num_rows > 0) {
                $lastNameExists = true;
            }
            
            $result = $conn->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
            if ($result && $result->num_rows > 0) {
                $adminColumnExists = true;
            }
            
            if (isset($_POST['form_type']) && $_POST['form_type'] === 'change_password') {
                $currentPassword = $_POST['current_password'];
                $newPassword = $_POST['new_password'];
                $confirmPassword = $_POST['confirm_password'];
                
                $errors = [];
                
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                $userData = $result->fetch_assoc();
                
                if (!password_verify($currentPassword, $userData['password'])) {
                    $errors[] = "Current password is incorrect";
                }
                
                if (empty($newPassword)) {
                    $errors[] = "New password is required";
                } elseif (strlen($newPassword) < 8) {
                    $errors[] = "New password must be at least 8 characters long";
                }
                
                if ($newPassword !== $confirmPassword) {
                    $errors[] = "New passwords do not match";
                }
                
                if (empty($errors)) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashedPassword, $userId);
                    
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">Password updated successfully.</div>';
                    } else {
                        $errors[] = "Error updating password: " . $stmt->error;
                    }
                }
                
                if (!empty($errors)) {
                    echo '<div class="error-container">';
                    foreach ($errors as $error) {
                        echo '<p class="error">' . $error . '</p>';
                    }
                    echo '</div>';
                }
            } else {
                $firstName = isset($_POST['first_name']) ? sanitizeInput($_POST['first_name']) : '';
                $lastName = isset($_POST['last_name']) ? sanitizeInput($_POST['last_name']) : '';
                $email = sanitizeInput($_POST['email']);
                $isAdmin = isset($_POST['is_admin']) ? 1 : 0;
                
                $errors = [];
                
                if ($firstNameExists && empty($firstName)) {
                    $errors[] = "First name is required";
                }
                
                if ($lastNameExists && empty($lastName)) {
                    $errors[] = "Last name is required";
                }
                
                if (empty($email)) {
                    $errors[] = "Email is required";
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "Invalid email format";
                }
                
                if (!$isEdit || ($isEdit && $email !== $user['email'])) {
                    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $errors[] = "Email already exists";
                    }
                }
                
                if (!$isEdit) {
                    $password = $_POST['password'];
                    $confirmPassword = $_POST['confirm_password'];
                    
                    if (empty($password)) {
                        $errors[] = "Password is required";
                    } elseif (strlen($password) < 8) {
                        $errors[] = "Password must be at least 8 characters long";
                    }
                    
                    if ($password !== $confirmPassword) {
                        $errors[] = "Passwords do not match";
                    }
                }
                
                if (empty($errors)) {
                    if ($isEdit) {
                        if ($firstNameExists && $lastNameExists && $adminColumnExists) {
                            $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, is_admin = ? WHERE id = ?");
                            $stmt->bind_param("sssis", $firstName, $lastName, $email, $isAdmin, $userId);
                        } elseif ($firstNameExists && $lastNameExists) {
                            $stmt = $conn->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE id = ?");
                            $stmt->bind_param("sssi", $firstName, $lastName, $email, $userId);
                        } else {
                            $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
                            $stmt->bind_param("si", $email, $userId);
                        }
                    } else {
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                        
                        if ($firstNameExists && $lastNameExists && $adminColumnExists) {
                            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, is_admin) VALUES (?, ?, ?, ?, ?)");
                            $stmt->bind_param("ssssi", $firstName, $lastName, $email, $hashedPassword, $isAdmin);
                        } elseif ($firstNameExists && $lastNameExists) {
                            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)");
                            $stmt->bind_param("ssss", $firstName, $lastName, $email, $hashedPassword);
                        } else {
                            $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
                            $stmt->bind_param("ss", $email, $hashedPassword);
                        }
                    }
                    
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success">User ' . ($isEdit ? 'updated' : 'created') . ' successfully.</div>';
                        echo '<script>window.location.href = "index.php?page=admin&action=users";</script>';
                    } else {
                        $errors[] = "Error " . ($isEdit ? 'updating' : 'creating') . " user: " . $stmt->error;
                    }
                }
                
                if (!empty($errors)) {
                    echo '<div class="error-container">';
                    foreach ($errors as $error) {
                        echo '<p class="error">' . $error . '</p>';
                    }
                    echo '</div>';
                }
            }
        }
        ?>
        
        <div class="admin-form">
            <h4><?php echo $isEdit ? 'Edit User' : 'Add New User'; ?></h4>
            
            <?php if ($isEdit): ?>
                <ul class="nav nav-tabs" id="userTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="password-tab" data-toggle="tab" href="#password" role="tab" aria-controls="password" aria-selected="false">Change Password</a>
                    </li>
                </ul>
                
                <div class="tab-content" id="userTabsContent">
                    <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="form_type" value="user_profile">
                
                <?php
                $firstNameExists = false;
                $lastNameExists = false;
                
                $result = $conn->query("SHOW COLUMNS FROM users LIKE 'first_name'");
                if ($result && $result->num_rows > 0) {
                    $firstNameExists = true;
                }
                
                $result = $conn->query("SHOW COLUMNS FROM users LIKE 'last_name'");
                if ($result && $result->num_rows > 0) {
                    $lastNameExists = true;
                }
                
                if ($firstNameExists):
                ?>
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name" value="<?php 
                        $firstNameValue = '';
                        if ($isEdit && isset($user['first_name'])) {
                            $firstNameValue = $user['first_name'];
                        } elseif (isset($_POST['first_name'])) {
                            $firstNameValue = $_POST['first_name'];
                        }
                        echo htmlspecialchars($firstNameValue); 
                    ?>" required>
                </div>
                <?php endif; ?>
                
                <?php if ($lastNameExists): ?>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name" value="<?php 
                        $lastNameValue = '';
                        if ($isEdit && isset($user['last_name'])) {
                            $lastNameValue = $user['last_name'];
                        } elseif (isset($_POST['last_name'])) {
                            $lastNameValue = $_POST['last_name'];
                        }
                        echo htmlspecialchars($lastNameValue); 
                    ?>" required>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php 
                        $emailValue = '';
                        if ($isEdit && isset($user['email'])) {
                            $emailValue = $user['email'];
                        } elseif (isset($_POST['email'])) {
                            $emailValue = $_POST['email'];
                        }
                        echo htmlspecialchars($emailValue); 
                    ?>" required>
                </div>
                
                <?php if (!$isEdit): ?>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                        <small>Password must be at least 8 characters long</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                <?php endif; ?>
                
                <?php
                $adminColumnExists = false;
                $result = $conn->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
                if ($result && $result->num_rows > 0) {
                    $adminColumnExists = true;
                }
                
                if ($adminColumnExists):
                ?>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_admin" <?php 
                            if ($isEdit && isset($user['is_admin']) && $user['is_admin'] == 1) {
                                echo 'checked';
                            }
                        ?>>
                        Admin User
                    </label>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo $isEdit ? 'Update User' : 'Add User'; ?></button>
                    <a href="index.php?page=admin&action=users" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
            
            <?php if ($isEdit): ?>
                    </div>
                    <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                        <form method="POST">
                            <input type="hidden" name="form_type" value="change_password">
                            
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" required>
                                <small>Password must be at least 8 characters long</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Change Password</button>
                                <a href="index.php?page=admin&action=users" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <?php if (empty($users)): ?>
            <div class="alert alert-info">No users found.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Admin</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php 
                                $name = '';
                                if (isset($user['first_name']) && isset($user['last_name'])) {
                                    $name = htmlspecialchars($user['first_name'] . ' ' . $user['last_name']);
                                } elseif (isset($user['name'])) {
                                    $name = htmlspecialchars($user['name']);
                                } else {
                                    $name = htmlspecialchars($user['email']);
                                }
                                echo $name;
                            ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo isset($user['is_admin']) ? ($user['is_admin'] ? 'Yes' : 'No') : 'No'; ?></td>
                            <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            <td>
                                <a href="index.php?page=admin&action=users&edit=1&user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <?php
                                $adminColumnExists = false;
                                $result = $conn->query("SHOW COLUMNS FROM users LIKE 'is_admin'");
                                if ($result && $result->num_rows > 0) {
                                    $adminColumnExists = true;
                                }
                                
                                if ($adminColumnExists):
                                ?>
                                <a href="index.php?page=admin&action=users&action=toggle_admin&user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-secondary"><?php echo isset($user['is_admin']) && $user['is_admin'] ? 'Remove Admin' : 'Make Admin'; ?></a>
                                <?php endif; ?>
                                <a href="index.php?page=admin&action=users&action=delete&user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-tertiary" onclick="return confirmDelete('Are you sure you want to delete this user?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="index.php?page=admin&action=users&page_num=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var tabLinks = document.querySelectorAll('.nav-link');
    
    tabLinks.forEach(function(tabLink) {
        tabLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            tabLinks.forEach(function(link) {
                link.classList.remove('active');
                link.setAttribute('aria-selected', 'false');
            });
            
            this.classList.add('active');
            this.setAttribute('aria-selected', 'true');
            
            var targetId = this.getAttribute('href');
            var targetTab = document.querySelector(targetId);
            
            document.querySelectorAll('.tab-pane').forEach(function(tabPane) {
                tabPane.classList.remove('show', 'active');
            });
            
            targetTab.classList.add('show', 'active');
        });
    });
});
</script>
