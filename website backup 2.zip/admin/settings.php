<?php
/**
 * Admin Settings Page
 * 
 * This file handles the admin settings functionality for the PPSR website.
 * It includes forms for updating general, appearance, payment, and API settings.
 */

if (file_exists(__DIR__ . '/../includes/functions.php')) {
    require_once __DIR__ . '/../includes/functions.php';
} elseif (file_exists(__DIR__ . '/functions.php')) {
    require_once __DIR__ . '/functions.php';
} elseif (file_exists('includes/functions.php')) {
    require_once 'includes/functions.php';
} elseif (file_exists('functions.php')) {
    require_once 'functions.php';
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}

function getSettingValue($key, $default = '') {
    global $conn;
    $value = $default;
    
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        if ($stmt) {
            $stmt->bind_param("s", $key);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $value = $row['setting_value'];
                return $value;
            }
        }
    } catch (Exception $e) {
        error_log("Error getting setting with setting_key: " . $e->getMessage());
    }
    
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_name = ?");
        if ($stmt) {
            $stmt->bind_param("s", $key);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $value = $row['setting_value'];
                return $value;
            }
        }
    } catch (Exception $e) {
        error_log("Error getting setting with setting_name: " . $e->getMessage());
    }
    
    $constantName = strtoupper($key);
    if (defined($constantName)) {
        $value = constant($constantName);
    }
    
    return $value;
}

function updateSettingInDatabase($key, $value) {
    global $conn;
    $updated = false;
    
    error_log("Updating setting in database: $key = $value");
    
    try {
        $stmt = $conn->prepare("SELECT id FROM settings WHERE setting_key = ?");
        if ($stmt) {
            $stmt->bind_param("s", $key);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                error_log("Found setting with setting_key: $key");
                $updateStmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("ss", $value, $key);
                    $updated = $updateStmt->execute();
                    error_log("Updated setting with setting_key: $key, result: " . ($updated ? 'success' : 'failed'));
                }
                return $updated;
            } else {
                error_log("No setting found with setting_key: $key");
            }
        }
    } catch (Exception $e) {
        error_log("Error checking/updating setting with setting_key: " . $e->getMessage());
    }
    
    try {
        $stmt = $conn->prepare("SELECT id FROM settings WHERE setting_name = ?");
        if ($stmt) {
            $stmt->bind_param("s", $key);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                error_log("Found setting with setting_name: $key");
                $updateStmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_name = ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("ss", $value, $key);
                    $updated = $updateStmt->execute();
                    error_log("Updated setting with setting_name: $key, result: " . ($updated ? 'success' : 'failed'));
                }
                return $updated;
            } else {
                error_log("No setting found with setting_name: $key");
            }
        }
    } catch (Exception $e) {
        error_log("Error checking/updating setting with setting_name: " . $e->getMessage());
    }
    
    try {
        $columnName = "setting_key";
        $columnsResult = $conn->query("SHOW COLUMNS FROM settings LIKE 'setting_key'");
        if (!$columnsResult || $columnsResult->num_rows === 0) {
            $columnName = "setting_name";
            error_log("Using column name: setting_name for insert");
        } else {
            error_log("Using column name: setting_key for insert");
        }
        
        $insertStmt = $conn->prepare("INSERT INTO settings ($columnName, setting_value) VALUES (?, ?)");
        if ($insertStmt) {
            $insertStmt->bind_param("ss", $key, $value);
            $updated = $insertStmt->execute();
            error_log("Inserted new setting: $key = $value, result: " . ($updated ? 'success' : 'failed'));
        }
    } catch (Exception $e) {
        error_log("Error inserting setting: " . $e->getMessage());
    }
    
    return $updated;
}

$searchFeeValue = getSettingValue('search_fee', '25.00');

$generalSettings = [
    'site_name' => [
        'label' => 'Site Name',
        'type' => 'text',
        'value' => defined('SITE_NAME') ? SITE_NAME : getSettingValue('site_name', 'PPSR Search'),
        'description' => 'The name of the website'
    ],
    'site_description' => [
        'label' => 'Site Description',
        'type' => 'textarea',
        'value' => defined('SITE_DESCRIPTION') ? SITE_DESCRIPTION : getSettingValue('site_description', ''),
        'description' => 'A brief description of the website'
    ],
    'admin_email' => [
        'label' => 'Admin Email',
        'type' => 'email',
        'value' => defined('ADMIN_EMAIL') ? ADMIN_EMAIL : getSettingValue('admin_email', 'admin@example.com'),
        'description' => 'The email address for admin notifications'
    ],
    'search_fee' => [
        'label' => 'Search Fee (AUD)',
        'type' => 'number',
        'value' => $searchFeeValue,
        'description' => 'The fee charged for each PPSR search'
    ]
];

$appearanceSettings = [
    'primary_color' => [
        'label' => 'Primary Color',
        'type' => 'color',
        'value' => defined('PRIMARY_COLOR') ? PRIMARY_COLOR : getSettingValue('primary_color', '#0056b3'),
        'description' => 'Primary color for buttons and highlights'
    ],
    'secondary_color' => [
        'label' => 'Secondary Color',
        'type' => 'color',
        'value' => defined('SECONDARY_COLOR') ? SECONDARY_COLOR : getSettingValue('secondary_color', '#6c757d'),
        'description' => 'Secondary color for accents and less prominent elements'
    ],
    'background_color' => [
        'label' => 'Background Color',
        'type' => 'color',
        'value' => defined('BACKGROUND_COLOR') ? BACKGROUND_COLOR : getSettingValue('background_color', '#f8f9fa'),
        'description' => 'Background color for the website'
    ],
    'text_color' => [
        'label' => 'Text Color',
        'type' => 'color',
        'value' => defined('TEXT_COLOR') ? TEXT_COLOR : getSettingValue('text_color', '#212529'),
        'description' => 'Main text color'
    ],
    'logo' => [
        'label' => 'Logo',
        'type' => 'file',
        'value' => defined('LOGO_PATH') ? LOGO_PATH : getSettingValue('logo', ''),
        'description' => 'Upload your website logo (recommended size: 200x50px)'
    ],
    'favicon' => [
        'label' => 'Favicon',
        'type' => 'file',
        'value' => defined('FAVICON_PATH') ? FAVICON_PATH : getSettingValue('favicon', ''),
        'description' => 'Upload your website favicon (must be .ico format, 16x16px or 32x32px)'
    ],
    'custom_css' => [
        'label' => 'Custom CSS',
        'type' => 'textarea',
        'value' => defined('CUSTOM_CSS') ? CUSTOM_CSS : getSettingValue('custom_css', ''),
        'description' => 'Add custom CSS to customize your website appearance'
    ]
];

$paymentSettings = [
    'payment_gateway' => [
        'label' => 'Payment Gateway',
        'type' => 'select',
        'options' => [
            'stripe' => 'Stripe'
        ],
        'value' => defined('PAYMENT_GATEWAY') ? PAYMENT_GATEWAY : getSettingValue('payment_gateway', 'stripe'),
        'description' => 'The payment gateway to use for processing payments'
    ],
    'stripe_public_key' => [
        'label' => 'Stripe Public Key',
        'type' => 'text',
        'value' => defined('STRIPE_PUBLIC_KEY') ? STRIPE_PUBLIC_KEY : getSettingValue('stripe_public_key', ''),
        'description' => 'The public key for Stripe integration'
    ],
    'stripe_secret_key' => [
        'label' => 'Stripe Secret Key',
        'type' => 'password',
        'value' => defined('STRIPE_SECRET_KEY') ? STRIPE_SECRET_KEY : getSettingValue('stripe_secret_key', ''),
        'description' => 'The secret key for Stripe integration'
    ]
];

$apiSettings = [
    'ppsr_account_name' => [
        'label' => 'PPSR Account Name',
        'type' => 'text',
        'value' => defined('PPSR_ACCOUNT_NAME') ? PPSR_ACCOUNT_NAME : getSettingValue('ppsr_account_name', ''),
        'description' => 'The account name for PPSR API access'
    ],
    'ppsr_account_number' => [
        'label' => 'PPSR Account Number',
        'type' => 'text',
        'value' => defined('PPSR_ACCOUNT_NUMBER') ? PPSR_ACCOUNT_NUMBER : getSettingValue('ppsr_account_number', ''),
        'description' => 'The account number for PPSR API access'
    ],
    'ppsr_username' => [
        'label' => 'PPSR Username',
        'type' => 'text',
        'value' => defined('PPSR_USERNAME') ? PPSR_USERNAME : getSettingValue('ppsr_username', ''),
        'description' => 'The username for PPSR API access'
    ],
    'ppsr_password' => [
        'label' => 'PPSR Password',
        'type' => 'password',
        'value' => defined('PPSR_PASSWORD') ? PPSR_PASSWORD : getSettingValue('ppsr_password', ''),
        'description' => 'The password for PPSR API access'
    ],
    'ppsr_endpoint' => [
        'label' => 'PPSR Endpoint URL',
        'type' => 'text',
        'value' => defined('PPSR_ENDPOINT') ? PPSR_ENDPOINT : getSettingValue('ppsr_endpoint', ''),
        'description' => 'The endpoint URL for PPSR API access'
    ],
    'ppsr_soap_action' => [
        'label' => 'PPSR SOAP Action',
        'type' => 'text',
        'value' => defined('PPSR_SOAP_ACTION') ? PPSR_SOAP_ACTION : getSettingValue('ppsr_soap_action', ''),
        'description' => 'The SOAP action for PPSR API access'
    ],
    'use_real_xml_data' => [
        'label' => 'Use Real XML Data',
        'type' => 'select',
        'options' => [
            '0' => 'No (Use Mock Data)',
            '1' => 'Yes (Use Real API Data)'
        ],
        'value' => defined('USE_REAL_XML_DATA') ? USE_REAL_XML_DATA : getSettingValue('use_real_xml_data', '0'),
        'description' => 'Toggle between mock data and real PPSR API data. Use mock data for testing and development.'
    ]
];

$settings = array_merge($generalSettings, $appearanceSettings, $paymentSettings, $apiSettings);

$uploadsDir = __DIR__ . '/../uploads';
$uploadsUrl = '../uploads';

if (!file_exists($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}

if (!file_exists($uploadsDir . '/logos')) {
    mkdir($uploadsDir . '/logos', 0755, true);
}

if (!file_exists($uploadsDir . '/favicons')) {
    mkdir($uploadsDir . '/favicons', 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    $updates = [];
    
    if (!isset($_POST['use_real_xml_data'])) {
        $_POST['use_real_xml_data'] = '0'; // Default to mock data if not set
    }
    
    error_log("POST data: " . print_r($_POST, true));
    
    echo '<div style="background-color: #f8d7da; padding: 10px; margin-bottom: 20px; border-radius: 5px;">';
    echo '<h4>Debug Information</h4>';
    echo '<p>POST data: <pre>' . print_r($_POST, true) . '</pre></p>';
    
    foreach (array_merge($generalSettings, $paymentSettings, $apiSettings, $appearanceSettings) as $key => $setting) {
        if (isset($_POST[$key]) && $setting['type'] !== 'file') {
            $value = sanitizeInput($_POST[$key]);
            
            error_log("Processing setting: $key = $value");
            echo '<p>Processing setting: ' . $key . ' = ' . $value . '</p>';
            
            switch ($setting['type']) {
                case 'email':
                    if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = $setting['label'] . ' must be a valid email address';
                    }
                    break;
                case 'number':
                    if (!empty($value) && !is_numeric($value)) {
                        $errors[] = $setting['label'] . ' must be a number';
                    }
                    break;
            }
            
            $updates[$key] = $value;
        } else {
            error_log("Setting not in POST or is file: $key");
        }
    }
    
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $logoInfo = pathinfo($_FILES['logo']['name']);
        $logoExtension = strtolower($logoInfo['extension']);
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($logoExtension, $allowedExtensions)) {
            $logoFilename = 'logo_' . time() . '.' . $logoExtension;
            $logoPath = $uploadsDir . '/logos/' . $logoFilename;
            
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $logoPath)) {
                $updates['logo'] = $uploadsUrl . '/logos/' . $logoFilename;
            } else {
                $errors[] = 'Failed to upload logo. Please try again.';
            }
        } else {
            $errors[] = 'Logo must be a JPG, JPEG, PNG, or GIF file.';
        }
    }
    
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] == 0) {
        $faviconInfo = pathinfo($_FILES['favicon']['name']);
        $faviconExtension = strtolower($faviconInfo['extension']);
        
        $allowedExtensions = ['ico', 'png'];
        
        if (in_array($faviconExtension, $allowedExtensions)) {
            $faviconFilename = 'favicon_' . time() . '.' . $faviconExtension;
            $faviconPath = $uploadsDir . '/favicons/' . $faviconFilename;
            
            if (move_uploaded_file($_FILES['favicon']['tmp_name'], $faviconPath)) {
                $updates['favicon'] = $uploadsUrl . '/favicons/' . $faviconFilename;
            } else {
                $errors[] = 'Failed to upload favicon. Please try again.';
            }
        } else {
            $errors[] = 'Favicon must be an ICO or PNG file.';
        }
    }
    
    if (empty($errors)) {
        $configFile = __DIR__ . '/../includes/config.php';
        $configContent = file_get_contents($configFile);
        $dbUpdates = [];
        
        foreach ($updates as $key => $value) {
            if (empty($value)) {
                continue;
            }
            
            $constantName = strtoupper($key);
            
            if (defined($constantName)) {
                $pattern = "/define\s*\(\s*['\"]" . $constantName . "['\"].*?\);/s";
                $replacement = "define('" . $constantName . "', '" . addslashes($value) . "');";
                $configContent = preg_replace($pattern, $replacement, $configContent);
            } else {
                $newConstant = "\ndefine('" . $constantName . "', '" . addslashes($value) . "');";
                $configContent = str_replace('?>', $newConstant . "\n?>", $configContent);
            }
            
            $dbUpdates[$key] = $value;
        }
        
        $configUpdateSuccess = file_put_contents($configFile, $configContent);
        $dbUpdateSuccess = true;
        
        echo '<h4>Database Updates</h4>';
        if (isset($_POST['use_real_xml_data'])) {
            $useRealXmlData = sanitizeInput($_POST['use_real_xml_data']);
            $dbUpdates['use_real_xml_data'] = $useRealXmlData;
            
            $configFile = __DIR__ . '/../includes/config.php';
            $configContent = file_get_contents($configFile);
            $pattern = "/define\s*\(\s*['\"](USE_REAL_XML_DATA)['\"].*?\);/s";
            $replacement = "define('USE_REAL_XML_DATA', '$useRealXmlData');";
            $configContent = preg_replace($pattern, $replacement, $configContent);
            file_put_contents($configFile, $configContent);
            
            echo '<p style="color: green;"><strong>Directly updated USE_REAL_XML_DATA in config.php to: ' . $useRealXmlData . '</strong></p>';
        }
        
        foreach ($dbUpdates as $key => $value) {
            error_log("Attempting to update database setting: $key = $value");
            echo '<p>Attempting to update database setting: ' . $key . ' = ' . $value . '</p>';
            
            if ($key === 'use_real_xml_data') {
                error_log("Special handling for use_real_xml_data: $value");
                echo '<p><strong>Special handling for use_real_xml_data:</strong> ' . $value . '</p>';
                
                $columnsResult = $conn->query("SHOW COLUMNS FROM settings LIKE 'setting_key'");
                $columnName = ($columnsResult && $columnsResult->num_rows > 0) ? 'setting_key' : 'setting_name';
                
                echo '<p>Using column name: ' . $columnName . ' for database update</p>';
                
                $directResult = $conn->query("UPDATE settings SET setting_value = '$value' WHERE $columnName = 'use_real_xml_data'");
                if ($directResult) {
                    echo '<p style="color: green;">Successfully updated use_real_xml_data in database using direct query</p>';
                } else {
                    $directInsert = $conn->query("INSERT INTO settings ($columnName, setting_value) VALUES ('use_real_xml_data', '$value')");
                    if ($directInsert) {
                        echo '<p style="color: green;">Successfully inserted use_real_xml_data in database using direct query</p>';
                    } else {
                        echo '<p style="color: red;">Failed to update use_real_xml_data in database: ' . $conn->error . '</p>';
                    }
                }
                
                continue;
            }
            
            $dbUpdateResult = updateSettingInDatabase($key, $value);
            if (!$dbUpdateResult) {
                $dbUpdateSuccess = false;
                error_log("Failed to update setting in database: $key");
                echo '<p style="color: red;">Failed to update setting in database: ' . $key . '</p>';
            } else {
                echo '<p style="color: green;">Successfully updated setting in database: ' . $key . '</p>';
            }
        }
        
        if ($configUpdateSuccess && $dbUpdateSuccess) {
            echo '<div class="alert alert-success">Settings updated successfully. Refresh the page to see changes.</div>';
        } elseif ($configUpdateSuccess) {
            echo '<div class="alert alert-warning">Settings updated in config file but some database updates failed. Some changes may not be visible until you restart the application.</div>';
        } elseif ($dbUpdateSuccess) {
            echo '<div class="alert alert-warning">Settings updated in database but config file update failed. Some changes may not be visible until you restart the application.</div>';
        } else {
            $errors[] = 'Failed to update settings. Please check file and database permissions.';
        }
    }
    
    if (!empty($errors)) {
        echo '<div class="error-container">';
        foreach ($errors as $error) {
            echo '<p class="error">' . $error . '</p>';
        }
        echo '</div>';
    }
}
?>

<div class="admin-settings">
    <h3>System Settings</h3>
    
    <form method="POST" class="settings-form" enctype="multipart/form-data" action="index.php?page=admin&action=settings">
        <!-- Hidden field to ensure use_real_xml_data is always submitted -->
        <input type="hidden" name="use_real_xml_data" value="0" id="default_use_real_xml_data">
        <div class="settings-section">
            <h4>General Settings</h4>
            <?php foreach ($generalSettings as $key => $setting): ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                    
                    <?php if ($setting['type'] === 'select'): ?>
                        <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                            <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                <option value="<?php echo $optionValue; ?>" <?php echo $optionValue == $setting['value'] ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($setting['type'] === 'textarea'): ?>
                        <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" rows="3"><?php echo htmlspecialchars($setting['value']); ?></textarea>
                    <?php else: ?>
                        <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['value']); ?>" class="form-control">
                    <?php endif; ?>
                    
                    <small><?php echo $setting['description']; ?></small>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="settings-section">
            <h4>Appearance Settings</h4>
            <?php foreach ($appearanceSettings as $key => $setting): ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                    
                    <?php if ($setting['type'] === 'select'): ?>
                        <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                            <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                <option value="<?php echo $optionValue; ?>" <?php echo $optionValue == $setting['value'] ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($setting['type'] === 'textarea'): ?>
                        <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" rows="5"><?php echo htmlspecialchars($setting['value']); ?></textarea>
                    <?php elseif ($setting['type'] === 'file'): ?>
                        <div class="file-upload-container">
                            <?php if (!empty($setting['value'])): ?>
                                <div class="current-file">
                                    <?php if ($key === 'logo'): ?>
                                        <img src="<?php echo $setting['value']; ?>" alt="Current Logo" style="max-height: 50px;">
                                    <?php elseif ($key === 'favicon'): ?>
                                        <img src="<?php echo $setting['value']; ?>" alt="Current Favicon" style="max-height: 32px;">
                                    <?php endif; ?>
                                    <span>Current file: <?php echo basename($setting['value']); ?></span>
                                </div>
                            <?php endif; ?>
                            <input type="file" id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control-file">
                        </div>
                    <?php else: ?>
                        <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['value']); ?>" class="form-control">
                    <?php endif; ?>
                    
                    <small><?php echo $setting['description']; ?></small>
                </div>
            <?php endforeach; ?>
            
            <div class="color-preview">
                <h5>Color Preview</h5>
                <div class="preview-box" style="background-color: <?php echo defined('BACKGROUND_COLOR') ? BACKGROUND_COLOR : '#f8f9fa'; ?>; color: <?php echo defined('TEXT_COLOR') ? TEXT_COLOR : '#212529'; ?>; padding: 15px; border-radius: 5px;">
                    <div style="background-color: <?php echo defined('PRIMARY_COLOR') ? PRIMARY_COLOR : '#0056b3'; ?>; color: white; padding: 10px; border-radius: 3px; margin-bottom: 10px;">Primary Button</div>
                    <div style="background-color: <?php echo defined('SECONDARY_COLOR') ? SECONDARY_COLOR : '#6c757d'; ?>; color: white; padding: 10px; border-radius: 3px;">Secondary Button</div>
                </div>
            </div>
        </div>
        
        <div class="settings-section">
            <h4>Payment Settings</h4>
            <?php foreach ($paymentSettings as $key => $setting): ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                    
                    <?php if ($setting['type'] === 'select'): ?>
                        <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                            <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                <option value="<?php echo $optionValue; ?>" <?php echo $optionValue == $setting['value'] ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($setting['type'] === 'textarea'): ?>
                        <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" rows="3"><?php echo htmlspecialchars($setting['value']); ?></textarea>
                    <?php else: ?>
                        <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['value']); ?>" class="form-control">
                    <?php endif; ?>
                    
                    <small><?php echo $setting['description']; ?></small>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="settings-section" id="xml_settings">
            <h4>API Settings</h4>
            <?php foreach ($apiSettings as $key => $setting): ?>
                <div class="form-group">
                    <label for="<?php echo $key; ?>"><?php echo $setting['label']; ?></label>
                    
                    <?php if ($setting['type'] === 'select'): ?>
                        <select id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control">
                            <?php foreach ($setting['options'] as $optionValue => $optionLabel): ?>
                                <option value="<?php echo $optionValue; ?>" <?php echo $optionValue == $setting['value'] ? 'selected' : ''; ?>><?php echo $optionLabel; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php elseif ($setting['type'] === 'textarea'): ?>
                        <textarea id="<?php echo $key; ?>" name="<?php echo $key; ?>" class="form-control" rows="3"><?php echo htmlspecialchars($setting['value']); ?></textarea>
                    <?php else: ?>
                        <input type="<?php echo $setting['type']; ?>" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['value']); ?>" class="form-control">
                    <?php endif; ?>
                    
                    <small><?php echo $setting['description']; ?></small>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Save Settings</button>
        </div>
    </form>
    
    <div class="admin-section">
        <h4>System Information</h4>
        
        <div class="system-info">
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
            <p><strong>MySQL Version:</strong> <?php echo $conn->server_info; ?></p>
            <p><strong>Server Software:</strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
            <p><strong>Document Root:</strong> <?php echo $_SERVER['DOCUMENT_ROOT']; ?></p>
        </div>
    </div>
</div>

<script>

</script>
