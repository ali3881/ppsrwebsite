<?php
/**
 * PPSR XML Manager
 * 
 * This file provides functionality to download and upload PPSR API XML files.
 * It allows administrators to export raw XML responses from successful PPSR API queries,
 * upload XML files for testing or data restoration, and view stored XML data.
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$functionsIncluded = false;
$possiblePaths = ['../includes/functions.php', 'includes/functions.php', 'functions.php'];
foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $functionsIncluded = true;
        break;
    }
}

$isAdminIncluded = false;
$possibleIsAdminPaths = ['../includes/functions-isadmin.php', 'includes/functions-isadmin.php', 'functions-isadmin.php'];
foreach ($possibleIsAdminPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $isAdminIncluded = true;
        break;
    }
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($input) {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        return $input;
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin($conn = null) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
}

if (file_exists('../includes/config.php')) {
    require_once '../includes/config.php';
} elseif (file_exists('includes/config.php')) {
    require_once 'includes/config.php';
} else {
    die("Configuration file not found");
}

if (!isset($_SESSION['user_id']) || !isAdmin($conn)) {
    header('Location: ../index.php?page=login');
    exit;
}

$xmlDir = '../xml_storage';
if (!file_exists($xmlDir)) {
    mkdir($xmlDir, 0755, true);
}

if (isset($_POST['upload_xml']) && isset($_FILES['xml_file'])) {
    $file = $_FILES['xml_file'];
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $fileName = sanitizeInput($file['name']);
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileType = $file['type'];
        
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if ($fileExt === 'xml') {
            $xmlContent = file_get_contents($fileTmpName);
            if (simplexml_load_string($xmlContent) !== false) {
                $newFileName = 'uploaded_' . date('YmdHis') . '_' . $fileName;
                $destination = $xmlDir . '/' . $newFileName;
                
                if (move_uploaded_file($fileTmpName, $destination)) {
                    try {
                        $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
                        if ($result && $result->num_rows > 0) {
                            $stmt = $conn->prepare("INSERT INTO api_xml (filename, content, upload_date, user_id) VALUES (?, ?, NOW(), ?)");
                            $stmt->bind_param("ssi", $newFileName, $xmlContent, $_SESSION['user_id']);
                            $stmt->execute();
                        }
                    } catch (Exception $e) {
                    }
                    
                    $successMessage = "XML file uploaded successfully.";
                } else {
                    $errorMessage = "Failed to move uploaded file.";
                }
            } else {
                $errorMessage = "Invalid XML file. Please upload a valid XML file.";
            }
        } else {
            $errorMessage = "Only XML files are allowed.";
        }
    } else {
        $errorMessage = "Error uploading file: " . getUploadErrorMessage($file['error']);
    }
}

if (isset($_GET['download']) && !empty($_GET['download'])) {
    $fileId = sanitizeInput($_GET['download']);
    
    if (is_numeric($fileId)) {
        try {
            $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
            if ($result && $result->num_rows > 0) {
                $stmt = $conn->prepare("SELECT filename, content FROM api_xml WHERE id = ?");
                $stmt->bind_param("i", $fileId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $fileName = $row['filename'];
                    $content = $row['content'];
                    
                    header('Content-Type: application/xml');
                    header('Content-Disposition: attachment; filename="' . $fileName . '"');
                    header('Content-Length: ' . strlen($content));
                    echo $content;
                    exit;
                }
            }
        } catch (Exception $e) {
            $errorMessage = "Error retrieving XML file: " . $e->getMessage();
        }
    } else {
        $filePath = $xmlDir . '/' . $fileId;
        if (file_exists($filePath)) {
            header('Content-Type: application/xml');
            header('Content-Disposition: attachment; filename="' . $fileId . '"');
            header('Content-Length: ' . filesize($filePath));
            readfile($filePath);
            exit;
        }
    }
    
    $errorMessage = "XML file not found.";
}

if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $fileId = sanitizeInput($_GET['delete']);
    
    if (is_numeric($fileId)) {
        try {
            $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
            if ($result && $result->num_rows > 0) {
                $stmt = $conn->prepare("SELECT filename FROM api_xml WHERE id = ?");
                $stmt->bind_param("i", $fileId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $fileName = $row['filename'];
                    
                    $filePath = $xmlDir . '/' . $fileName;
                    if (file_exists($filePath)) {
                        unlink($filePath);
                    }
                    
                    $stmt = $conn->prepare("DELETE FROM api_xml WHERE id = ?");
                    $stmt->bind_param("i", $fileId);
                    $stmt->execute();
                    
                    $successMessage = "XML file deleted successfully.";
                } else {
                    $errorMessage = "XML file not found in database.";
                }
            }
        } catch (Exception $e) {
            $errorMessage = "Error deleting XML file: " . $e->getMessage();
        }
    } else {
        $filePath = $xmlDir . '/' . $fileId;
        if (file_exists($filePath)) {
            if (unlink($filePath)) {
                $successMessage = "XML file deleted successfully.";
            } else {
                $errorMessage = "Failed to delete XML file.";
            }
        } else {
            $errorMessage = "XML file not found.";
        }
    }
}

function getUploadErrorMessage($errorCode) {
    switch ($errorCode) {
        case UPLOAD_ERR_INI_SIZE:
            return "The uploaded file exceeds the upload_max_filesize directive in php.ini.";
        case UPLOAD_ERR_FORM_SIZE:
            return "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.";
        case UPLOAD_ERR_PARTIAL:
            return "The uploaded file was only partially uploaded.";
        case UPLOAD_ERR_NO_FILE:
            return "No file was uploaded.";
        case UPLOAD_ERR_NO_TMP_DIR:
            return "Missing a temporary folder.";
        case UPLOAD_ERR_CANT_WRITE:
            return "Failed to write file to disk.";
        case UPLOAD_ERR_EXTENSION:
            return "A PHP extension stopped the file upload.";
        default:
            return "Unknown upload error.";
    }
}

$dbXmlFiles = [];
try {
    $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
    if ($result && $result->num_rows > 0) {
        $result = $conn->query("SELECT id, filename, upload_date, user_id FROM api_xml ORDER BY upload_date DESC");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $dbXmlFiles[] = $row;
            }
        }
    }
} catch (Exception $e) {
}

$dirXmlFiles = [];
if (is_dir($xmlDir)) {
    $files = scandir($xmlDir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..' && pathinfo($file, PATHINFO_EXTENSION) === 'xml') {
            $filePath = $xmlDir . '/' . $file;
            $dirXmlFiles[] = [
                'filename' => $file,
                'size' => filesize($filePath),
                'modified' => date('Y-m-d H:i:s', filemtime($filePath))
            ];
        }
    }
}

function getUserEmail($userId, $conn) {
    if (!$userId) return 'Guest';
    
    $stmt = $conn->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['email'];
    }
    
    return 'Unknown';
}

function formatDate($date) {
    return date('Y-m-d H:i:s', strtotime($date));
}

function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

if (isset($_GET['extract']) && $_GET['extract'] === 'searches') {
    try {
        $result = $conn->query("SHOW TABLES LIKE 'searches'");
        if ($result && $result->num_rows > 0) {
            $result = $conn->query("SHOW COLUMNS FROM searches LIKE 'result'");
            if ($result && $result->num_rows > 0) {
                $result = $conn->query("SELECT id, identifier, result FROM searches ORDER BY id DESC");
                if ($result) {
                    $extractedCount = 0;
                    while ($row = $result->fetch_assoc()) {
                        $searchData = json_decode($row['result'], true);
                        if (isset($searchData['xml']) && !empty($searchData['xml'])) {
                            $xml = $searchData['xml'];
                            $fileName = 'search_' . $row['id'] . '_' . $row['identifier'] . '.xml';
                            $filePath = $xmlDir . '/' . $fileName;
                            
                            if (!file_exists($filePath)) {
                                file_put_contents($filePath, $xml);
                                $extractedCount++;
                                
                                try {
                                    $result2 = $conn->query("SHOW TABLES LIKE 'api_xml'");
                                    if ($result2 && $result2->num_rows > 0) {
                                        $stmt = $conn->prepare("INSERT INTO api_xml (filename, content, upload_date, search_id) VALUES (?, ?, NOW(), ?)");
                                        $stmt->bind_param("ssi", $fileName, $xml, $row['id']);
                                        $stmt->execute();
                                    }
                                } catch (Exception $e) {
                                }
                            }
                        }
                    }
                    
                    if ($extractedCount > 0) {
                        $successMessage = "Successfully extracted $extractedCount XML files from searches.";
                    } else {
                        $infoMessage = "No new XML files found in searches.";
                    }
                }
            }
        }
    } catch (Exception $e) {
        $errorMessage = "Error extracting XML from searches: " . $e->getMessage();
    }
}

if (isset($_GET['create_table']) && $_GET['create_table'] === 'api_xml') {
    try {
        $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
        if ($result && $result->num_rows === 0) {
            $sql = "CREATE TABLE api_xml (
                id INT(11) NOT NULL AUTO_INCREMENT,
                filename VARCHAR(255) NOT NULL,
                content LONGTEXT NOT NULL,
                upload_date DATETIME NOT NULL,
                user_id INT(11) DEFAULT NULL,
                search_id INT(11) DEFAULT NULL,
                PRIMARY KEY (id)
            )";
            
            if ($conn->query($sql) === TRUE) {
                $successMessage = "api_xml table created successfully.";
            } else {
                $errorMessage = "Error creating api_xml table: " . $conn->error;
            }
        } else {
            $infoMessage = "api_xml table already exists.";
        }
    } catch (Exception $e) {
        $errorMessage = "Error creating api_xml table: " . $e->getMessage();
    }
}

$viewXmlContent = '';
$viewXmlFilename = '';
if (isset($_GET['view']) && !empty($_GET['view'])) {
    $fileId = sanitizeInput($_GET['view']);
    
    if (is_numeric($fileId)) {
        try {
            $result = $conn->query("SHOW TABLES LIKE 'api_xml'");
            if ($result && $result->num_rows > 0) {
                $stmt = $conn->prepare("SELECT filename, content FROM api_xml WHERE id = ?");
                $stmt->bind_param("i", $fileId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $viewXmlFilename = $row['filename'];
                    $viewXmlContent = htmlspecialchars($row['content']);
                }
            }
        } catch (Exception $e) {
            $errorMessage = "Error retrieving XML file: " . $e->getMessage();
        }
    } else {
        $filePath = $xmlDir . '/' . $fileId;
        if (file_exists($filePath)) {
            $viewXmlFilename = $fileId;
            $viewXmlContent = htmlspecialchars(file_get_contents($filePath));
        }
    }
    
    if (empty($viewXmlContent)) {
        $errorMessage = "XML file not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - PPSR XML Manager</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .xml-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .xml-table th, .xml-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        
        .xml-table th {
            background-color: #f2f2f2;
        }
        
        .xml-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .xml-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .action-links a {
            margin-right: 10px;
            color: #0066cc;
            text-decoration: none;
        }
        
        .action-links a:hover {
            text-decoration: underline;
        }
        
        .action-links a.delete {
            color: #cc0000;
        }
        
        .success-message {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .error-message {
            background-color: #f2dede;
            color: #a94442;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .info-message {
            background-color: #d9edf7;
            color: #31708f;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .upload-form {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f8f8;
            border-radius: 4px;
        }
        
        .upload-form input[type="file"] {
            margin-bottom: 10px;
        }
        
        .upload-form input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .upload-form input[type="submit"]:hover {
            background-color: #45a049;
        }
        
        .action-buttons {
            margin-bottom: 20px;
        }
        
        .action-buttons a {
            display: inline-block;
            margin-right: 10px;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        
        .action-buttons a:hover {
            background-color: #45a049;
        }
        
        .xml-content {
            background-color: #f8f8f8;
            padding: 15px;
            border-radius: 4px;
            overflow-x: auto;
            white-space: pre-wrap;
            font-family: monospace;
            margin-top: 20px;
        }
        
        .xml-content-header {
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .tabs {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            margin-bottom: 20px;
        }
        
        .tabs button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
        }
        
        .tabs button:hover {
            background-color: #ddd;
        }
        
        .tabs button.active {
            background-color: #ccc;
        }
        
        .tab-content {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName).style.display = "block";
            evt.currentTarget.className += " active";
        }
        
        function confirmDelete(filename) {
            return confirm("Are you sure you want to delete the XML file: " + filename + "?");
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>PPSR XML Manager</h1>
        
        <?php if (isset($successMessage)): ?>
            <div class="success-message"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        
        <?php if (isset($errorMessage)): ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        
        <?php if (isset($infoMessage)): ?>
            <div class="info-message"><?php echo $infoMessage; ?></div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tablinks active" onclick="openTab(event, 'UploadTab')">Upload XML</button>
            <button class="tablinks" onclick="openTab(event, 'DatabaseTab')">Database XML Files</button>
            <button class="tablinks" onclick="openTab(event, 'FileSystemTab')">File System XML Files</button>
            <?php if (!empty($viewXmlContent)): ?>
                <button class="tablinks" onclick="openTab(event, 'ViewTab')">View XML</button>
            <?php endif; ?>
        </div>
        
        <div id="UploadTab" class="tab-content" style="display: block;">
            <h2>Upload XML File</h2>
            <div class="upload-form">
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="file" name="xml_file" accept=".xml" required>
                    <input type="submit" name="upload_xml" value="Upload XML">
                </form>
            </div>
            
            <div class="action-buttons">
                <a href="?extract=searches">Extract XML from Searches</a>
                <a href="?create_table=api_xml">Create api_xml Table</a>
            </div>
        </div>
        
        <div id="DatabaseTab" class="tab-content">
            <h2>Database XML Files</h2>
            <?php if (empty($dbXmlFiles)): ?>
                <p>No XML files found in database. You may need to create the api_xml table first.</p>
            <?php else: ?>
                <table class="xml-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Filename</th>
                            <th>Upload Date</th>
                            <th>User</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dbXmlFiles as $file): ?>
                            <tr>
                                <td><?php echo $file['id']; ?></td>
                                <td><?php echo $file['filename']; ?></td>
                                <td><?php echo formatDate($file['upload_date']); ?></td>
                                <td><?php echo getUserEmail($file['user_id'] ?? null, $conn); ?></td>
                                <td class="action-links">
                                    <a href="?view=<?php echo $file['id']; ?>">View</a>
                                    <a href="?download=<?php echo $file['id']; ?>">Download</a>
                                    <a href="?delete=<?php echo $file['id']; ?>" class="delete" onclick="return confirmDelete('<?php echo $file['filename']; ?>')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div id="FileSystemTab" class="tab-content">
            <h2>File System XML Files</h2>
            <?php if (empty($dirXmlFiles)): ?>
                <p>No XML files found in the file system.</p>
            <?php else: ?>
                <table class="xml-table">
                    <thead>
                        <tr>
                            <th>Filename</th>
                            <th>Size</th>
                            <th>Modified</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dirXmlFiles as $file): ?>
                            <tr>
                                <td><?php echo $file['filename']; ?></td>
                                <td><?php echo formatFileSize($file['size']); ?></td>
                                <td><?php echo $file['modified']; ?></td>
                                <td class="action-links">
                                    <a href="?view=<?php echo $file['filename']; ?>">View</a>
                                    <a href="?download=<?php echo $file['filename']; ?>">Download</a>
                                    <a href="?delete=<?php echo $file['filename']; ?>" class="delete" onclick="return confirmDelete('<?php echo $file['filename']; ?>')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <?php if (!empty($viewXmlContent)): ?>
            <div id="ViewTab" class="tab-content">
                <h2>View XML: <?php echo $viewXmlFilename; ?></h2>
                <div class="action-links">
                    <a href="?download=<?php echo is_numeric($_GET['view']) ? $_GET['view'] : $viewXmlFilename; ?>">Download</a>
                </div>
                <div class="xml-content">
                    <pre><?php echo $viewXmlContent; ?></pre>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
