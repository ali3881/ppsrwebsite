<div class="admin-api-logs">
    <h3>API Logs</h3>
    
    <?php
    if (isset($_GET['action']) && isset($_GET['log_id'])) {
        $logId = (int)$_GET['log_id'];
        $action = $_GET['action'];
        
        switch ($action) {
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM api_logs WHERE id = ?");
                $stmt->bind_param("i", $logId);
                
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success">API log deleted successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger">Error deleting API log: ' . $stmt->error . '</div>';
                }
                break;
                
            case 'view':
                $stmt = $conn->prepare("SELECT l.*, u.email FROM api_logs l JOIN users u ON l.user_id = u.id WHERE l.id = ?");
                $stmt->bind_param("i", $logId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $log = $result->fetch_assoc();
                    
                    echo '<div class="log-details">';
                    echo '<h4>API Log Details</h4>';
                    
                    echo '<div class="log-info">';
                    echo '<p><strong>Log ID:</strong> ' . $log['id'] . '</p>';
                    echo '<p><strong>User:</strong> ' . htmlspecialchars($log['email']) . '</p>';
                    echo '<p><strong>Request Type:</strong> ' . htmlspecialchars($log['request_type']) . '</p>';
                    echo '<p><strong>Status:</strong> ' . htmlspecialchars($log['status']) . '</p>';
                    echo '<p><strong>Date:</strong> ' . date('Y-m-d H:i:s', strtotime($log['created_at'])) . '</p>';
                    echo '</div>';
                    
                    echo '<h4>Request Data</h4>';
                    echo '<div class="log-request">';
                    echo '<pre>' . htmlspecialchars($log['request_data']) . '</pre>';
                    echo '</div>';
                    
                    echo '<h4>Response Data</h4>';
                    echo '<div class="log-response">';
                    echo '<pre>' . htmlspecialchars($log['response_data']) . '</pre>';
                    echo '</div>';
                    
                    echo '<div class="back-link">';
                    echo '<a href="index.php?page=admin&action=api_logs">Back to API Logs</a>';
                    echo '</div>';
                    echo '</div>';
                    
                    return;
                } else {
                    echo '<div class="alert alert-danger">API log not found.</div>';
                }
                break;
        }
    }
    
    $page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
    $perPage = 20;
    $offset = ($page - 1) * $perPage;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM api_logs");
    $totalLogs = $result->fetch_assoc()['count'];
    $totalPages = ceil($totalLogs / $perPage);
    
    $result = $conn->query("SELECT l.*, u.email FROM api_logs l JOIN users u ON l.user_id = u.id ORDER BY l.created_at DESC LIMIT $offset, $perPage");
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    ?>
    
    <div class="admin-actions">
        <a href="index.php?page=admin&action=api_logs&clear=1" class="btn btn-tertiary" onclick="return confirmDelete('Are you sure you want to clear all API logs?')">Clear All Logs</a>
    </div>
    
    <?php
    if (isset($_GET['clear']) && $_GET['clear'] == 1) {
        $result = $conn->query("DELETE FROM api_logs");
        
        if ($result) {
            echo '<div class="alert alert-success">All API logs cleared successfully.</div>';
            echo '<script>window.location.href = "index.php?page=admin&action=api_logs";</script>';
        } else {
            echo '<div class="alert alert-danger">Error clearing API logs: ' . $conn->error . '</div>';
        }
    }
    ?>
    
    <?php if (empty($logs)): ?>
        <div class="alert alert-info">No API logs found.</div>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Request Type</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo $log['id']; ?></td>
                        <td><?php echo htmlspecialchars($log['email']); ?></td>
                        <td><?php echo htmlspecialchars($log['request_type']); ?></td>
                        <td><?php echo htmlspecialchars($log['status']); ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                        <td>
                            <a href="index.php?page=admin&action=api_logs&action=view&log_id=<?php echo $log['id']; ?>" class="btn btn-sm btn-primary">View</a>
                            <a href="index.php?page=admin&action=api_logs&action=delete&log_id=<?php echo $log['id']; ?>" class="btn btn-sm btn-tertiary" onclick="return confirmDelete('Are you sure you want to delete this API log?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="index.php?page=admin&action=api_logs&page_num=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
