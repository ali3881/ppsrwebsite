<div class="admin-searches">
    <h3>Search Management</h3>
    
    <?php
    if (isset($_GET['action']) && isset($_GET['search_id'])) {
        $searchId = (int)$_GET['search_id'];
        $action = $_GET['action'];
        
        switch ($action) {
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM searches WHERE id = ?");
                $stmt->bind_param("i", $searchId);
                
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success">Search record deleted successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger">Error deleting search record: ' . $stmt->error . '</div>';
                }
                break;
                
            case 'view':
                $stmt = $conn->prepare("SELECT s.*, u.email FROM searches s JOIN users u ON s.user_id = u.id WHERE s.id = ?");
                $stmt->bind_param("i", $searchId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $search = $result->fetch_assoc();
                    $searchData = json_decode($search['response_data'], true);
                    
                    echo '<div class="search-details">';
                    echo '<h4>Search Details</h4>';
                    
                    echo '<div class="search-info">';
                    echo '<p><strong>Search ID:</strong> ' . $search['id'] . '</p>';
                    echo '<p><strong>User:</strong> ' . htmlspecialchars($search['email']) . '</p>';
                    echo '<p><strong>VIN:</strong> ' . htmlspecialchars($search['vin']) . '</p>';
                    echo '<p><strong>Status:</strong> ' . htmlspecialchars($search['status']) . '</p>';
                    echo '<p><strong>Date:</strong> ' . date('Y-m-d H:i:s', strtotime($search['created_at'])) . '</p>';
                    echo '</div>';
                    
                    echo '<h4>Search Results</h4>';
                    echo '<div class="search-results">';
                    echo '<pre>' . print_r($searchData, true) . '</pre>';
                    echo '</div>';
                    
                    echo '<div class="search-actions">';
                    if ($search['pdf_report']) {
                        echo '<a href="' . $search['pdf_report'] . '" class="btn btn-primary" target="_blank">View PDF Report</a> ';
                    }
                    
                    if ($search['html_report']) {
                        echo '<a href="' . $search['html_report'] . '" class="btn btn-secondary" target="_blank">View HTML Report</a> ';
                    }
                    echo '</div>';
                    
                    echo '<div class="back-link">';
                    echo '<a href="index.php?page=admin&action=searches">Back to Searches</a>';
                    echo '</div>';
                    echo '</div>';
                    
                    return;
                } else {
                    echo '<div class="alert alert-danger">Search record not found.</div>';
                }
                break;
        }
    }
    
    $page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    
    $result = $conn->query("SELECT COUNT(*) as count FROM searches");
    $totalSearches = $result->fetch_assoc()['count'];
    $totalPages = ceil($totalSearches / $perPage);
    
    $result = $conn->query("SELECT s.*, u.email FROM searches s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC LIMIT $offset, $perPage");
    
    $searches = [];
    while ($row = $result->fetch_assoc()) {
        $searches[] = $row;
    }
    ?>
    
    <?php if (empty($searches)): ?>
        <div class="alert alert-info">No searches found.</div>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>VIN</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Reports</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($searches as $search): ?>
                    <tr>
                        <td><?php echo $search['id']; ?></td>
                        <td><?php echo htmlspecialchars($search['email']); ?></td>
                        <td><?php echo htmlspecialchars($search['vin']); ?></td>
                        <td><?php echo htmlspecialchars($search['status']); ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($search['created_at'])); ?></td>
                        <td>
                            <?php if ($search['pdf_report']): ?>
                                <a href="<?php echo $search['pdf_report']; ?>" class="btn btn-sm btn-primary" target="_blank">PDF</a>
                            <?php endif; ?>
                            
                            <?php if ($search['html_report']): ?>
                                <a href="<?php echo $search['html_report']; ?>" class="btn btn-sm btn-secondary" target="_blank">HTML</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="index.php?page=admin&action=searches&action=view&search_id=<?php echo $search['id']; ?>" class="btn btn-sm btn-primary">View</a>
                            <a href="index.php?page=admin&action=searches&action=delete&search_id=<?php echo $search['id']; ?>" class="btn btn-sm btn-tertiary" onclick="return confirmDelete('Are you sure you want to delete this search record?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="index.php?page=admin&action=searches&page_num=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
