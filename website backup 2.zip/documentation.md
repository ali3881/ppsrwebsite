# PPSR Service Website Documentation

## Overview

This documentation provides detailed information about the PPSR (Personal Property Securities Register) Service Website implementation. The website allows users to search the PPSR database using VIN (Vehicle Identification Number) and provides detailed reports in PDF and HTML formats.

## System Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- SOAP extension for PHP
- GD library for PHP (for PDF generation)
- SSL certificate for secure connections

## Installation

1. Clone or download the repository to your web server directory.
2. Create a MySQL database for the application.
3. Import the database schema using the `setup/database.php` script.
4. Configure the database connection and other settings in `includes/config.php`.
5. Ensure the `reports` directory is writable by the web server.
6. Set up your web server to point to the application's root directory.

## Configuration

The application configuration is stored in `includes/config.php`. You need to update the following settings:

- Database connection details
- PPSR API credentials
- Payment gateway credentials
- Site settings

## Directory Structure

```
ppsr-php/
├── admin/                  # Admin panel files
│   ├── api_logs.php        # API logs management
│   ├── dashboard.php       # Admin dashboard
│   ├── index.php           # Admin panel main file
│   ├── payments.php        # Payment management
│   ├── searches.php        # Search management
│   ├── settings.php        # System settings
│   └── users.php           # User management
├── api/                    # API endpoints
├── assets/                 # Static assets
├── css/                    # CSS files
│   └── style.css           # Main stylesheet
├── includes/               # Core PHP files
│   ├── config.php          # Configuration file
│   ├── dashboard.php       # User dashboard
│   ├── footer.php          # Footer template
│   ├── functions.php       # Helper functions
│   ├── header.php          # Header template
│   ├── home.php            # Home page
│   ├── login.php           # Login page
│   ├── logout.php          # Logout script
│   ├── register.php        # Registration page
│   └── search.php          # Search page
├── js/                     # JavaScript files
│   └── main.js             # Main JavaScript file
├── reports/                # Generated reports
├── setup/                  # Setup scripts
│   └── database.php        # Database setup script
├── soap/                   # SOAP API integration
└── index.php               # Main entry point
```

## Features

### User Registration and Login

The system provides a secure user registration and login system. Users can:
- Register with their name, email, and password
- Log in using their email and password
- Reset their password if forgotten
- Update their profile information

### VIN Search

Users can search the PPSR database using a Vehicle Identification Number (VIN). The system:
- Validates the VIN format
- Connects to the PPSR SOAP API
- Processes the search request
- Handles the API response
- Displays the search results
- Generates reports in PDF and HTML formats

### Payment Processing

The system integrates with payment gateways to process search fees:
- Stripe for credit card payments
- Secure payment processing
- Transaction logging

### User Dashboard

Registered users have access to a dashboard where they can:
- View their search history
- Download previously generated reports
- Manage their account information

### Admin Panel

The admin panel provides administrative functions:
- User management (add, edit, delete users)
- Search management (view, delete search records)
- Payment management (view, delete payment records)
- API logs (view, delete API logs)
- System settings (configure application settings)

### Report Generation

The system generates detailed reports in multiple formats:
- PDF reports for printing and offline viewing
- HTML reports for online viewing and sharing

## SOAP API Integration

The system integrates with the PPSR SOAP API to perform VIN searches. The integration:
- Authenticates with the PPSR API using provided credentials
- Sends search requests with VIN information
- Processes the API responses
- Handles errors and exceptions

### API Credentials

The following credentials are used for PPSR API access:
- Account Name: ppsrseccheck
- Account Number: 101321866
- Username: pps834
- Password: M4GZ3RPYLFN6
- Endpoint URL: https://ppsr.gov.au/b2g/production
- SOAPAction: "http://afsa.gov.au/services/SearchByVIN"

## Security Measures

The system implements several security measures:
- Password hashing using bcrypt
- Input sanitization to prevent SQL injection
- CSRF protection for forms
- Secure session management
- Role-based access control
- Secure storage of API credentials and payment gateway keys

## Error Handling and Logging

The system includes comprehensive error handling and logging:
- API request and response logging
- Payment transaction logging
- User activity logging
- Structured error logging for debugging

## Australian Data Privacy Compliance

The system is designed to comply with Australian data privacy regulations:
- Secure storage of personal information
- User consent for data collection
- Data retention policies
- Privacy policy implementation

## Responsive Design

The website features a responsive design that works on various devices:
- Desktop computers
- Tablets
- Mobile phones

## Maintenance and Updates

### Regular Maintenance Tasks

- Database backup
- Log file rotation
- Security updates
- API credential rotation

### Updating the System

1. Backup the database and files
2. Download the updated files
3. Replace the existing files
4. Run any database migration scripts
5. Test the system functionality

## Troubleshooting

### Common Issues

1. **SOAP Connection Errors**
   - Check API credentials
   - Verify endpoint URL
   - Check network connectivity
   - Ensure SOAP extension is enabled

2. **Payment Processing Errors**
   - Verify payment gateway credentials
   - Check payment gateway status
   - Review transaction logs

3. **Report Generation Errors**
   - Ensure the reports directory is writable
   - Check PHP GD library is installed
   - Verify PDF generation library is working

## Support

For technical support or questions about the PPSR Service Website, please contact:
- Email: support@example.com
- Phone: (123) 456-7890
