
document.addEventListener('DOMContentLoaded', function() {
    
    initializeComponents();
});

function initializeComponents() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', validateForm);
    });
}

function validateForm(event) {
    const form = event.target;
    
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            highlightField(field, true);
        } else {
            highlightField(field, false);
        }
    });
    
    const emailFields = form.querySelectorAll('input[type="email"]');
    emailFields.forEach(field => {
        if (field.value.trim() && !isValidEmail(field.value.trim())) {
            isValid = false;
            highlightField(field, true);
        }
    });
    
    const passwordField = form.querySelector('input[name="password"]');
    const confirmPasswordField = form.querySelector('input[name="confirm_password"]');
    
    if (passwordField && confirmPasswordField) {
        if (passwordField.value !== confirmPasswordField.value) {
            isValid = false;
            highlightField(confirmPasswordField, true);
            
            const errorContainer = document.querySelector('.error-container');
            if (errorContainer) {
                const errorElement = document.createElement('p');
                errorElement.classList.add('error');
                errorElement.textContent = 'Passwords do not match';
                errorContainer.appendChild(errorElement);
            }
        }
    }
    
    if (!isValid) {
        event.preventDefault();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function highlightField(field, isError) {
    if (isError) {
        field.classList.add('error');
        field.style.borderColor = 'var(--danger-color)';
    } else {
        field.classList.remove('error');
        field.style.borderColor = '';
    }
}

function formatCurrency(amount) {
    return '$' + parseFloat(amount).toFixed(2);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-AU');
}

function togglePasswordVisibility(inputId) {
    const passwordInput = document.getElementById(inputId);
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
}

function printReport() {
    window.print();
}

function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this item?');
}
